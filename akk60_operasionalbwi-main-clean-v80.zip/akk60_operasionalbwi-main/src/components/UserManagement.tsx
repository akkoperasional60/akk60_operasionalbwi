import React, { useState, useEffect, useRef, useLayoutEffect } from 'react';
import { createPortal } from 'react-dom';
import { 
  Users, UserCheck, UserX, Clock, ShieldAlert, CheckCircle2, XCircle, 
  Search, Filter, Plus, Shield, User, Building, Phone, Mail, Calendar, 
  AlertTriangle, Edit3, Lock, Save, UserCog, ShieldCheck, X, Key, Copy, Check,
  ChevronDown, ChevronRight, ChevronUp, Settings, Eye, EyeOff, BarChart3,
  Truck, Briefcase, Package, Megaphone, ShoppingBag, DollarSign
} from 'lucide-react';
import { UserProfile, UserRole, UserApprovalStatus, UserPermissions } from '../types';
import { logisticsStore } from '../services/store';
import { canAccess, getDefaultPermissionsForRole, CANONICAL_SIDEBAR_MODULES, LEGACY_SUBMENU_KEY_MAP } from '../utils/rbac';
import { branchStore, BranchRecord, UserBranchPermissionEntry } from '../services/branchStore';

const MODULE_ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  logistics: Truck,
  sales_admin: Briefcase,
  warehouse: Package,
  purchasing: ShoppingBag,
  marketing: Megaphone,
  finance_tax: DollarSign,
  hr: Users,
  sistem_pengguna: Settings,
};

const MODULE_DEFINITIONS = CANONICAL_SIDEBAR_MODULES.map(mod => ({
  ...mod,
  IconComp: MODULE_ICON_MAP[mod.id] || Settings,
}));

const DEPARTMENT_FILTER_OPTIONS = [
  { id: 'all', label: 'Semua Role / Departemen', shortLabel: 'Semua', Icon: Users, tone: 'text-amber-400 bg-amber-500/15' },
  { id: 'logistics', label: 'Logistik & Armada', shortLabel: 'Logistik', Icon: Truck, tone: 'text-blue-400 bg-blue-500/15' },
  { id: 'sales', label: 'Admin Penjualan (Sales)', shortLabel: 'Sales', Icon: Briefcase, tone: 'text-violet-400 bg-violet-500/15' },
  { id: 'warehouse', label: 'Gudang (Warehouse)', shortLabel: 'Gudang', Icon: Package, tone: 'text-emerald-400 bg-emerald-500/15' },
  { id: 'marketing', label: 'Marketing', shortLabel: 'Marketing', Icon: Megaphone, tone: 'text-orange-400 bg-orange-500/15' },
  { id: 'purchasing', label: 'Admin Pembelian', shortLabel: 'Pembelian', Icon: ShoppingBag, tone: 'text-pink-400 bg-pink-500/15' },
  { id: 'finance', label: 'Adm Finance & Tax', shortLabel: 'Finance', Icon: DollarSign, tone: 'text-lime-400 bg-lime-500/15' },
  { id: 'hr', label: 'HRD & Security', shortLabel: 'HR & GA', Icon: Shield, tone: 'text-rose-400 bg-rose-500/15' },
  { id: 'super_admin', label: 'Super Admin', shortLabel: 'Super Admin', Icon: ShieldCheck, tone: 'text-amber-300 bg-amber-500/20' },
];

const OFFICIAL_DEPARTMENT_OPTIONS = [
  'Logistik',
  'Adm. Penjualan',
  'Adm. Pembelian',
  'Gudang',
  'Finance & Tax',
  'Satpam',
  'Human Resources',
  'Marketing'
];

interface RoleDropdownOption {
  value: UserRole;
  label: string;
  category: string;
  Icon: React.ComponentType<{ className?: string }>;
  iconTone: string;
}

const ROLE_DROPDOWN_OPTIONS: RoleDropdownOption[] = [
  { value: 'super_admin', label: 'Super Admin', category: 'Manajemen', Icon: ShieldCheck, iconTone: 'bg-amber-500/20 text-amber-400 border-amber-500/30' },
  { value: 'spv_logistik', label: 'SPV Logistik', category: 'Logistik', Icon: Truck, iconTone: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
  { value: 'operasional', label: 'SPV Operasional', category: 'Operasional', Icon: BarChart3, iconTone: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30' },
  { value: 'koordinator_driver', label: 'Koordinator Driver', category: 'Logistik', Icon: UserCog, iconTone: 'bg-sky-500/20 text-sky-400 border-sky-500/30' },
  { value: 'driver', label: 'Driver', category: 'Logistik', Icon: Truck, iconTone: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
  { value: 'crew_helper', label: 'Helper', category: 'Logistik', Icon: Users, iconTone: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30' },
  { value: 'koordinator_gudang', label: 'Koordinator Gudang', category: 'Gudang', Icon: Package, iconTone: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
  { value: 'warehouse_admin', label: 'Gudang', category: 'Gudang', Icon: Package, iconTone: 'bg-teal-500/20 text-teal-400 border-teal-500/30' },
  { value: 'spv_sales_admin', label: 'SPV Adm Penjualan', category: 'Penjualan', Icon: Briefcase, iconTone: 'bg-violet-500/20 text-violet-400 border-violet-500/30' },
  { value: 'sales_admin', label: 'Adm. Penjualan', category: 'Penjualan', Icon: Briefcase, iconTone: 'bg-purple-500/20 text-purple-400 border-purple-500/30' },
  { value: 'spv_purchasing_admin', label: 'SPV Adm Pembelian', category: 'Pembelian', Icon: ShoppingBag, iconTone: 'bg-fuchsia-500/20 text-fuchsia-400 border-fuchsia-500/30' },
  { value: 'purchasing_admin', label: 'Adm. Pembelian', category: 'Pembelian', Icon: ShoppingBag, iconTone: 'bg-pink-500/20 text-pink-400 border-pink-500/30' },
  { value: 'spv_marketing_offline', label: 'SPV Marketing Offline', category: 'Marketing', Icon: Megaphone, iconTone: 'bg-orange-500/20 text-orange-400 border-orange-500/30' },
  { value: 'marketing_offline', label: 'Marketing Offline', category: 'Marketing', Icon: Megaphone, iconTone: 'bg-amber-500/20 text-amber-400 border-amber-500/30' },
  { value: 'marketing_online', label: 'Marketing Online', category: 'Marketing', Icon: BarChart3, iconTone: 'bg-sky-500/20 text-sky-400 border-sky-500/30' },
  { value: 'finance_tax_admin', label: 'Adm Finance & Tax', category: 'Finance', Icon: DollarSign, iconTone: 'bg-lime-500/20 text-lime-400 border-lime-500/30' },
  { value: 'hr_admin', label: 'Human Resource Development', category: 'HR & GA', Icon: Users, iconTone: 'bg-rose-500/20 text-rose-400 border-rose-500/30' },
  { value: 'security', label: 'Security', category: 'Keamanan', Icon: Shield, iconTone: 'bg-slate-500/20 text-slate-300 border-slate-500/30' },
  { value: 'unassigned', label: 'Perlu Diisi (Belum Ditentukan)', category: 'Belum Diatur', Icon: AlertTriangle, iconTone: 'bg-rose-500/20 text-rose-400 border-rose-500/30' }
];

const getDefaultDepartmentForRole = (role: UserRole, fallback = 'Logistik'): string => {
  switch (role) {
    case 'driver':
    case 'crew_helper':
    case 'spv_logistik':
    case 'operasional':
    case 'koordinator_driver':
    case 'super_admin':
      return 'Logistik';
    case 'security':
      return 'Satpam';
    case 'sales_admin':
    case 'spv_sales_admin':
      return 'Adm. Penjualan';
    case 'purchasing_admin':
    case 'spv_purchasing_admin':
      return 'Adm. Pembelian';
    case 'warehouse_admin':
    case 'koordinator_gudang':
      return 'Gudang';
    case 'finance_tax_admin':
      return 'Finance & Tax';
    case 'hr_admin':
      return 'Human Resources';
    case 'marketing_online':
    case 'marketing_offline':
    case 'spv_marketing_offline':
      return 'Marketing';
    default:
      return fallback;
  }
};

interface PortalMenuPosition {
  top?: number;
  bottom?: number;
  left: number;
  width: number;
  maxHeight: number;
  openUp: boolean;
}

function computePortalPosition(triggerEl: HTMLElement, minWidth = 220, desiredMaxHeight = 260): PortalMenuPosition {
  const rect = triggerEl.getBoundingClientRect();
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const margin = 12;
  const gap = 6;
  const width = Math.min(Math.max(rect.width, minWidth), vw - margin * 2);
  let left = rect.left;
  if (left + width > vw - margin) {
    left = Math.max(margin, vw - margin - width);
  }
  const spaceBelow = vh - rect.bottom - margin - gap;
  const spaceAbove = rect.top - margin - gap;
  const openUp = spaceBelow < Math.min(220, desiredMaxHeight) && spaceAbove > spaceBelow;
  const maxHeight = Math.max(140, Math.min(desiredMaxHeight, openUp ? spaceAbove : spaceBelow));

  if (openUp) {
    return {
      bottom: vh - rect.top + gap,
      left,
      width,
      maxHeight,
      openUp: true
    };
  }
  return {
    top: rect.bottom + gap,
    left,
    width,
    maxHeight,
    openUp: false
  };
}

interface CustomSelectOption {
  value: string;
  label: string;
  sublabel?: string;
  dotClass?: string;
  Icon?: React.ComponentType<{ className?: string }>;
  iconTone?: string;
}

const CustomSelectDropdown: React.FC<{
  value: string;
  onChange: (val: string) => void;
  options: CustomSelectOption[];
  placeholder?: string;
  disabled?: boolean;
  searchable?: boolean;
  searchPlaceholder?: string;
  compact?: boolean;
  minMenuWidth?: number;
}> = ({
  value,
  onChange,
  options,
  placeholder = 'Pilih opsi...',
  disabled = false,
  searchable = false,
  searchPlaceholder = 'Cari...',
  compact = false,
  minMenuWidth = 210
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [menuPos, setMenuPos] = useState<PortalMenuPosition | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const searchRef = useRef<HTMLInputElement | null>(null);

  const selected = options.find(opt => opt.value === value) || null;
  const filtered = query.trim()
    ? options.filter(
        opt =>
          opt.label.toLowerCase().includes(query.trim().toLowerCase()) ||
          (opt.sublabel || '').toLowerCase().includes(query.trim().toLowerCase())
      )
    : options;

  const updatePos = () => {
    if (!triggerRef.current) return;
    setMenuPos(computePortalPosition(triggerRef.current, minMenuWidth, 260));
  };

  useLayoutEffect(() => {
    if (!isOpen) return;
    updatePos();
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    setQuery('');
    const t = searchable ? setTimeout(() => searchRef.current?.focus(), 40) : null;
    const handleOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      if (triggerRef.current?.contains(target) || menuRef.current?.contains(target)) return;
      setIsOpen(false);
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsOpen(false);
    };
    const handleReposition = () => updatePos();
    document.addEventListener('mousedown', handleOutside);
    window.addEventListener('keydown', handleEsc);
    window.addEventListener('resize', handleReposition);
    window.addEventListener('scroll', handleReposition, true);
    return () => {
      if (t) clearTimeout(t);
      document.removeEventListener('mousedown', handleOutside);
      window.removeEventListener('keydown', handleEsc);
      window.removeEventListener('resize', handleReposition);
      window.removeEventListener('scroll', handleReposition, true);
    };
  }, [isOpen, searchable]);

  const SelectedIcon = selected?.Icon;

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        disabled={disabled}
        onClick={() => !disabled && setIsOpen(prev => !prev)}
        className={`w-full ${
          compact ? 'px-2.5 py-1.5 rounded-lg text-[11px]' : 'px-3 py-2 rounded-xl text-xs'
        } bg-slate-950 border text-left flex items-center justify-between gap-2 transition ${
          disabled
            ? 'opacity-60 cursor-not-allowed border-slate-800'
            : isOpen
            ? 'border-amber-500 ring-2 ring-amber-500/20 shadow-md shadow-amber-500/10 cursor-pointer'
            : 'border-slate-800 hover:border-slate-600 cursor-pointer'
        }`}
      >
        <div className="flex items-center gap-2 min-w-0">
          {selected?.dotClass && (
            <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${selected.dotClass}`} />
          )}
          {SelectedIcon && (
            <span
              className={`${
                compact ? 'w-5 h-5 rounded-md' : 'w-6 h-6 rounded-lg'
              } border flex items-center justify-center shrink-0 ${
                selected?.iconTone || 'bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              <SelectedIcon className={compact ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
            </span>
          )}
          <span className={`font-semibold truncate ${selected ? 'text-white' : 'text-slate-400'}`}>
            {selected ? selected.label : placeholder}
          </span>
        </div>
        <ChevronDown
          className={`${compact ? 'w-3.5 h-3.5' : 'w-4 h-4'} text-slate-400 shrink-0 transition-transform duration-150 ${
            isOpen ? 'rotate-180 text-amber-400' : ''
          }`}
        />
      </button>

      {isOpen &&
        menuPos &&
        typeof document !== 'undefined' &&
        createPortal(
          <div
            ref={menuRef}
            style={{
              position: 'fixed',
              top: menuPos.top,
              bottom: menuPos.bottom,
              left: menuPos.left,
              width: menuPos.width,
              zIndex: 9999
            }}
            className="rounded-2xl bg-slate-900 border border-slate-700/90 shadow-2xl shadow-black/75 overflow-hidden animate-in fade-in duration-150"
          >
            {searchable && (
              <div className="p-2 border-b border-slate-800 bg-slate-950/80">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    ref={searchRef}
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder={searchPlaceholder}
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            )}

            <div
              style={{ maxHeight: Math.max(120, menuPos.maxHeight - (searchable ? 48 : 8)) }}
              className="overflow-y-auto p-1.5 space-y-0.5"
            >
              {filtered.length === 0 ? (
                <div className="py-4 text-center text-[11px] text-slate-500">Data tidak ditemukan.</div>
              ) : (
                filtered.map(opt => {
                  const OptIcon = opt.Icon;
                  const active = opt.value === value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => {
                        onChange(opt.value);
                        setIsOpen(false);
                      }}
                      className={`w-full px-2.5 py-2 rounded-xl flex items-center justify-between gap-2 text-left transition cursor-pointer ${
                        active
                          ? 'bg-amber-500/15 border border-amber-500/40 text-amber-300'
                          : 'border border-transparent hover:bg-slate-800/80 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {opt.dotClass && (
                          <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${opt.dotClass}`} />
                        )}
                        {OptIcon && (
                          <span
                            className={`w-6 h-6 rounded-lg border flex items-center justify-center shrink-0 ${
                              opt.iconTone || 'bg-slate-800 text-slate-300 border-slate-700'
                            }`}
                          >
                            <OptIcon className="w-3.5 h-3.5" />
                          </span>
                        )}
                        <div className="min-w-0">
                          <div className={`text-xs truncate ${active ? 'text-amber-300 font-bold' : 'text-white font-semibold'}`}>
                            {opt.label}
                          </div>
                          {opt.sublabel && (
                            <div className="text-[10px] text-slate-400 truncate">{opt.sublabel}</div>
                          )}
                        </div>
                      </div>
                      {active && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                    </button>
                  );
                })
              )}
            </div>
          </div>,
          document.body
        )}
    </>
  );
};

const USER_STATUS_DROPDOWN_OPTIONS: CustomSelectOption[] = [
  { value: 'approved', label: 'Aktif / Disetujui', sublabel: 'Akun aktif dan dapat mengakses sistem', dotClass: 'bg-emerald-400 ring-2 ring-emerald-500/30' },
  { value: 'inactive', label: 'Nonaktif', sublabel: 'Akses ditutup, histori tetap tersimpan', dotClass: 'bg-slate-400 ring-2 ring-slate-500/30' },
  { value: 'pending', label: 'Menunggu Approval', sublabel: 'Belum disetujui oleh Super Admin', dotClass: 'bg-amber-400 ring-2 ring-amber-500/30' },
  { value: 'rejected', label: 'Ditolak / Dibekukan', sublabel: 'Permintaan akses dibekukan', dotClass: 'bg-rose-500 ring-2 ring-rose-500/30' }
];

const ACCESS_LEVEL_DROPDOWN_OPTIONS: CustomSelectOption[] = [
  { value: 'full_access', label: 'Full Akses', sublabel: 'Bisa input & edit data', dotClass: 'bg-emerald-400' },
  { value: 'read_only', label: 'Hanya Lihat', sublabel: 'Read only tanpa ubah data', dotClass: 'bg-amber-400' },
  { value: 'none', label: 'Tidak Ada Akses', sublabel: 'Sub-menu dinonaktifkan', dotClass: 'bg-rose-500' }
];

const CustomRoleDropdown: React.FC<{
  value: UserRole;
  onChange: (role: UserRole) => void;
  includeUnassigned?: boolean;
}> = ({ value, onChange, includeUnassigned = false }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [menuPos, setMenuPos] = useState<PortalMenuPosition | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const searchRef = useRef<HTMLInputElement | null>(null);

  const options = ROLE_DROPDOWN_OPTIONS.filter(opt => includeUnassigned || opt.value !== 'unassigned');
  const selected = ROLE_DROPDOWN_OPTIONS.find(opt => opt.value === value) || options[0];
  const filtered = query.trim()
    ? options.filter(
        opt =>
          opt.label.toLowerCase().includes(query.trim().toLowerCase()) ||
          opt.category.toLowerCase().includes(query.trim().toLowerCase())
      )
    : options;

  const updatePos = () => {
    if (!triggerRef.current) return;
    setMenuPos(computePortalPosition(triggerRef.current, 270, 290));
  };

  useLayoutEffect(() => {
    if (!isOpen) return;
    updatePos();
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    setQuery('');
    const t = setTimeout(() => searchRef.current?.focus(), 40);
    const handleOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      if (triggerRef.current?.contains(target) || menuRef.current?.contains(target)) return;
      setIsOpen(false);
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsOpen(false);
    };
    const handleReposition = () => updatePos();
    document.addEventListener('mousedown', handleOutside);
    window.addEventListener('keydown', handleEsc);
    window.addEventListener('resize', handleReposition);
    window.addEventListener('scroll', handleReposition, true);
    return () => {
      clearTimeout(t);
      document.removeEventListener('mousedown', handleOutside);
      window.removeEventListener('keydown', handleEsc);
      window.removeEventListener('resize', handleReposition);
      window.removeEventListener('scroll', handleReposition, true);
    };
  }, [isOpen]);

  const SelectedIcon = selected.Icon;

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        onClick={() => setIsOpen(prev => !prev)}
        className={`w-full px-3 py-2 rounded-xl bg-slate-950 border text-left flex items-center justify-between gap-2 transition cursor-pointer ${
          isOpen
            ? 'border-amber-500 ring-2 ring-amber-500/20 shadow-lg shadow-amber-500/10'
            : 'border-slate-800 hover:border-slate-600'
        }`}
      >
        <div className="flex items-center gap-2 min-w-0">
          <span className={`w-6 h-6 rounded-lg border flex items-center justify-center shrink-0 ${selected.iconTone}`}>
            <SelectedIcon className="w-3.5 h-3.5" />
          </span>
          <span className="text-xs font-bold text-white truncate">{selected.label}</span>
        </div>
        <ChevronDown className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-150 ${isOpen ? 'rotate-180 text-amber-400' : ''}`} />
      </button>

      {isOpen &&
        menuPos &&
        typeof document !== 'undefined' &&
        createPortal(
          <div
            ref={menuRef}
            style={{
              position: 'fixed',
              top: menuPos.top,
              bottom: menuPos.bottom,
              left: menuPos.left,
              width: menuPos.width,
              zIndex: 9999
            }}
            className="rounded-2xl bg-slate-900 border border-slate-700/90 shadow-2xl shadow-black/75 overflow-hidden animate-in fade-in duration-150"
          >
            <div className="p-2 border-b border-slate-800 bg-slate-950/80">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  ref={searchRef}
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Cari role atau divisi..."
                  className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div
              style={{ maxHeight: Math.max(140, menuPos.maxHeight - 50) }}
              className="overflow-y-auto p-1.5 space-y-0.5"
            >
              {filtered.length === 0 ? (
                <div className="py-5 text-center text-[11px] text-slate-500">
                  Role tidak ditemukan.
                </div>
              ) : (
                filtered.map(opt => {
                  const OptIcon = opt.Icon;
                  const active = opt.value === value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => {
                        onChange(opt.value);
                        setIsOpen(false);
                      }}
                      className={`w-full px-2.5 py-2 rounded-xl flex items-center justify-between gap-2 text-left transition cursor-pointer ${
                        active
                          ? 'bg-amber-500/15 border border-amber-500/40 text-amber-300'
                          : 'border border-transparent hover:bg-slate-800/80 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className={`w-7 h-7 rounded-lg border flex items-center justify-center shrink-0 ${opt.iconTone}`}>
                          <OptIcon className="w-3.5 h-3.5" />
                        </span>
                        <div className="min-w-0">
                          <div className={`text-xs font-semibold truncate ${active ? 'text-amber-300 font-bold' : 'text-white'}`}>
                            {opt.label}
                          </div>
                          <div className="text-[10px] text-slate-400">{opt.category}</div>
                        </div>
                      </div>
                      {active && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                    </button>
                  );
                })
              )}
            </div>
          </div>,
          document.body
        )}
    </>
  );
};

export interface UserManagementProps {
  onNavigateToE2E?: () => void;
}

export const UserManagement: React.FC<UserManagementProps> = ({ onNavigateToE2E }) => {
  const [users, setUsers] = useState<UserProfile[]>(logisticsStore.getUsers());
  const [currentUser, setCurrentUser] = useState<UserProfile>(logisticsStore.getCurrentUser());
  const [statusFilter, setStatusFilter] = useState<'all' | UserApprovalStatus>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [isDeptFilterOpen, setIsDeptFilterOpen] = useState<boolean>(false);
  const deptFilterRef = useRef<HTMLDivElement | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);

  useEffect(() => {
    if (!isDeptFilterOpen) return;
    const handleOutside = (e: MouseEvent) => {
      if (deptFilterRef.current && !deptFilterRef.current.contains(e.target as Node)) {
        setIsDeptFilterOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, [isDeptFilterOpen]);

  // Super Admin check
  const isSuperAdmin = currentUser.role === 'super_admin';
  const visibleUsersForRole = isSuperAdmin
    ? users
    : users.filter(u => u.status !== 'inactive' && u.status !== 'rejected');

  // Selected User for Split-Screen Detail View
  const [selectedUserId, setSelectedUserId] = useState<string>(visibleUsersForRole[0]?.id || '');
  const selectedUser = visibleUsersForRole.find(u => u.id === selectedUserId) || visibleUsersForRole[0] || null;

  // Granular Access & Per-Branch Menu Permissions State
  const [branches, setBranches] = useState<BranchRecord[]>(branchStore.getBranches());
  const prevLoadedUserIdRef = useRef<string | null>(null);
  const [expandedBranches, setExpandedBranches] = useState<Record<string, boolean>>({});
  const [expandedModules, setExpandedModules] = useState<Record<string, boolean>>({});
  const [editingPermissions, setEditingPermissions] = useState<UserPermissions['modules']>({});
  const [branchPermissions, setBranchPermissions] = useState<Record<string, UserBranchPermissionEntry>>({});
  
  // Copy Access Modal State
  const [isCopyModalOpen, setIsCopyModalOpen] = useState(false);
  const [sourceUserIdForCopy, setSourceUserIdForCopy] = useState<string>('');
  
  // Delete Confirmation Modal State
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  // Change Password Modal State (locked to explicit target user so it never switches to Super Admin)
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [passwordTargetUser, setPasswordTargetUser] = useState<UserProfile | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const openPasswordModalForUser = (targetUser: UserProfile) => {
    setPasswordTargetUser(targetUser);
    setSelectedUserId(targetUser.id);
    setNewPasswordInput('');
    setConfirmPasswordInput('');
    setShowNewPassword(false);
    setShowConfirmPassword(false);
    // Clear searchQuery if browser autofill previously injected currentUser's email
    if (
      searchQuery &&
      currentUser?.email &&
      searchQuery.trim().toLowerCase() === currentUser.email.trim().toLowerCase()
    ) {
      setSearchQuery('');
    }
    setIsPasswordModalOpen(true);
  };

  const closePasswordModal = () => {
    setIsPasswordModalOpen(false);
    setPasswordTargetUser(null);
    setNewPasswordInput('');
    setConfirmPasswordInput('');
    setShowNewPassword(false);
    setShowConfirmPassword(false);
  };

  // View Password per user account state
  const [visiblePasswords, setVisiblePasswords] = useState<Record<string, boolean>>({});
  const [copiedPasswordUserId, setCopiedPasswordUserId] = useState<string | null>(null);

  const getEffectivePassword = (_u: UserProfile): string => 'Tersimpan sebagai hash di server';

  const togglePasswordVisibility = (userId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setVisiblePasswords(prev => ({ ...prev, [userId]: !prev[userId] }));
  };

  const handleCopyUserPassword = (_u: UserProfile, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setPageModalNotification({
      title: 'Password Tidak Dapat Ditampilkan',
      message: 'Password disimpan sebagai hash scrypt terenkripsi di server database. Gunakan menu Reset Password untuk menetapkan password baru.',
      type: 'info'
    });
  };

  // In-Page Pop-up Notification Modal State (Request: popup di depan halaman user manajemen)
  const [pageModalNotification, setPageModalNotification] = useState<{
    title: string;
    message: string;
    type: 'success' | 'warning' | 'error' | 'info';
  } | null>(null);

  // Support pressing Enter or Escape on keyboard when "Oke, Mengerti" modal is open
  useEffect(() => {
    if (!pageModalNotification) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        setPageModalNotification(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [pageModalNotification]);

  const showNotification = (title: string, message: string, type: 'success' | 'warning' | 'error' | 'info' = 'info') => {
    setPageModalNotification({ title, message, type });
  };

  // Edit User Profile State
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [editFormData, setEditFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    role: 'unassigned' as UserRole,
    department: 'Logistik',
    status: 'approved' as UserApprovalStatus,
    notes: '',
    approvedBy: ''
  });
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  // New user form state
  const [newUser, setNewUser] = useState({
    fullName: '',
    email: '',
    phone: '',
    role: 'driver' as UserRole,
    password: '',
    department: 'Logistik & Pengiriman'
  });

  useEffect(() => {
    const unsubUsers = logisticsStore.subscribe(() => {
      const freshUsers = logisticsStore.getUsers();
      setUsers(freshUsers);
      setCurrentUser(logisticsStore.getCurrentUser());
      if (!selectedUserId && freshUsers.length > 0) {
        setSelectedUserId(freshUsers[0].id);
      }
    });
    const unsubBranches = branchStore.subscribe(() => {
      setBranches(branchStore.getBranches());
    });
    return () => {
      unsubUsers();
      unsubBranches();
    };
  }, [selectedUserId]);

  // Combine per-branch module permissions into effective user.permissions.modules
  const computeMergedModulesFromBranches = (
    bPerms: Record<string, UserBranchPermissionEntry>,
    fallbackRole: UserRole
  ): UserPermissions['modules'] => {
    const merged: UserPermissions['modules'] = {};
    const roleDefaults = getDefaultPermissionsForRole(fallbackRole);

    MODULE_DEFINITIONS.forEach(mod => {
      let anyModEnabled = false;
      const subMenus: Record<string, 'none' | 'read_only' | 'full_access'> = {};
      mod.subMenus.forEach(s => {
        subMenus[s.id] = 'none';
      });

      Object.values(bPerms).forEach(entry => {
        if (!entry.enabled) return;
        const m = entry.modules?.[mod.id];
        if (m?.enabled) {
          anyModEnabled = true;
          mod.subMenus.forEach(s => {
            const val = m.subMenus?.[s.id] || 'none';
            if (val === 'full_access') {
              subMenus[s.id] = 'full_access';
            } else if (val === 'read_only' && subMenus[s.id] !== 'full_access') {
              subMenus[s.id] = 'read_only';
            }
          });
        }
      });

      // Fallback if all branches were unchecked so roleDefaults structure stays valid
      if (!anyModEnabled && Object.values(bPerms).every(b => !b.enabled)) {
        merged[mod.id] = {
          enabled: false,
          subMenus
        };
      } else {
        merged[mod.id] = {
          enabled: anyModEnabled || Boolean(roleDefaults[mod.id]?.enabled && false),
          subMenus
        };
      }
    });

    return merged;
  };

  const handleExpandAllBranches = () => {
    const next: Record<string, boolean> = {};
    branches.forEach(b => {
      next[b.id] = true;
    });
    setExpandedBranches(next);
  };

  const handleCollapseAllBranches = () => {
    setExpandedBranches({});
  };

  // Whenever selectedUser changes to a DIFFERENT user, initialize editingPermissions, branchPermissions, and reset accordions
  useEffect(() => {
    if (!selectedUser) {
      prevLoadedUserIdRef.current = null;
      return;
    }

    // Hanya reset dan muat ulang penuh saat berganti user (atau inisialisasi awal)
    // Mengunci status accordion agar cabang/modul yang sedang diedit TIDAK tiba-tiba tertutup saat admin mencentang hak akses
    if (prevLoadedUserIdRef.current !== selectedUser.id) {
      prevLoadedUserIdRef.current = selectedUser.id;

      const roleDefaults = getDefaultPermissionsForRole(selectedUser.role);
      const initialPerms: UserPermissions['modules'] = {};
      const isCrewRole = selectedUser.role === 'driver' || selectedUser.role === 'crew_helper';

      MODULE_DEFINITIONS.forEach(mod => {
        const userMod = selectedUser.permissions?.modules?.[mod.id];
        const defaultMod = roleDefaults[mod.id];
        const subMenuPerms: Record<string, 'read_only' | 'full_access' | 'none'> = {};

        const savedSubEntries = Object.entries(userMod?.subMenus || {});
        const savedActiveKeys = savedSubEntries
          .filter(([, v]) => v === 'full_access' || v === 'read_only')
          .map(([k]) => k);
        const savedActiveCount = savedActiveKeys.length;
        const isLegacyCrewDefault =
          mod.id === 'logistics' &&
          isCrewRole &&
          !selectedUser.permissions?.branchPermissions &&
          savedActiveCount === 2 &&
          savedActiveKeys.includes('portal_driver') &&
          savedActiveKeys.includes('monitoring_sla');

        mod.subMenus.forEach(sub => {
          if (isLegacyCrewDefault) {
            subMenuPerms[sub.id] = sub.id === 'driver_portal' || sub.id === 'portal_driver' ? 'full_access' : 'none';
          } else {
            let savedVal = userMod?.subMenus?.[sub.id];
            if (savedVal === undefined && userMod?.subMenus) {
              const legacyKeys = LEGACY_SUBMENU_KEY_MAP[sub.id];
              if (legacyKeys) {
                for (const lk of legacyKeys) {
                  if (userMod.subMenus[lk] !== undefined) {
                    savedVal = userMod.subMenus[lk];
                    break;
                  }
                }
              }
            }
            subMenuPerms[sub.id] = savedVal !== undefined ? savedVal : (defaultMod?.subMenus?.[sub.id] || 'none');
          }
        });
        const isEnabled = userMod !== undefined
          ? userMod.enabled
          : (defaultMod ? defaultMod.enabled : false);
        initialPerms[mod.id] = {
          enabled: isEnabled,
          subMenus: subMenuPerms
        };
      });

      const loadedBranchPerms = branchStore.getUserBranchPermissions(
        selectedUser.id,
        selectedUser.role,
        initialPerms,
        selectedUser.permissions?.branchPermissions
      );
      const syncedMergedPerms = computeMergedModulesFromBranches(loadedBranchPerms, selectedUser.role);
      setBranchPermissions(loadedBranchPerms);
      setEditingPermissions(syncedMergedPerms);
      // Cabang tertutup default hanya saat beralih ke user baru
      setExpandedBranches({});
      setExpandedModules({});
    }
  }, [selectedUser?.id, selectedUser?.role, branches.length]);

  const ROLE_LABELS: Record<UserRole, string> = {
    super_admin: 'Super Admin',
    dispatcher: 'SPV Logistik',
    spv_logistik: 'SPV Logistik',
    operasional: 'SPV Operasional',
    koordinator_driver: 'Koordinator Driver',
    security: 'Security',
    sales_admin: 'Adm. Penjualan',
    spv_sales_admin: 'SPV Adm Penjualan',
    purchasing_admin: 'Adm. Pembelian',
    spv_purchasing_admin: 'SPV Adm Pembelian',
    hr_admin: 'Human Resource Development',
    finance_tax_admin: 'Adm Finance & Tax',
    warehouse_admin: 'Gudang',
    koordinator_gudang: 'Koordinator Gudang',
    driver: 'Driver',
    marketing_online: 'Marketing Online',
    marketing_offline: 'Marketing Offline',
    spv_marketing_offline: 'SPV Marketing Offline',
    crew_helper: 'Helper',
    unassigned: 'Perlu Diisi (Belum Ada Role)'
  };

  const toggleBranchExpansion = (branchId: string) => {
    setExpandedBranches(prev => ({ ...prev, [branchId]: !prev[branchId] }));
  };

  const toggleBranchModuleExpansion = (branchId: string, modId: string) => {
    const key = `${branchId}:${modId}`;
    setExpandedModules(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleToggleBranchEnabled = (branchId: string, enabled: boolean) => {
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Hanya Super Admin yang berwenang mengubah akses cabang.', 'warning');
      return;
    }
    setBranchPermissions(prev => {
      const current = prev[branchId];
      if (!current) return prev;
      const roleDefaults = getDefaultPermissionsForRole(selectedUser?.role || 'unassigned');
      let nextModules = { ...current.modules };

      // If enabling a branch that currently has 0 active modules, populate from role defaults
      if (enabled && branchStore.countActiveModulesInBranch(nextModules) === 0) {
        nextModules = JSON.parse(JSON.stringify(roleDefaults));
      }

      const nextMap = {
        ...prev,
        [branchId]: {
          ...current,
          enabled,
          allAccess: enabled ? current.allAccess : false,
          modules: nextModules
        }
      };
      const merged = computeMergedModulesFromBranches(nextMap, selectedUser?.role || 'unassigned');
      setEditingPermissions(merged);
      if (selectedUser) {
        branchStore.saveUserBranchPermissions(selectedUser.id, nextMap);
        logisticsStore.updateUserProfile(selectedUser.id, {
          permissions: { modules: merged, branchPermissions: nextMap }
        });
      }
      return nextMap;
    });

    if (enabled) {
      setExpandedBranches(prev => ({ ...prev, [branchId]: true }));
    }
  };

  const handleToggleBranchAllAccess = (branchId: string, allAccess: boolean) => {
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Hanya Super Admin yang berwenang mengubah akses cabang.', 'warning');
      return;
    }
    setBranchPermissions(prev => {
      const current = prev[branchId];
      if (!current) return prev;
      const nextModules: UserPermissions['modules'] = {};

      MODULE_DEFINITIONS.forEach(mod => {
        const subMenus: Record<string, 'none' | 'read_only' | 'full_access'> = {};
        mod.subMenus.forEach(sub => {
          subMenus[sub.id] = allAccess ? 'full_access' : 'none';
        });
        nextModules[mod.id] = {
          enabled: allAccess,
          subMenus
        };
      });

      const nextMap = {
        ...prev,
        [branchId]: {
          ...current,
          enabled: allAccess ? true : current.enabled,
          allAccess,
          modules: nextModules
        }
      };
      const merged = computeMergedModulesFromBranches(nextMap, selectedUser?.role || 'unassigned');
      setEditingPermissions(merged);
      if (selectedUser) {
        branchStore.saveUserBranchPermissions(selectedUser.id, nextMap);
        logisticsStore.updateUserProfile(selectedUser.id, {
          permissions: { modules: merged, branchPermissions: nextMap }
        });
      }
      return nextMap;
    });

    if (allAccess) {
      setExpandedBranches(prev => ({ ...prev, [branchId]: true }));
    }
  };

  const handleToggleBranchModuleEnabled = (branchId: string, modId: string, enabled: boolean) => {
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Hanya Super Admin yang berwenang mengubah hak akses modul.', 'warning');
      return;
    }
    const modDef = MODULE_DEFINITIONS.find(m => m.id === modId);
    setBranchPermissions(prev => {
      const branchEntry = prev[branchId];
      if (!branchEntry) return prev;
      const existingSubMenus = { ...(branchEntry.modules[modId]?.subMenus || {}) };
      if (modDef) {
        modDef.subMenus.forEach(sub => {
          existingSubMenus[sub.id] = enabled ? 'full_access' : 'none';
        });
      }
      const nextModules = {
        ...branchEntry.modules,
        [modId]: {
          enabled,
          subMenus: existingSubMenus
        }
      };
      const activeModCount = branchStore.countActiveModulesInBranch(nextModules);
      const nextMap = {
        ...prev,
        [branchId]: {
          ...branchEntry,
          enabled: enabled ? true : activeModCount > 0,
          allAccess: activeModCount === MODULE_DEFINITIONS.length,
          modules: nextModules
        }
      };
      const merged = computeMergedModulesFromBranches(nextMap, selectedUser?.role || 'unassigned');
      setEditingPermissions(merged);
      if (selectedUser) {
        branchStore.saveUserBranchPermissions(selectedUser.id, nextMap);
        logisticsStore.updateUserProfile(selectedUser.id, {
          permissions: { modules: merged, branchPermissions: nextMap }
        });
      }
      return nextMap;
    });

    if (enabled) {
      setExpandedModules(prev => ({ ...prev, [`${branchId}:${modId}`]: true }));
    }
  };

  const handleBranchSubMenuPermissionChange = (
    branchId: string,
    modId: string,
    subId: string,
    accessLevel: 'none' | 'read_only' | 'full_access'
  ) => {
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Hanya Super Admin yang berwenang mengubah hak akses sub-menu.', 'warning');
      return;
    }
    setBranchPermissions(prev => {
      const branchEntry = prev[branchId];
      if (!branchEntry) return prev;
      const mod = branchEntry.modules[modId] || { enabled: true, subMenus: {} };
      const nextSubs = {
        ...mod.subMenus,
        [subId]: accessLevel
      };
      const hasAnyActiveSub = Object.values(nextSubs).some(v => v === 'full_access' || v === 'read_only');
      const nextModules = {
        ...branchEntry.modules,
        [modId]: {
          enabled: hasAnyActiveSub,
          subMenus: nextSubs
        }
      };
      const activeModCount = branchStore.countActiveModulesInBranch(nextModules);
      const nextMap = {
        ...prev,
        [branchId]: {
          ...branchEntry,
          enabled: activeModCount > 0,
          allAccess: activeModCount === MODULE_DEFINITIONS.length,
          modules: nextModules
        }
      };
      const merged = computeMergedModulesFromBranches(nextMap, selectedUser?.role || 'unassigned');
      setEditingPermissions(merged);
      if (selectedUser) {
        branchStore.saveUserBranchPermissions(selectedUser.id, nextMap);
        logisticsStore.updateUserProfile(selectedUser.id, {
          permissions: { modules: merged, branchPermissions: nextMap }
        });
      }
      return nextMap;
    });
  };

  const handleSaveAccess = () => {
    if (!selectedUser) return;
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Hanya Super Admin yang dapat menyimpan perubahan akses.', 'warning');
      return;
    }

    const mergedModules = computeMergedModulesFromBranches(branchPermissions, selectedUser.role);
    const updatedPermissions: UserPermissions = {
      modules: mergedModules,
      branchPermissions
    };

    branchStore.saveUserBranchPermissions(selectedUser.id, branchPermissions);
    const success = logisticsStore.updateUserProfile(selectedUser.id, {
      permissions: updatedPermissions
    });

    if (success) {
      showNotification('Hak Akses Disimpan', `Akses cabang dan rincian menu website untuk "${selectedUser.fullName}" berhasil disimpan ke sistem.`, 'success');
      setSaveSuccessMessage(`Akses cabang dan hak akses untuk "${selectedUser.fullName}" berhasil disimpan.`);
      setTimeout(() => setSaveSuccessMessage(null), 4000);
    }
  };

  const handleCopyAccess = () => {
    if (!sourceUserIdForCopy) {
      showNotification('Peringatan', 'Silakan pilih user sumber untuk menyalin akses.', 'warning');
      return;
    }
    const sourceUser = users.find(u => u.id === sourceUserIdForCopy);
    if (!sourceUser || !sourceUser.permissions) {
      showNotification('User Sumber Kosong', 'User sumber tidak memiliki konfigurasi akses khusus.', 'warning');
      return;
    }
    const copiedBranchPerms = branchStore.getUserBranchPermissions(
      sourceUser.id,
      sourceUser.role,
      sourceUser.permissions.modules,
      sourceUser.permissions.branchPermissions
    );
    setBranchPermissions(JSON.parse(JSON.stringify(copiedBranchPerms)));
    setEditingPermissions(JSON.parse(JSON.stringify(sourceUser.permissions.modules)));
    setIsCopyModalOpen(false);
    setSourceUserIdForCopy('');
    showNotification('Salin Akses Berhasil', `Berhasil menyalin hak akses dari ${sourceUser.fullName}. Klik 'Simpan Akses' di kanan bawah untuk menerapkan ke database.`, 'success');
  };

  const handleChangePassword = async () => {
    const target = passwordTargetUser || selectedUser;
    if (!target) return;
    if (!newPasswordInput || newPasswordInput.length < 8) {
      showNotification('Password Tidak Valid', 'Password baru minimal harus 8 karakter.', 'warning');
      return;
    }
    if (newPasswordInput !== confirmPasswordInput) {
      showNotification('Password Tidak Cocok', 'Konfirmasi password tidak cocok dengan password baru. Harap periksa kembali kedua input.', 'error');
      return;
    }
    const success = await logisticsStore.resetUserPassword(target.id, newPasswordInput);
    if (success) {
      showNotification('Password Berhasil Diubah', `Password baru untuk akun "${target.fullName}" (${target.email}) berhasil disimpan ke database.`, 'success');
      setSaveSuccessMessage(`Password akun "${target.fullName}" berhasil diubah.`);
      setTimeout(() => setSaveSuccessMessage(null), 4000);
      closePasswordModal();
    }
  };

  const handleApprove = (userId: string, notes?: string) => {
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Hanya Super Admin yang dapat menyetujui akun pengguna.', 'warning');
      return;
    }
    logisticsStore.approveUser(userId, notes || 'Disetujui oleh ' + currentUser.fullName);
    showNotification('Akun Disetujui', 'Akun pengguna berhasil disetujui dan kini berstatus aktif.', 'success');
  };

  const handleDeactivateUser = (user: UserProfile, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Hanya Super Admin yang dapat menonaktifkan akun pengguna.', 'warning');
      return;
    }
    const isPrimaryOrSelfSuperAdmin =
      user.id === currentUser.id ||
      (user.email || '').trim().toLowerCase() === 'akkoperasional60@gmail.com';
    if (user.role === 'super_admin' && isPrimaryOrSelfSuperAdmin) {
      showNotification('Tindakan Dibatasi', 'Akun utama Super Admin yang sedang aktif tidak dapat dinonaktifkan.', 'warning');
      return;
    }
    logisticsStore.deactivateUser(user.id);
    setSaveSuccessMessage(`Akun "${user.fullName}" berhasil dinonaktifkan. Hak akses ditutup, histori data tetap tersimpan.`);
    setTimeout(() => setSaveSuccessMessage(null), 5000);
    showNotification(
      'Akun Dinonaktifkan',
      `Akun "${user.fullName}" kini berstatus Nonaktif. Hak akses disembunyikan sementara, namun seluruh histori pengiriman & log aktivitas tetap tersimpan utuh.`,
      'warning'
    );
  };

  const handleActivateUser = (user: UserProfile, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Hanya Super Admin yang dapat mengaktifkan akun pengguna.', 'warning');
      return;
    }
    logisticsStore.activateUser(user.id);
    setSaveSuccessMessage(`Akun "${user.fullName}" berhasil diaktifkan kembali dan hak akses dipulihkan!`);
    setTimeout(() => setSaveSuccessMessage(null), 5000);
    showNotification(
      'Akun Diaktifkan Kembali',
      `Akun "${user.fullName}" telah aktif kembali. Pengaturan hak akses kini ditampilkan dan akun terbaca pada pemrosesan sistem ke depannya.`,
      'success'
    );
  };

  const handleDelete = (userId: string) => {
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Hanya Super Admin yang dapat menghapus akun pengguna.', 'warning');
      return;
    }
    
    setDeleteTargetId(userId);
    setIsDeleteModalOpen(true);
  };
  
  const confirmDelete = () => {
    if (!deleteTargetId) return;
    
    const target = users.find(u => u.id === deleteTargetId);
    logisticsStore.deleteUser(deleteTargetId);
    const remaining = users.filter(u => u.id !== deleteTargetId);
    if (remaining.length > 0) {
      setSelectedUserId(remaining[0].id);
    }
    
    setIsDeleteModalOpen(false);
    setDeleteTargetId(null);
    showNotification('Akun Dihapus', `Akun ${target?.fullName || 'pengguna'} telah berhasil dihapus dari sistem.`, 'success');
  };

  const handleOpenEdit = (user: UserProfile) => {
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Fitur edit profil hanya dapat diakses oleh Super Admin.', 'warning');
      return;
    }
    setEditingUser(user);
    setEditFormData({
      fullName: user.fullName || '',
      email: user.email || '',
      phone: user.phone || '',
      role: user.role,
      department: user.department || '',
      status: user.status,
      notes: user.notes || '',
      approvedBy: user.approvedBy || currentUser.fullName
    });
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    if (!isSuperAdmin) {
      showNotification('Akses Ditolak', 'Hanya Super Admin yang berwenang mengubah profil pengguna.', 'warning');
      return;
    }

    const roleChanged = editFormData.role !== editingUser.role;
    const success = logisticsStore.updateUserProfile(editingUser.id, {
      fullName: editFormData.fullName.trim(),
      email: editFormData.email.trim(),
      phone: editFormData.phone.trim(),
      role: editFormData.role,
      department: editFormData.department.trim(),
      status: editFormData.status,
      notes: editFormData.notes.trim(),
      approvedBy: editFormData.status === 'approved' ? (editFormData.approvedBy || currentUser.fullName) : editingUser.approvedBy
    });

    if (success) {
      const updatedUserObj = logisticsStore.getUsers().find(u => u.id === editingUser.id);
      if (updatedUserObj && roleChanged) {
        const syncedBranchPerms = branchStore.getUserBranchPermissions(
          updatedUserObj.id,
          updatedUserObj.role,
          updatedUserObj.permissions?.modules,
          updatedUserObj.permissions?.branchPermissions
        );
        branchStore.saveUserBranchPermissions(updatedUserObj.id, syncedBranchPerms);
        const mergedMods = computeMergedModulesFromBranches(syncedBranchPerms, updatedUserObj.role);
        logisticsStore.updateUserProfile(updatedUserObj.id, {
          permissions: {
            modules: mergedMods,
            branchPermissions: syncedBranchPerms
          }
        });
        if (selectedUserId === updatedUserObj.id) {
          prevLoadedUserIdRef.current = null;
          setBranchPermissions(syncedBranchPerms);
          setEditingPermissions(mergedMods);
        }
      }
      setSaveSuccessMessage(`Profil "${editFormData.fullName}" berhasil diperbarui.`);
      setTimeout(() => setSaveSuccessMessage(null), 4000);
      setEditingUser(null);
    }
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUser.email) return;
    if (!newUser.password || newUser.password.length < 8) {
      setPageModalNotification({
        title: 'Password Belum Valid',
        message: 'Saat membuat akun baru, masukkan password minimal 8 karakter. Password akan dikirim ke backend dan disimpan sebagai hash.',
        type: 'warning'
      });
      return;
    }

    const chosenRole: UserRole = newUser.role || 'unassigned';
    const isCrewRole = chosenRole === 'driver' || chosenRole === 'crew_helper';
    const preGeneratedId = 'usr-' + Math.random().toString(36).substring(2, 8);
    const initialBranchPerms = branchStore.getUserBranchPermissions(preGeneratedId, chosenRole);
    branchStore.saveUserBranchPermissions(preGeneratedId, initialBranchPerms);
    const mergedNewMods = computeMergedModulesFromBranches(initialBranchPerms, chosenRole);

    const created = logisticsStore.registerUser({
      id: preGeneratedId,
      fullName: newUser.fullName || 'Pengguna Baru',
      email: newUser.email,
      phone: (newUser.phone || '').trim(),
      role: chosenRole,
      department: newUser.department || 'Logistik & Pengiriman',
      password: newUser.password,
      status: chosenRole !== 'unassigned' ? 'approved' : 'pending',
      notes: isCrewRole
        ? `Akun ${chosenRole === 'driver' ? 'Driver' : 'Helper'} aktif`
        : chosenRole !== 'unassigned'
        ? `Akun aktif untuk role ${ROLE_LABELS[chosenRole] || chosenRole}`
        : 'Akun baru terdaftar — Role perlu diisi oleh Super Admin',
      permissions: {
        modules: mergedNewMods,
        branchPermissions: initialBranchPerms
      }
    });

    prevLoadedUserIdRef.current = null;
    setIsAddUserModalOpen(false);
    setSelectedUserId(created.id);
    setNewUser({
      fullName: '',
      email: '',
      phone: '',
      role: 'driver',
      password: '',
      department: 'Logistik & Pengiriman'
    });
    showNotification(
      isCrewRole ? 'Akun Kru Terdaftar & Sinkron ke Jadwal' : 'Akun Baru Terdaftar',
      isCrewRole
        ? `Akun "${created.fullName}" (${ROLE_LABELS[chosenRole]}) berhasil dibuat dan otomatis masuk ke dalam daftar pilihan ${chosenRole === 'driver' ? 'Driver' : 'Helper'} pada menu Jadwal & Penugasan Pengiriman.`
        : `Akun "${created.fullName}" berhasil dibuat dengan Role: ${ROLE_LABELS[chosenRole] || chosenRole}.`,
      'success'
    );
  };

  const pendingCount = visibleUsersForRole.filter(u => u.status === 'pending').length;
  const approvedCount = visibleUsersForRole.filter(u => u.status === 'approved').length;
  const inactiveCount = visibleUsersForRole.filter(u => u.status === 'inactive').length;
  const rejectedCount = visibleUsersForRole.filter(u => u.status === 'rejected').length;

  const matchUserDepartment = (u: UserProfile, filterKey: string) => {
    if (filterKey === 'all') return true;
    const dept = (u.department || '').toLowerCase();
    const role = (u.role || '').toLowerCase();
    switch (filterKey) {
      case 'logistics':
        return (
          role === 'spv_logistik' ||
          role === 'operasional' ||
          role === 'koordinator_driver' ||
          role === 'driver' ||
          role === 'crew_helper' ||
          /logistik|pengiriman|distribusi|armada|supir|operasional/i.test(dept) ||
          (role !== 'super_admin' && canAccess(u, 'logistics'))
        );
      case 'sales':
        return (
          role === 'sales_admin' ||
          role === 'spv_sales_admin' ||
          /sales|penjualan/i.test(dept) ||
          (role !== 'super_admin' && canAccess(u, 'sales_admin'))
        );
      case 'warehouse':
        return (
          role === 'warehouse_admin' ||
          role === 'koordinator_gudang' ||
          /gudang|warehouse/i.test(dept) ||
          (role !== 'super_admin' && canAccess(u, 'warehouse'))
        );
      case 'marketing':
        return (
          role === 'marketing_online' ||
          role === 'marketing_offline' ||
          role === 'spv_marketing_offline' ||
          /marketing|pemasaran/i.test(dept) ||
          (role !== 'super_admin' && canAccess(u, 'marketing'))
        );
      case 'purchasing':
        return (
          role === 'purchasing_admin' ||
          role === 'spv_purchasing_admin' ||
          /pembelian|purchasing|pengadaan/i.test(dept) ||
          (role !== 'super_admin' && canAccess(u, 'purchasing'))
        );
      case 'finance':
        return (
          role === 'finance_tax_admin' ||
          /finance|tax|keuangan|pajak/i.test(dept) ||
          (role !== 'super_admin' && canAccess(u, 'finance_tax'))
        );
      case 'hr':
        return (
          role === 'hr_admin' ||
          role === 'security' ||
          /hr|human|ga|personalia|general affair|satpam|keamanan/i.test(dept) ||
          (role !== 'super_admin' && canAccess(u, 'hr'))
        );
      case 'super_admin':
        return role === 'super_admin' || /super|direksi|manajemen/i.test(dept);
      default:
        return role === filterKey || dept.includes(filterKey.toLowerCase());
    }
  };

  const countUsersInDept = (deptId: string) => {
    if (deptId === 'all') return visibleUsersForRole.length;
    return visibleUsersForRole.filter(u => matchUserDepartment(u, deptId)).length;
  };

  const filteredUsers = visibleUsersForRole.filter(u => {
    const matchesStatus = statusFilter === 'all' || u.status === statusFilter;
    const matchesDept = matchUserDepartment(u, departmentFilter);
    const matchesQuery =
      u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.role.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesDept && matchesQuery;
  });

  // Auto-select first matching user if current selected user is filtered out (only when no modal is open)
  useEffect(() => {
    if (!isSuperAdmin && statusFilter === 'inactive') {
      setStatusFilter('all');
    }
    if (isPasswordModalOpen || Boolean(editingUser) || isDeleteModalOpen || isCopyModalOpen) {
      return;
    }
    if (filteredUsers.length > 0) {
      const isSelectedPresent = filteredUsers.some(u => u.id === selectedUserId);
      if (!isSelectedPresent) {
        setSelectedUserId(filteredUsers[0].id);
      }
    }
  }, [departmentFilter, statusFilter, searchQuery, isSuperAdmin, visibleUsersForRole.length, isPasswordModalOpen, editingUser, isDeleteModalOpen, isCopyModalOpen]);

  const activeDeptOption = DEPARTMENT_FILTER_OPTIONS.find(opt => opt.id === departmentFilter);

  return (
    <div className="space-y-5">
      {/* RBAC Header & Schedule Integration Summary */}
      <div className={`p-4 sm:p-5 rounded-2xl border flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-sm bg-slate-900 ${
        isSuperAdmin
          ? 'border-amber-500/40'
          : 'border-slate-800'
      }`}>
        <div className="flex items-start sm:items-center gap-3.5">
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${
            isSuperAdmin
              ? 'bg-amber-500/15 border-amber-500/40 text-amber-400 shadow-xs'
              : 'bg-slate-800 border-slate-700 text-slate-400'
          }`}>
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="font-extrabold text-white text-sm sm:text-base flex items-center gap-2 flex-wrap">
              <span>{isSuperAdmin ? 'Manajemen User & Hak Akses Cabang' : 'Hak Akses Pengguna Terbatas'}</span>
              <span className={`px-2.5 py-0.5 rounded-md text-[10px] font-black uppercase border ${
                isSuperAdmin
                  ? 'bg-amber-500/15 text-amber-400 border-amber-500/40'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}>
                {isSuperAdmin ? '👑 Super Admin' : '🔒 Read Only'}
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-400 mt-1 leading-relaxed">
              {isSuperAdmin
                ? 'Pengaturan akun pengguna, pembagian akses cabang (Sidoarjo & Nusantara), serta kontrol hak akses modul sistem.'
                : `Manajemen user dan perubahan hak akses dikunci khusus untuk Super Admin. Anda login sebagai: ${currentUser.fullName} (${currentUser.role}).`}
            </p>
          </div>
        </div>
      </div>

      {/* Save Success Alert Banner */}
      {saveSuccessMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-400 text-xs flex items-center justify-between shadow-sm animate-in fade-in duration-200">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-semibold">{saveSuccessMessage}</span>
          </div>
          <button
            onClick={() => setSaveSuccessMessage(null)}
            className="p-1 text-emerald-400 hover:text-white rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Toolbar: Add User & Search / Filter */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xs">
        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={() => setIsAddUserModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-xs transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah User Langsung</span>
          </button>

          {/* Department / Role Filter Custom Dropdown in Top Toolbar */}
          <div ref={deptFilterRef} className="relative">
            <button
              type="button"
              onClick={() => setIsDeptFilterOpen(prev => !prev)}
              className={`flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-xl border text-xs transition cursor-pointer ${
                isDeptFilterOpen
                  ? 'border-amber-500 ring-2 ring-amber-500/20'
                  : 'border-slate-800 hover:border-slate-600'
              }`}
            >
              <Filter className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="text-slate-400 font-semibold text-[11px] hidden sm:inline">Role / Dept:</span>
              <span className="text-amber-400 font-bold text-xs">
                {activeDeptOption?.label || 'Semua Role / Departemen'} ({countUsersInDept(departmentFilter)})
              </span>
              <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isDeptFilterOpen ? 'rotate-180 text-amber-400' : ''}`} />
            </button>

            {isDeptFilterOpen && (
              <div className="absolute left-0 mt-1.5 w-72 z-[70] rounded-2xl bg-slate-900 border border-slate-700/90 shadow-2xl shadow-black/70 p-1.5 space-y-0.5 animate-in fade-in slide-in-from-top-1 duration-150">
                {DEPARTMENT_FILTER_OPTIONS.map(opt => {
                  const OptIcon = opt.Icon;
                  const active = departmentFilter === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        setDepartmentFilter(opt.id);
                        setIsDeptFilterOpen(false);
                      }}
                      className={`w-full px-2.5 py-2 rounded-xl flex items-center justify-between gap-2 text-left transition cursor-pointer ${
                        active
                          ? 'bg-amber-500/15 border border-amber-500/40 text-amber-300'
                          : 'border border-transparent hover:bg-slate-800/80 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${opt.tone}`}>
                          <OptIcon className="w-3.5 h-3.5" />
                        </span>
                        <span className="text-xs font-semibold truncate">{opt.label}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold tabular-nums ${active ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'}`}>
                        {countUsersInDept(opt.id)}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap w-full lg:w-auto">
          {/* Status Filter Tabs */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs overflow-x-auto">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-2.5 py-1.5 rounded-md font-semibold transition cursor-pointer whitespace-nowrap ${
                statusFilter === 'all' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Semua ({visibleUsersForRole.length})
            </button>
            <button
              onClick={() => setStatusFilter('pending')}
              className={`px-2.5 py-1.5 rounded-md font-semibold transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                statusFilter === 'pending' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Pending</span>
              {pendingCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-400 text-slate-950">
                  {pendingCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setStatusFilter('approved')}
              className={`px-2.5 py-1.5 rounded-md font-semibold transition cursor-pointer whitespace-nowrap ${
                statusFilter === 'approved' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Aktif ({approvedCount})
            </button>
            {isSuperAdmin && (
              <button
                onClick={() => setStatusFilter('inactive')}
                className={`px-2.5 py-1.5 rounded-md font-semibold transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                  statusFilter === 'inactive' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>Nonaktif ({inactiveCount})</span>
              </button>
            )}
          </div>

          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <input
              type="search"
              name="akk_user_directory_search_filter"
              autoComplete="off"
              autoCorrect="off"
              autoCapitalize="off"
              spellCheck={false}
              data-lpignore="true"
              data-1p-ignore="true"
              data-form-type="other"
              placeholder="Cari nama, email, divisi..."
              value={searchQuery}
              onChange={(e) => {
                // Ignore background browser credential autofill when input is not focused
                if (document.activeElement !== e.currentTarget && e.target.value.includes('@')) {
                  return;
                }
                setSearchQuery(e.target.value);
              }}
              className="w-full pl-9 pr-7 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5 cursor-pointer"
                title="Bersihkan pencarian"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ================= SPLIT SCREEN MASTER-DETAIL LAYOUT ================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        
        {/* LEFT COLUMN: Modern & Crisp User List */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xs flex flex-col max-h-[82vh]">
          {/* Header */}
          <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-white text-xs flex items-center gap-2">
              <Users className="w-4 h-4 text-amber-400" />
              <span>Daftar Pengguna ({filteredUsers.length})</span>
            </h3>
            {departmentFilter !== 'all' ? (
              <button
                type="button"
                onClick={() => setDepartmentFilter('all')}
                className="text-amber-400 hover:text-amber-300 font-bold text-[10px] flex items-center gap-1 cursor-pointer bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30 transition"
              >
                <X className="w-3 h-3" />
                <span>Reset Filter</span>
              </button>
            ) : (
              <span className="text-[10px] text-slate-400 font-medium">Pilih akun untuk rincian</span>
            )}
          </div>

          <div className="overflow-y-auto p-2 space-y-1.5 flex-1">
            {filteredUsers.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                Tidak ada user yang ditemukan.
              </div>
            ) : (
              filteredUsers.map(user => {
                const isSelected = selectedUser?.id === user.id;
                const isCurrent = user.id === currentUser.id;
                const isInactive = user.status === 'inactive';

                return (
                  <div
                    key={user.id}
                    onClick={() => setSelectedUserId(user.id)}
                    className={`p-3 rounded-xl border transition cursor-pointer flex items-center justify-between gap-2.5 ${
                      isSelected 
                        ? 'bg-amber-500/15 border-amber-500/50 shadow-xs' 
                        : isInactive
                        ? 'bg-slate-950/70 border-slate-800/70 hover:bg-slate-800/50 opacity-75'
                        : 'bg-slate-950/40 border-slate-800/80 hover:bg-slate-800/70 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-extrabold text-xs shrink-0 shadow-xs border ${
                        isSelected
                          ? 'bg-amber-500 text-slate-950 border-amber-400'
                          : isInactive
                          ? 'bg-slate-800 text-slate-500 border-slate-700'
                          : user.role === 'super_admin'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : user.role === 'driver' || user.role === 'crew_helper'
                          ? 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                          : 'bg-slate-800 text-slate-200 border-slate-700'
                      }`}>
                        {user.fullName === 'Super Admin' ? '👑' : user.fullName.substring(0, 2).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <div className="font-bold text-xs leading-snug flex items-center gap-1.5 flex-wrap">
                          <span className={isSelected ? 'text-amber-400 font-extrabold' : isInactive ? 'text-slate-400 line-through' : 'text-white'}>
                            {user.fullName}
                          </span>
                          {isCurrent && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30 shrink-0">
                              Anda
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] mt-0.5 flex items-center gap-1.5 flex-wrap">
                          {user.role === 'unassigned' ? (
                            <span className="text-rose-400 font-bold text-[10px]">
                              ⚠️ Perlu Diisi Role
                            </span>
                          ) : (
                            <span className="text-slate-400 font-medium">{ROLE_LABELS[user.role] || user.role}</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0">
                      {user.status === 'approved' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          Aktif
                        </span>
                      )}
                      {user.status === 'inactive' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                          Nonaktif
                        </span>
                      )}
                      {user.status === 'pending' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
                          Pending
                        </span>
                      )}
                      {user.status === 'rejected' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/40">
                          Ditolak
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Selected User Details, Password & Menu/Submenu Granular Access */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xs flex flex-col">
          {selectedUser ? (
            <>
              {/* Selected User Header Banner */}
              <div className="p-5 bg-slate-950 border-b border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3.5">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-extrabold text-sm shadow-xs shrink-0 border ${
                      selectedUser.status === 'inactive'
                        ? 'bg-slate-800 border-slate-700 text-slate-400'
                        : 'bg-amber-600 border-amber-500 text-white'
                    }`}>
                      {selectedUser.fullName === 'Super Admin' ? '👑' : selectedUser.fullName.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-base font-extrabold text-white">
                          {selectedUser.fullName}
                        </h3>
                        <span className={`px-2.5 py-0.5 rounded-md text-[10px] font-extrabold border ${
                          selectedUser.role === 'unassigned'
                            ? 'bg-rose-500/15 text-rose-400 border-rose-500/40'
                            : 'bg-amber-500/15 text-amber-400 border-amber-500/40'
                        }`}>
                          {ROLE_LABELS[selectedUser.role] || selectedUser.role}
                        </span>
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                          selectedUser.status === 'approved'
                            ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/40'
                            : selectedUser.status === 'inactive'
                            ? 'bg-rose-500/15 text-rose-400 border-rose-500/40'
                            : 'bg-amber-500/15 text-amber-400 border-amber-500/40'
                        }`}>
                          {selectedUser.status === 'approved' ? '🟢 Status: Aktif' : selectedUser.status === 'inactive' ? '🔴 Status: Nonaktif' : '🟡 Status: Pending'}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 flex items-center gap-3.5 mt-1.5 flex-wrap font-medium">
                        <span className="flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-amber-400" />
                          <span>{selectedUser.email}</span>
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Building className="w-3.5 h-3.5 text-blue-400" />
                          <span>{selectedUser.department || 'Perlu Diisi'}</span>
                        </span>
                        {(() => {
                          const rawPhone = String(selectedUser.phone || '').trim();
                          const digits = rawPhone.replace(/\D/g, '');
                          const isPlaceholder =
                            !digits ||
                            digits.length < 9 ||
                            digits === '081234567890' ||
                            digits === '6281234567890' ||
                            digits === '081200000000' ||
                            digits === '6281200000000';
                          return (
                            <span
                              className="flex items-center gap-1.5"
                              title="Nomor WhatsApp ini terhubung langsung ke fitur Lupa Password OTP WhatsApp"
                            >
                              <Phone className={`w-3.5 h-3.5 ${isPlaceholder ? 'text-slate-500' : 'text-emerald-400'}`} />
                              {isPlaceholder ? (
                                <span className="text-amber-400/90 font-semibold">No. WA belum diisi</span>
                              ) : (
                                <>
                                  <span className="text-slate-200 font-mono font-semibold">{rawPhone}</span>
                                  <span className="px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                                    OTP WA Aktif
                                  </span>
                                </>
                              )}
                            </span>
                          );
                        })()}
                      </div>
                    </div>
                  </div>

                  {/* User Actions in Detail View: Masuk Role, Edit & Aktifkan/Nonaktifkan */}
                  <div className="flex items-center gap-2 self-end sm:self-auto flex-wrap">
                    {selectedUser.status === 'approved' && (
                      <button
                        onClick={() => {
                          if (isSuperAdmin) {
                            const merged = computeMergedModulesFromBranches(branchPermissions, selectedUser.role);
                            branchStore.saveUserBranchPermissions(selectedUser.id, branchPermissions);
                            logisticsStore.updateUserProfile(selectedUser.id, {
                              permissions: { modules: merged, branchPermissions }
                            });
                          }
                          logisticsStore.switchCurrentUser(selectedUser.id);
                        }}
                        className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
                        title={`Masuk sebagai ${selectedUser.fullName} dan buka menu ${ROLE_LABELS[selectedUser.role] || selectedUser.role}`}
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Masuk &amp; Buka Menu Role</span>
                      </button>
                    )}
                    {isSuperAdmin && (
                      <button
                        onClick={() => handleOpenEdit(selectedUser)}
                        className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
                        title={`Edit Data ${selectedUser.fullName} (${ROLE_LABELS[selectedUser.role] || selectedUser.role})`}
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Edit Pengguna</span>
                      </button>
                    )}
                    {isSuperAdmin && !(selectedUser.role === 'super_admin' && (selectedUser.id === currentUser.id || (selectedUser.email || '').trim().toLowerCase() === 'akkoperasional60@gmail.com')) && (
                      selectedUser.status === 'inactive' ? (
                        <button
                          onClick={() => handleActivateUser(selectedUser)}
                          className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
                        >
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Aktifkan User</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleDeactivateUser(selectedUser)}
                          className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
                        >
                          <UserX className="w-3.5 h-3.5" />
                          <span>Nonaktifkan User</span>
                        </button>
                      )
                    )}
                    {selectedUser.status === 'pending' && isSuperAdmin && (
                      <button
                        onClick={() => handleApprove(selectedUser.id)}
                        className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer shadow-xs active:scale-95"
                      >
                        Setujui Akun
                      </button>
                    )}
                  </div>
                </div>

                {/* Dedicated Password & Credentials Bar for Selected User */}
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-2xs">
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                      <Key className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block font-bold">
                        Kata Sandi / Password Akun ({selectedUser.email}):
                      </span>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <code className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 font-mono font-extrabold text-amber-400 text-xs tracking-wider">
                          {visiblePasswords[selectedUser.id] ? getEffectivePassword(selectedUser) : '••••••••••••'}
                        </code>
                        <button
                          type="button"
                          onClick={() => togglePasswordVisibility(selectedUser.id)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-blue-400 font-bold text-[11px] flex items-center gap-1.5 transition cursor-pointer border border-slate-700"
                        >
                          {visiblePasswords[selectedUser.id] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          <span>{visiblePasswords[selectedUser.id] ? 'Sembunyikan Password' : 'Lihat Password'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCopyUserPassword(selectedUser)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-[11px] flex items-center gap-1.5 transition cursor-pointer border border-slate-700"
                        >
                          {copiedPasswordUserId === selectedUser.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedPasswordUserId === selectedUser.id ? 'Tersalin' : 'Salin'}</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {isSuperAdmin && (
                    <button
                      type="button"
                      onClick={() => openPasswordModalForUser(selectedUser)}
                      className="px-3.5 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/40 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer self-end sm:self-auto"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Ubah Password</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Conditional Content: Hide Hak Akses if User is Inactive */}
              {selectedUser.status === 'inactive' ? (
                <div className="p-6 space-y-5 text-xs flex-1 bg-slate-950/40">
                  <div className="p-5 rounded-2xl bg-rose-950/20 border border-rose-500/30 space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
                        <Lock className="w-5 h-5" />
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          <span>Hak Akses Tidak Ditampilkan (Akun Nonaktif)</span>
                        </h4>
                        <p className="text-slate-300 leading-relaxed text-xs">
                          Akun <strong className="text-amber-300">{selectedUser.fullName}</strong> saat ini berstatus <strong className="text-rose-400">NONAKTIF</strong>. Sesuai aturan integrasi sistem, pengaturan dan daftar hak akses tidak dimunculkan serta tidak dapat digunakan untuk pemrosesan operasional baru sampai akun ini diaktifkan kembali.
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                        <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Histori Data Tetap Terlihat</span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          Seluruh riwayat jadwal pengiriman, surat jalan, laporan aktivitas, dan log audit milik <strong>{selectedUser.fullName}</strong> tetap tersimpan utuh dan terlihat di sistem.
                        </p>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                        <div className="font-bold text-amber-400 flex items-center gap-1.5">
                          <ShieldAlert className="w-3.5 h-3.5" />
                          <span>Pemrosesan Sistem Ke Depan</span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          Hanya akun berstatus <strong>Aktif</strong> yang akan terbaca pada pemrosesan sistem ke depannya. Aktifkan kembali akun ini untuk memulihkan hak akses.
                        </p>
                      </div>
                    </div>

                    {isSuperAdmin && (
                      <div className="pt-2 flex items-center justify-end">
                        <button
                          type="button"
                          onClick={() => handleActivateUser(selectedUser)}
                          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/25 transition cursor-pointer active:scale-95"
                        >
                          <UserCheck className="w-4 h-4" />
                          <span>Aktifkan Kembali Akun &amp; Tampilkan Hak Akses</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Preserved History Data Preview for Inactive User */}
                  <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2.5">
                    <div className="font-bold text-slate-200 flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-amber-400" />
                        <span>Arsip &amp; Histori Data Pengguna ({selectedUser.fullName})</span>
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-bold">
                        Data Historis Tersimpan
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-[11px]">
                      <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                        <span className="text-slate-400 block">ID Akun &amp; Departemen</span>
                        <strong className="text-white">{selectedUser.id} &bull; {selectedUser.department || '-'}</strong>
                      </div>
                      <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                        <span className="text-slate-400 block">Role Terakhir</span>
                        <strong className="text-amber-300">{ROLE_LABELS[selectedUser.role] || selectedUser.role}</strong>
                      </div>
                      <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                        <span className="text-slate-400 block">Catatan Status</span>
                        <strong className="text-slate-300">{selectedUser.notes || 'Akun dinonaktifkan sementara'}</strong>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  {/* Role Unassigned Warning Banner if role is 'unassigned' */}
                  {selectedUser.role === 'unassigned' && (
                    <div className="mx-5 mt-4 p-3.5 rounded-xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2.5">
                        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                        <div>
                          <strong className="text-amber-300 block">Role Akun Baru Belum Diisi (Perlu Diisi)</strong>
                          <span className="text-slate-300 text-[11px]">
                            Akun baru tidak otomatis menjadi SPV Logistik. Silakan klik <strong>Edit Pengguna</strong> untuk memilih Role dan Departemen yang sesuai.
                          </span>
                        </div>
                      </div>
                      {isSuperAdmin && (
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(selectedUser)}
                          className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shrink-0 cursor-pointer"
                        >
                          Isi Role Sekarang
                        </button>
                      )}
                    </div>
                  )}

                  {/* AKSES CABANG & MENU WEBSITE SECTION — Matches image_22fe4cd6.png & image_a6bb64da.png */}
                  <div className="p-5 space-y-4 max-h-[68vh] overflow-y-auto text-xs bg-slate-950/30">
                    {/* Top Header Row: AKSES CABANG & Controls */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-black uppercase tracking-widest text-slate-400">
                          AKSES CABANG
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold flex items-center gap-1">
                          🔒 Terkunci Saat Edit (Tidak Otomatis Tertutup)
                        </span>
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          type="button"
                          onClick={handleExpandAllBranches}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-bold text-[10px] transition cursor-pointer"
                          title="Buka semua kartu cabang"
                        >
                          Buka Semua
                        </button>
                        <button
                          type="button"
                          onClick={handleCollapseAllBranches}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-bold text-[10px] transition cursor-pointer"
                          title="Tutup semua kartu cabang"
                        >
                          Tutup Semua
                        </button>
                        <button
                          type="button"
                          onClick={() => setIsCopyModalOpen(true)}
                          className="px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-bold text-[10px] flex items-center gap-1.5 transition cursor-pointer shrink-0"
                          title="Salin hak akses dari user lain"
                        >
                          <Copy className="w-3 h-3" />
                          <span>Copy Akses</span>
                        </button>
                      </div>
                    </div>

                    {/* Branch Accordion Cards */}
                    <div className="space-y-3">
                      {branches.map(branch => {
                        const bEntry = branchPermissions[branch.id] || {
                          branchId: branch.id,
                          enabled: false,
                          allAccess: false,
                          modules: {}
                        };
                        const isBranchExpanded = Boolean(expandedBranches[branch.id]);
                        const activeModCount = bEntry.enabled
                          ? branchStore.countActiveModulesInBranch(bEntry.modules)
                          : 0;

                        return (
                          <div
                            key={branch.id}
                            className={`rounded-2xl border transition overflow-hidden ${
                              bEntry.enabled
                                ? 'bg-slate-900/90 border-slate-700/90 shadow-xs'
                                : 'bg-slate-900/50 border-slate-800/80'
                            }`}
                          >
                            {/* Branch Card Header Row (matches image_22fe4cd6.png) */}
                            <div
                              onClick={() => toggleBranchExpansion(branch.id)}
                              className="p-4 flex flex-wrap items-center justify-between gap-3 cursor-pointer hover:bg-slate-800/40 transition select-none"
                            >
                              <div className="flex flex-wrap items-center gap-2.5">
                                {/* Branch Checkbox Pill */}
                                <label
                                  onClick={e => e.stopPropagation()}
                                  className={`inline-flex items-center gap-2.5 px-3.5 py-2 rounded-xl border font-extrabold text-xs transition cursor-pointer ${
                                    bEntry.enabled
                                      ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                                  }`}
                                >
                                  <input
                                    type="checkbox"
                                    checked={bEntry.enabled}
                                    onChange={e => handleToggleBranchEnabled(branch.id, e.target.checked)}
                                    disabled={!isSuperAdmin}
                                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                                  />
                                  <span>{branch.name}</span>
                                </label>

                                {/* "Semua akses cabang ini" Checkbox Pill */}
                                <label
                                  onClick={e => e.stopPropagation()}
                                  className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border font-bold text-xs transition cursor-pointer ${
                                    bEntry.allAccess
                                      ? 'bg-blue-500/20 border-blue-500/40 text-blue-300'
                                      : 'bg-blue-500/10 border-blue-500/20 text-blue-400 hover:bg-blue-500/15'
                                  }`}
                                >
                                  <input
                                    type="checkbox"
                                    checked={bEntry.allAccess}
                                    onChange={e => handleToggleBranchAllAccess(branch.id, e.target.checked)}
                                    disabled={!isSuperAdmin}
                                    className="w-3.5 h-3.5 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                                  />
                                  <span>Semua akses cabang ini</span>
                                </label>

                                {/* Active Access Count Badge */}
                                <span
                                  className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                                    activeModCount > 0
                                      ? 'bg-slate-800 text-slate-200 border border-slate-700'
                                      : 'bg-slate-950 text-slate-500 border border-slate-800'
                                  }`}
                                >
                                  {activeModCount} AKSES AKTIF
                                </span>
                              </div>

                              <button
                                type="button"
                                onClick={e => {
                                  e.stopPropagation();
                                  toggleBranchExpansion(branch.id);
                                }}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
                                title={isBranchExpanded ? 'Tutup Menu Cabang' : 'Buka Menu Website Cabang Ini'}
                              >
                                {isBranchExpanded ? (
                                  <ChevronUp className="w-4 h-4 text-blue-400" />
                                ) : (
                                  <ChevronDown className="w-4 h-4" />
                                )}
                              </button>
                            </div>

                            {/* Expanded Website Menu Modules inside this Branch (matches image_a6bb64da.png) */}
                            {isBranchExpanded && (
                              <div className="px-4 pb-4 pt-1 space-y-2.5 border-t border-slate-800/80 bg-slate-950/50">
                                {MODULE_DEFINITIONS.map(mod => {
                                  const modState = bEntry.modules?.[mod.id] || {
                                    enabled: false,
                                    subMenus: {}
                                  };
                                  const modKey = `${branch.id}:${mod.id}`;
                                  const isModExpanded = Boolean(expandedModules[modKey]);
                                  const activeSubCount = branchStore.countActiveSubMenusInModule(modState);
                                  const IconComp = mod.IconComp;

                                  return (
                                    <div
                                      key={mod.id}
                                      className={`rounded-2xl border bg-slate-900/90 transition overflow-hidden ${mod.borderClass}`}
                                    >
                                      {/* Website Module Header Card */}
                                      <div
                                        onClick={() => toggleBranchModuleExpansion(branch.id, mod.id)}
                                        className="p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-800/40 transition select-none"
                                      >
                                        <div className="flex items-center gap-3 min-w-0">
                                          <div
                                            className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${mod.iconBgClass}`}
                                          >
                                            <IconComp className="w-4 h-4" />
                                          </div>
                                          <div className="min-w-0">
                                            <div className="font-black text-white text-xs sm:text-sm flex items-center gap-2">
                                              <span>{mod.name}</span>
                                            </div>
                                            <p className="text-[11px] text-slate-400 truncate">
                                              {mod.description}
                                            </p>
                                          </div>
                                        </div>

                                        <div className="flex items-center gap-2.5 shrink-0">
                                          <span
                                            className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                                              activeSubCount > 0
                                                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                                                : 'bg-slate-950 text-slate-400 border-slate-800'
                                            }`}
                                          >
                                            {activeSubCount} AKSES
                                          </span>
                                          {isModExpanded ? (
                                            <ChevronUp className="w-4 h-4 text-slate-300" />
                                          ) : (
                                            <ChevronDown className="w-4 h-4 text-slate-400" />
                                          )}
                                        </div>
                                      </div>

                                      {/* Expanded Sub-Menus inside Module */}
                                      {isModExpanded && (
                                        <div className="px-4 pb-3.5 pt-2.5 border-t border-slate-800/80 bg-slate-950/60 space-y-2.5">
                                          <div className="flex items-center justify-between pb-2 border-b border-slate-800/70">
                                            <label className="inline-flex items-center gap-2 text-xs font-bold text-amber-300 cursor-pointer">
                                              <input
                                                type="checkbox"
                                                checked={modState.enabled && mod.subMenus.length > 0 && activeSubCount === mod.subMenus.length}
                                                onChange={e =>
                                                  handleToggleBranchModuleEnabled(
                                                    branch.id,
                                                    mod.id,
                                                    e.target.checked
                                                  )
                                                }
                                                disabled={!isSuperAdmin}
                                                className="w-4 h-4 rounded text-amber-500 cursor-pointer"
                                              />
                                              <span>Aktifkan Semua Sub-Menu {mod.name} ({branch.name})</span>
                                            </label>
                                          </div>

                                          <div className="divide-y divide-slate-800/60 space-y-2">
                                            {mod.subMenus.map(sub => {
                                              const accessLevel = modState.subMenus?.[sub.id] || 'none';
                                              const isSubActive = accessLevel !== 'none';

                                              return (
                                                <div
                                                  key={sub.id}
                                                  className="pt-2 first:pt-0 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                                                >
                                                  <label className="flex items-center gap-2.5 cursor-pointer">
                                                    <input
                                                      type="checkbox"
                                                      checked={isSubActive}
                                                      onChange={e =>
                                                        handleBranchSubMenuPermissionChange(
                                                          branch.id,
                                                          mod.id,
                                                          sub.id,
                                                          e.target.checked ? 'full_access' : 'none'
                                                        )
                                                      }
                                                      disabled={!isSuperAdmin}
                                                      className="w-3.5 h-3.5 rounded bg-slate-900 border-slate-700 text-amber-500 cursor-pointer"
                                                    />
                                                    <span
                                                      className={
                                                        isSubActive
                                                          ? 'text-slate-200 font-semibold'
                                                          : 'text-slate-500'
                                                      }
                                                    >
                                                      {sub.name}
                                                    </span>
                                                  </label>

                                                  {isSubActive && (
                                                    <div className="flex items-center gap-1.5 self-end sm:self-auto">
                                                      <span className="text-[10px] text-slate-400 shrink-0">
                                                        Akses Input:
                                                      </span>
                                                      <div className="w-36">
                                                        <CustomSelectDropdown
                                                          value={accessLevel}
                                                          onChange={val =>
                                                            handleBranchSubMenuPermissionChange(
                                                              branch.id,
                                                              mod.id,
                                                              sub.id,
                                                              val as 'none' | 'read_only' | 'full_access'
                                                            )
                                                          }
                                                          options={ACCESS_LEVEL_DROPDOWN_OPTIONS}
                                                          disabled={!isSuperAdmin}
                                                          compact
                                                          minMenuWidth={195}
                                                        />
                                                      </div>
                                                    </div>
                                                  )}
                                                </div>
                                              );
                                            })}
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Bottom Right Actions Footer (Copy Akses, Ubah Password, Simpan Akses, Hapus) */}
                  <div className="p-4 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      {isSuperAdmin && (
                        <>
                          <button
                            type="button"
                            onClick={() => openPasswordModalForUser(selectedUser)}
                            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 font-bold flex items-center gap-1.5 transition cursor-pointer border border-slate-700 text-xs shadow-xs"
                            title="Ubah password akun apabila user lupa password"
                          >
                            <Key className="w-4 h-4 text-amber-400" />
                            <span>Ubah Password</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDelete(selectedUser.id)}
                            className="px-3.5 py-2 rounded-xl bg-rose-950/50 hover:bg-rose-900 text-rose-300 font-bold flex items-center gap-1.5 transition cursor-pointer border border-rose-950 text-xs shadow-xs"
                            title="Hapus akun dari sistem"
                          >
                            <XCircle className="w-4 h-4 text-rose-400" />
                            <span>Hapus Akun</span>
                          </button>
                        </>
                      )}
                    </div>

                    {isSuperAdmin && (
                      <button
                        type="button"
                        onClick={handleSaveAccess}
                        className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center gap-1.5 shadow-lg shadow-amber-500/20 transition cursor-pointer active:scale-95 text-xs self-end sm:self-auto"
                      >
                        <Save className="w-4 h-4" />
                        <span>Simpan Akses</span>
                      </button>
                    )}
                  </div>
                </>
              )}
            </>
          ) : (
            <div className="p-12 text-center text-slate-500 text-xs">
              Pilih pengguna di sebelah kiri untuk melihat rincian hak akses.
            </div>
          )}
        </div>

      </div>

      {/* ================= COPY ACCESS SUB-MODAL ================= */}
      {isCopyModalOpen && (
        <div className="fixed inset-0 z-60 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-sm p-5 space-y-4 shadow-2xl">
            <h4 className="font-bold text-white text-sm flex items-center gap-2">
              <Copy className="w-4 h-4 text-amber-400" />
              <span>Salin Akses dari User Lain</span>
            </h4>
            <p className="text-xs text-slate-400">
              Pilih akun pengguna sumber untuk menyalin seluruh konfigurasi hak akses modul dan sub-menu ke user saat ini ({selectedUser?.fullName}).
            </p>
            <CustomSelectDropdown
              value={sourceUserIdForCopy}
              onChange={(val) => setSourceUserIdForCopy(val)}
              placeholder="Pilih User Sumber..."
              searchable
              searchPlaceholder="Cari nama atau role user..."
              minMenuWidth={280}
              options={visibleUsersForRole
                .filter(u => u.id !== selectedUser?.id && u.status !== 'inactive')
                .map(u => ({
                  value: u.id,
                  label: u.fullName,
                  sublabel: ROLE_LABELS[u.role] || u.role,
                  Icon: User,
                  iconTone: 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                }))}
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setIsCopyModalOpen(false)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 font-semibold text-xs"
              >
                Batal
              </button>
              <button
                onClick={handleCopyAccess}
                className="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs"
              >
                Terapkan Salin Akses
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= CHANGE PASSWORD SUB-MODAL ================= */}
      {isPasswordModalOpen && (passwordTargetUser || selectedUser) && (
        <div className="fixed inset-0 z-60 bg-black/50 backdrop-blur-[2px] flex items-center justify-center p-4 animate-in fade-in duration-150">
          <form
            autoComplete="off"
            onSubmit={(e) => {
              e.preventDefault();
              handleChangePassword();
            }}
            className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-4 shadow-2xl"
          >
            {/* Hidden trap field so browser password managers never autofill the page search bar */}
            <input
              type="text"
              name="username"
              autoComplete="username"
              value={(passwordTargetUser || selectedUser)?.email || ''}
              readOnly
              tabIndex={-1}
              aria-hidden="true"
              className="sr-only"
            />

            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-400" />
                <span>Ubah Password Akun: {(passwordTargetUser || selectedUser)?.fullName}</span>
              </h4>
              <button
                type="button"
                onClick={closePasswordModal}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="text-xs text-slate-400 space-y-1">
              <p>
                Masukkan password baru untuk akun <strong className="text-white">{(passwordTargetUser || selectedUser)?.fullName}</strong> (<span className="text-amber-400">{(passwordTargetUser || selectedUser)?.email}</span>).
              </p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  Password Baru <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    name="akk_reset_new_password"
                    autoComplete="new-password"
                    data-lpignore="true"
                    data-1p-ignore="true"
                    placeholder="Minimal 8 karakter"
                    value={newPasswordInput}
                    onChange={(e) => setNewPasswordInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white pr-9 focus:outline-none focus:border-amber-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                    title={showNewPassword ? 'Sembunyikan password' : 'Lihat password'}
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  Konfirmasi Password Baru <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    name="akk_reset_confirm_password"
                    autoComplete="new-password"
                    data-lpignore="true"
                    data-1p-ignore="true"
                    placeholder="Ketik ulang password baru"
                    value={confirmPasswordInput}
                    onChange={(e) => setConfirmPasswordInput(e.target.value)}
                    className={`w-full bg-slate-950 border rounded-xl px-3 py-2.5 text-xs text-white pr-9 focus:outline-none ${
                      confirmPasswordInput && newPasswordInput !== confirmPasswordInput
                        ? 'border-rose-500/70 focus:border-rose-500'
                        : confirmPasswordInput && newPasswordInput === confirmPasswordInput
                        ? 'border-emerald-500/70 focus:border-emerald-500'
                        : 'border-slate-800 focus:border-amber-500'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                    title={showConfirmPassword ? 'Sembunyikan password' : 'Lihat password'}
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Real-time mismatch detection */}
              {confirmPasswordInput.length > 0 && (
                <div className="text-[11px] flex items-center gap-1.5 pt-0.5">
                  {newPasswordInput !== confirmPasswordInput ? (
                    <span className="text-rose-400 flex items-center gap-1 font-semibold">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      <span>Password konfirmasi tidak cocok!</span>
                    </span>
                  ) : (
                    <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      <span>Password cocok dan terkonfirmasi.</span>
                    </span>
                  )}
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={closePasswordModal}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                disabled={!newPasswordInput || newPasswordInput.length < 8 || newPasswordInput !== confirmPasswordInput}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800 disabled:text-slate-600 text-slate-950 font-bold text-xs transition cursor-pointer shadow-md shadow-amber-500/20 active:scale-95 disabled:cursor-not-allowed"
              >
                Simpan Password Baru
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Manual Add User Modal */}
      {isAddUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-visible shadow-2xl">
            <div className="p-4 bg-slate-950 border-b border-slate-800 rounded-t-2xl flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <User className="w-4 h-4 text-amber-400" />
                Tambah Pengguna Baru AKK
              </h3>
              <button
                onClick={() => setIsAddUserModalOpen(false)}
                className="text-slate-400 hover:text-white font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="text-slate-300 font-bold block mb-1">Nama Lengkap *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Hendra Wijaya"
                  value={newUser.fullName}
                  onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Email / Username *</label>
                  <input
                    type="text"
                    required
                    placeholder="nama@gmail.com"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-bold block mb-1">No. WhatsApp</label>
                  <input
                    type="text"
                    placeholder="0878xxxxxxxx"
                    value={newUser.phone}
                    onChange={(e) => setNewUser({ ...newUser, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-amber-500"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Terhubung ke pengiriman OTP Lupa Password via WhatsApp.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">Role Pengguna *</label>
                  <CustomRoleDropdown
                    value={newUser.role}
                    onChange={(r) => {
                      setNewUser({
                        ...newUser,
                        role: r,
                        department: getDefaultDepartmentForRole(r, newUser.department)
                      });
                    }}
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">Departemen / Divisi</label>
                  <CustomSelectDropdown
                    value={newUser.department}
                    onChange={(val) => setNewUser({ ...newUser, department: val })}
                    options={OFFICIAL_DEPARTMENT_OPTIONS.map(dept => ({
                      value: dept,
                      label: dept,
                      Icon: Building,
                      iconTone: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30'
                    }))}
                    minMenuWidth={220}
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">Password *</label>
                <input
                  type="text"
                  required
                  placeholder="Minimal 6 karakter"
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddUserModalOpen(false)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold shadow cursor-pointer"
                >
                  Simpan Akun Baru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit User Profile Modal (Khusus Super Admin) — Compact Single-Viewport Tanpa Double Scroll */}
      {editingUser && isSuperAdmin && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl my-auto">
            <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 rounded-t-2xl flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                  <UserCog className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 flex-wrap">
                    <span className="truncate">Edit Pengguna: {editingUser.fullName}</span>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/40 shrink-0">
                      {ROLE_LABELS[editingUser.role] || editingUser.role}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-400 truncate">
                    Perbarui data akun <strong className="text-slate-200">{editingUser.fullName}</strong> &bull; ID: <code className="text-amber-400 font-mono">{editingUser.id}</code>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-4 space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1 sm:col-span-2">
                  <label className="text-slate-300 font-bold flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-amber-400" />
                    <span>Nama Lengkap &amp; Gelar</span>
                    <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={editFormData.fullName}
                    onChange={(e) => setEditFormData({ ...editFormData, fullName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-bold flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-blue-400" />
                    <span>Email Akun</span>
                    <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={editFormData.email}
                    onChange={(e) => setEditFormData({ ...editFormData, email: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-bold flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    <span>No. WhatsApp</span>
                  </label>
                  <input
                    type="text"
                    placeholder="0878xxxxxxxx"
                    value={editFormData.phone}
                    onChange={(e) => setEditFormData({ ...editFormData, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                  <p className="text-[10px] text-emerald-400/90 font-medium">
                    Nomor ini menjadi tujuan otomatis kode OTP Lupa Password WhatsApp.
                  </p>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-bold flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-amber-400" />
                    <span>Role / Jabatan User</span>
                    <span className="text-rose-400">*</span>
                  </label>
                  <CustomRoleDropdown
                    value={editFormData.role}
                    includeUnassigned={true}
                    onChange={(r) =>
                      setEditFormData({
                        ...editFormData,
                        role: r,
                        department: getDefaultDepartmentForRole(r, editFormData.department)
                      })
                    }
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Status Akun</span>
                  </label>
                  <CustomSelectDropdown
                    value={editFormData.status}
                    onChange={(val) => setEditFormData({ ...editFormData, status: val as UserApprovalStatus })}
                    options={USER_STATUS_DROPDOWN_OPTIONS}
                    minMenuWidth={240}
                  />
                </div>

                <div className="space-y-1 sm:col-span-2">
                  <label className="text-slate-300 font-bold flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Departemen / Divisi</span>
                    <span className="text-rose-400">*</span>
                  </label>
                  <CustomSelectDropdown
                    value={editFormData.department}
                    onChange={(val) => setEditFormData({ ...editFormData, department: val })}
                    options={[
                      ...(!OFFICIAL_DEPARTMENT_OPTIONS.includes(editFormData.department) && editFormData.department
                        ? [{
                            value: editFormData.department,
                            label: editFormData.department,
                            Icon: Building,
                            iconTone: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30'
                          }]
                        : []),
                      ...OFFICIAL_DEPARTMENT_OPTIONS.map(dept => ({
                        value: dept,
                        label: dept,
                        Icon: Building,
                        iconTone: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30'
                      }))
                    ]}
                    minMenuWidth={260}
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center gap-1.5 shadow-lg shadow-amber-500/20 transition cursor-pointer active:scale-95"
                >
                  <Save className="w-4 h-4" />
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* ================= DELETE CONFIRMATION SUB-MODAL ================= */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 z-60 bg-black/40 backdrop-blur-[2px] flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-4 shadow-2xl neu-flat">
            <div className="flex items-center gap-2.5 pb-2 border-b border-slate-800">
              <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-500" />
              </div>
              <div>
                <h4 className="font-bold text-white text-sm">
                  Konfirmasi Hapus Akun
                </h4>
                <p className="text-[10px] text-slate-400">
                  Panel Pengguna &bull; PT Anugrah Kemasan Kreatif
                </p>
              </div>
            </div>

            {users.find(u => u.id === deleteTargetId) && (
              <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3 flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-xs">
                  {users.find(u => u.id === deleteTargetId)?.fullName.substring(0, 2).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-white text-xs truncate">
                    {users.find(u => u.id === deleteTargetId)?.fullName}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">
                    {users.find(u => u.id === deleteTargetId)?.email} &bull; <span className="text-amber-400">{ROLE_LABELS[users.find(u => u.id === deleteTargetId)?.role || 'spv_logistik']}</span>
                  </div>
                </div>
              </div>
            )}

            <p className="text-xs text-slate-300 leading-relaxed">
              Apakah Anda yakin ingin menghapus akun pengguna ini? Tindakan ini bersifat permanen dan seluruh hak akses akun akan dihapus dari sistem.
            </p>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => { setIsDeleteModalOpen(false); setDeleteTargetId(null); }}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition cursor-pointer"
              >
                Tidak, Batal
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 transition cursor-pointer active:scale-95"
              >
                Ya, Hapus Akun
              </button>
            </div>
          </div>
        </div>
      )}


      {/* ================= IN-PAGE POP-UP MODAL NOTIFICATION ================= */}
      {pageModalNotification && (
        <div className="fixed inset-0 z-70 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-4 shadow-2xl text-center">
            <div className="flex flex-col items-center gap-2.5">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                pageModalNotification.type === 'success' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                pageModalNotification.type === 'error' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                pageModalNotification.type === 'warning' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                'bg-blue-500/20 text-blue-400 border border-blue-500/30'
              }`}>
                {pageModalNotification.type === 'success' && <CheckCircle2 className="w-6 h-6" />}
                {pageModalNotification.type === 'error' && <AlertTriangle className="w-6 h-6" />}
                {pageModalNotification.type === 'warning' && <ShieldAlert className="w-6 h-6" />}
                {pageModalNotification.type === 'info' && <ShieldCheck className="w-6 h-6" />}
              </div>
              <h4 className="font-bold text-white text-base">
                {pageModalNotification.title}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {pageModalNotification.message}
              </p>
            </div>

            <div className="pt-2 border-t border-slate-800">
              <button
                type="button"
                autoFocus
                onClick={() => setPageModalNotification(null)}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition cursor-pointer shadow-lg shadow-amber-500/20 active:scale-95 focus:outline-none focus:ring-2 focus:ring-amber-300"
              >
                Oke, Mengerti
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
