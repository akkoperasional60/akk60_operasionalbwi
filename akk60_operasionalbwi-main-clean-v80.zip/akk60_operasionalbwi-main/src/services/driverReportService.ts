import { resolvePreciseCustomerGps } from '../utils/preciseCustomerGps';

export interface DriverHelperReport {
  id: string;
  timestamp: string;
  date?: string; // YYYY-MM-DD
  driverId: string;
  driverName: string;
  reportedByName?: string;
  userRole?: string;
  helperName?: string;
  plateNumber: string;
  category:
    | 'kendala_jalan'
    | 'akhir_kiriman'
    | 'istirahat'
    | 'update_lokasi'
    | 'presensi_shift'
    | 'pin_keamanan'
    | 'mode_offline'
    | 'isi_bbm'
    | 'retur'
    | 'kurang_muat'
    | 'lebih_muat'
    | 'salah_muat';
  areaName: string;
  deliveryId?: string;
  notes: string;
  photoUrl?: string | null;
  photoUrls?: string[];
  latitude?: number;
  longitude?: number;
  gmapsUrl?: string;
  status: 'pending' | 'verified' | 'follow_up' | 'resolved';
  verifiedBy?: string;
  verifiedAt?: string;
  // Data Barang Retur / Kurang Muat / Lebih Muat / Salah Muat
  issueItemName?: string;
  issueItemCode?: string;
  issueItemUnit?: string;
  issueQty?: string;
  invoiceNumber?: string;
  validationDecision?: 'pending' | 'approved' | 'follow_up' | 'rejected';
  validationNote?: string;
  validatedBy?: string;
  validatedAt?: string;
  // Validasi Titik GPS Lapangan (Super Admin & SPV Logistik)
  gpsValidationStatus?: 'valid' | 'mismatch' | 'unchecked';
  gpsValidatedBy?: string;
  gpsValidatedAt?: string;
  gpsValidationNote?: string;
  // Data Pengisian BBM (Solar) di Farly / Gajah Mada / SPBU Lain (Urgent)
  fuelLocation?: 'Farly' | 'Gajah Mada' | 'SPBU Lain (Urgent)' | string;
  fuelUrgentReason?: string;
  fuelLiters?: string;
  exifMetadata?: {
    DateTimeOriginal: string;
    DateTimeDigitized: string;
    OffsetTimeOriginal: string;
    OffsetTime: string;
    SubSecTimeOriginal: string;
    source?: 'EXIF_BINARY' | 'CAMERA_CAPTURE_SENSOR';
  };
  // Data Presensi Check-In & Check-Out Terpadu + PIN Keamanan
  shiftId?: string;
  checkinTimeFormatted?: string;
  checkoutTimeFormatted?: string;
  securityPin?: string;
  // Data Peringatan Aktivasi Mode Offline Kru Pengiriman
  offlineStatus?: 'masih_offline' | 'sudah_online';
  offlineActivatedAt?: string;
  onlineRestoredAt?: string;
  // Data Kendala Mengantri di Customer (Mulai Antri -> Selang Beberapa Menit Keluar dari Customer)
  customerQueueStatus?: 'sedang_mengantri' | 'selesai_antri';
  customerQueueStartIso?: string;
  customerQueueStartFormatted?: string;
  customerQueueExitFormatted?: string;
  customerQueueDurationMinutes?: number;
  customerOutletName?: string;
  // Solusi & Arahan dari SPV Logistik / Super Admin
  solution?: string;
  solutionBy?: string;
  solutionAt?: string;
  driverAcknowledged?: boolean;
  driverAcknowledgedAt?: string;
}

const STORAGE_KEY = 'akk_driver_helper_reports_v2';
const DELETED_REPORTS_KEY = 'akk_deleted_driver_report_ids_v1';

export const getLocalDateStr = (input?: string | Date): string => {
  const fallbackNow = () => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  };
  if (!input) return fallbackNow();
  if (typeof input === 'string') {
    const trimmed = input.trim();
    if (!trimmed || trimmed.toLowerCase().includes('invalid')) return fallbackNow();
    if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return trimmed;
    const isoPrefix = trimmed.match(/^(\d{4}-\d{2}-\d{2})[T\s]/);
    if (isoPrefix) return isoPrefix[1];
    const dmy = trimmed.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
    if (dmy) {
      return `${dmy[3]}-${ dmy[2].padStart(2, '0') }-${ dmy[1].padStart(2, '0') }`;
    }
  }
  const d = input instanceof Date ? input : new Date(input);
  if (isNaN(d.getTime())) {
    return fallbackNow();
  }
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const sanitizeOperationalPlate = (plate?: string): string => {
  const clean = String(plate || '').trim();
  if (!clean || clean === '-') return '-';
  if (/^FLT-\d+$/i.test(clean) || clean.toUpperCase().endsWith('AKK')) return '-';
  return clean;
};

const stripHelperSelfDuplicate = (driverName?: string, helperName?: string, userRole?: string): string | undefined => {
  const cleanHelper = String(helperName || '').trim();
  if (!cleanHelper || cleanHelper === '-') return undefined;
  const normCompact = (v?: string) => String(v || '').trim().toLowerCase().replace(/[^a-z0-9]/g, '');
  const driverCompact = normCompact(driverName);
  const roleLower = String(userRole || '').toLowerCase();
  // When userRole is Helper and both fields hold the same name (legacy report bug),
  // keep helperName intact so the Helper isn't erased and confused with the Driver.
  if (roleLower.includes('helper') && driverCompact && normCompact(cleanHelper) === driverCompact) {
    return cleanHelper;
  }
  const filteredParts = cleanHelper
    .split(/[,&/]+/)
    .map(p => p.trim())
    .filter(p => p && p !== '-' && (!driverCompact || normCompact(p) !== driverCompact));
  return filteredParts.length > 0 ? filteredParts.join(', ') : undefined;
};

class DriverReportService {
  private memoryReports: DriverHelperReport[] | null = null;
  private deletedReportIds: Set<string> = new Set<string>();
  private deletedIdsLoaded = false;
  private syncedToServerIds: Set<string> = new Set<string>();
  private isSyncingWithServer = false;
  private lastServerSyncAt = 0;
  private seqCounter = 0;
  private channel: BroadcastChannel | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.migrateLegacyLocalStorageOnce();
      try {
        if ('BroadcastChannel' in window) {
          this.channel = new BroadcastChannel('akk_driver_reports_realtime');
          this.channel.onmessage = (evt) => {
            const msg = evt.data;
            if (!msg) return;
            if (msg.deletedId) {
              this.applyRemoteDeletion(String(msg.deletedId), false);
              return;
            }
            if (Array.isArray(msg.reports)) {
              this.mergeIncomingReports(msg.reports, false);
            } else if (msg.report && msg.report.id) {
              this.mergeIncomingReports([msg.report], false);
            }
          };
        }
      } catch {}

      void this.syncWithServer(true);
    }
  }

  private getAuthHeaders(): Record<string, string> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    try {
      const token =
        localStorage.getItem('akk_session_token') ||
        localStorage.getItem('session_token') ||
        sessionStorage.getItem('akk_session_token') ||
        '';
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
        headers['x-akk-session-token'] = token;
      }
    } catch {}
    return headers;
  }

  private migrateLegacyLocalStorageOnce() {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') return;
    try {
      const rawDel = localStorage.getItem(DELETED_REPORTS_KEY);
      if (rawDel) {
        const parsedDel = JSON.parse(rawDel);
        if (Array.isArray(parsedDel)) {
          parsedDel.forEach((id) => {
            if (id) this.deletedReportIds.add(String(id));
          });
        }
        localStorage.removeItem(DELETED_REPORTS_KEY);
      }
      const rawReports = localStorage.getItem(STORAGE_KEY);
      if (rawReports) {
        const parsedReports = JSON.parse(rawReports);
        if (Array.isArray(parsedReports) && parsedReports.length > 0) {
          this.memoryReports = this.normalizeList(parsedReports);
        }
        localStorage.removeItem(STORAGE_KEY);
      }
      this.deletedIdsLoaded = true;
    } catch {}
  }

  private loadDeletedReportIds(_force: boolean = false) {
    this.deletedIdsLoaded = true;
  }

  private saveDeletedReportIds() {
    // Disimpan langsung pada MySQL melalui endpoint /api/driver-reports
  }

  private applyRemoteDeletion(id: string, broadcastToPeers: boolean = false) {
    const cleanId = String(id || '').trim();
    if (!cleanId) return;
    this.deletedReportIds.add(cleanId);
    const current = this.getStoredReports().filter(r => r.id !== cleanId);
    this.persistListInternal(current, broadcastToPeers);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('driver-report-updated'));
    }
  }

  public async syncWithServer(force: boolean = false): Promise<void> {
    if (typeof window === 'undefined' || typeof fetch === 'undefined') return;
    if (this.isSyncingWithServer) return;
    const nowMs = Date.now();
    if (!force && nowMs - this.lastServerSyncAt < 8000) return;
    this.isSyncingWithServer = true;
    this.lastServerSyncAt = nowMs;
    try {
      const res = await fetch('/api/driver-reports', {
        credentials: 'include',
        headers: this.getAuthHeaders()
      });
      if (!res.ok) return;
      const json = await res.json();
      if (Array.isArray(json.deletedIds) && json.deletedIds.length > 0) {
        let hasNewDeleted = false;
        json.deletedIds.forEach((delId: any) => {
          const clean = String(delId || '').trim();
          if (clean && !this.deletedReportIds.has(clean)) {
            this.deletedReportIds.add(clean);
            hasNewDeleted = true;
          }
        });
        if (hasNewDeleted && this.memoryReports) {
          this.memoryReports = this.memoryReports.filter(r => !this.deletedReportIds.has(r.id));
          if (typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent('driver-report-updated'));
          }
        }
      }
      const serverIds = new Set<string>();
      if (Array.isArray(json.reports) && json.reports.length > 0) {
        json.reports.forEach((r: any) => {
          if (r?.id) {
            serverIds.add(String(r.id));
            this.syncedToServerIds.add(String(r.id));
          }
        });
        this.mergeIncomingReports(json.reports, false);
      }
      const localList = this.getReports();
      const unsyncedReports = localList
        .slice(0, 25)
        .filter(r => r?.id && !serverIds.has(r.id) && !this.syncedToServerIds.has(r.id));
      if (unsyncedReports.length > 0) {
        unsyncedReports.forEach(r => this.syncedToServerIds.add(r.id));
        await fetch('/api/driver-reports', {
          method: 'POST',
          headers: this.getAuthHeaders(),
          credentials: 'include',
          body: JSON.stringify({ reports: unsyncedReports })
        });
      }
    } catch {
      // ignore transient network errors
    } finally {
      this.isSyncingWithServer = false;
    }
  }

  private pushReportToServer(report: DriverHelperReport) {
    if (typeof window === 'undefined' || typeof fetch === 'undefined') return;
    if (report?.id) {
      this.syncedToServerIds.add(report.id);
    }
    fetch('/api/driver-reports', {
      method: 'POST',
      headers: this.getAuthHeaders(),
      credentials: 'include',
      body: JSON.stringify({ report })
    }).catch(() => {
      if (report?.id) {
        this.syncedToServerIds.delete(report.id);
      }
    });
  }

  private normalizeList(parsed: DriverHelperReport[]): DriverHelperReport[] {
    this.loadDeletedReportIds();
    const seenIds = new Set<string>();
    const filtered = parsed.filter(r => !r?.id || !this.deletedReportIds.has(String(r.id)));

    // Hitung frekuensi koordinat mentah agar koordinat duplikat antar pelanggan otomatis dipresisikan per toko
    const coordFreq = new Map<string, number>();
    filtered.forEach(r => {
      if (typeof r.latitude === 'number' && typeof r.longitude === 'number') {
        const k = `${r.latitude.toFixed(4)},${r.longitude.toFixed(4)}`;
        coordFreq.set(k, (coordFreq.get(k) || 0) + 1);
      }
    });

    return filtered.map((r, index) => {
      let uniqueId = r.id || `REP-2026-${1000 + index}`;
      if (seenIds.has(uniqueId)) {
        uniqueId = `${uniqueId}-${index + 1}`;
      }
      seenIds.add(uniqueId);
      const hasSol = Boolean(r.solution && r.solution.trim());
      const isConstraintCategory =
        r.category === 'kendala_jalan' ||
        r.category === 'mode_offline' ||
        r.category === 'retur' ||
        r.category === 'kurang_muat' ||
        r.category === 'lebih_muat' ||
        r.category === 'salah_muat';
      const resolvedStatus =
        hasSol && r.status === 'pending'
          ? 'resolved'
          : !isConstraintCategory && r.status === 'pending'
          ? 'verified'
          : r.status;
      const photoUrls = Array.isArray(r.photoUrls) && r.photoUrls.length > 0
        ? r.photoUrls
        : r.photoUrl
        ? [r.photoUrl]
        : [];

      let finalLat = r.latitude;
      let finalLng = r.longitude;
      let finalGmapsUrl = r.gmapsUrl;

      if (
        r.category === 'istirahat' ||
        r.category === 'isi_bbm' ||
        r.category === 'retur' ||
        r.category === 'kurang_muat' ||
        r.category === 'lebih_muat' ||
        r.category === 'salah_muat'
      ) {
        const customerName =
          r.customerOutletName ||
          (r.notes?.match(/\[ABSEN KIRIMAN PELANGGAN:\s*([^\]]+)\]/i)?.[1] ?? '') ||
          (r.category === 'isi_bbm' && r.fuelLocation ? `SPBU ${r.fuelLocation}` : '') ||
          r.issueItemName ||
          '';
        const coordKey =
          typeof r.latitude === 'number' && typeof r.longitude === 'number'
            ? `${r.latitude.toFixed(4)},${r.longitude.toFixed(4)}`
            : '';
        const isDuplicate = coordKey ? (coordFreq.get(coordKey) || 0) > 1 : false;
        const precise = resolvePreciseCustomerGps({
          customerName,
          areaName: r.areaName,
          rawLat: r.latitude,
          rawLng: r.longitude,
          rawGmapsUrl: r.gmapsUrl,
          isDuplicateCoordInGroup: isDuplicate
        });
        finalLat = precise.latitude;
        finalLng = precise.longitude;
        finalGmapsUrl = precise.gmapsUrl;
      }

      const helperSelfFixed =
        String(r.userRole || '').toLowerCase().includes('helper') &&
        r.helperName &&
        r.driverName &&
        r.helperName.trim().toLowerCase() === r.driverName.trim().toLowerCase()
          ? { reportedByName: r.reportedByName || r.helperName.trim() }
          : {};

      return {
        ...r,
        ...helperSelfFixed,
        id: uniqueId,
        plateNumber: sanitizeOperationalPlate(r.plateNumber),
        helperName: stripHelperSelfDuplicate(r.driverName, r.helperName, r.userRole),
        photoUrl: r.photoUrl || photoUrls[0] || null,
        photoUrls,
        latitude: finalLat,
        longitude: finalLng,
        gmapsUrl: finalGmapsUrl,
        status: resolvedStatus,
        date: r.timestamp ? getLocalDateStr(new Date(r.timestamp)) : (r.date || getLocalDateStr())
      };
    });
  }

  private mergeIncomingReports(incoming: DriverHelperReport[], broadcastToPeers: boolean = false) {
    this.loadDeletedReportIds();
    const current = this.getStoredReports();
    const map = new Map<string, DriverHelperReport>();
    for (const r of current) {
      if (!this.deletedReportIds.has(r.id)) {
        map.set(r.id, r);
      }
    }
    let changedReport: DriverHelperReport | null = null;
    let hasMeaningfulChange = false;
    for (const inc of incoming) {
      if (!inc || !inc.id || this.deletedReportIds.has(inc.id)) continue;
      const existing = map.get(inc.id);
      if (!existing) {
        map.set(inc.id, inc);
        changedReport = inc;
        hasMeaningfulChange = true;
      } else {
        const incHasSol = Boolean(inc.solution && inc.solution.trim());
        const exHasSol = Boolean(existing.solution && existing.solution.trim());
        const nextSolution = incHasSol ? inc.solution : existing.solution;
        const nextStatus = incHasSol
          ? (inc.status === 'pending' ? 'resolved' : inc.status)
          : (exHasSol ? existing.status : inc.status);
        const nextCheckout = inc.checkoutTimeFormatted || existing.checkoutTimeFormatted;
        const nextQueueStatus = inc.customerQueueStatus || existing.customerQueueStatus;
        const nextOfflineStatus = inc.offlineStatus || existing.offlineStatus;
        const nextAck = inc.driverAcknowledged ?? existing.driverAcknowledged;
        const nextNotes = inc.notes || existing.notes;
        const nextValidationDecision = inc.validationDecision || existing.validationDecision;
        const nextValidationNote = inc.validationNote || existing.validationNote;
        const nextGpsValidationStatus = inc.gpsValidationStatus || existing.gpsValidationStatus;
        const nextGpsValidationNote = inc.gpsValidationNote || existing.gpsValidationNote;
        const nextOutlet = inc.customerOutletName || existing.customerOutletName;
        const nextInvoice = inc.invoiceNumber || existing.invoiceNumber;
        const nextItemName = inc.issueItemName || existing.issueItemName;
        const nextItemQty = inc.issueQty || existing.issueQty;

        const isDiff =
          nextSolution !== existing.solution ||
          nextStatus !== existing.status ||
          nextCheckout !== existing.checkoutTimeFormatted ||
          nextQueueStatus !== existing.customerQueueStatus ||
          nextOfflineStatus !== existing.offlineStatus ||
          nextAck !== existing.driverAcknowledged ||
          nextNotes !== existing.notes ||
          nextValidationDecision !== existing.validationDecision ||
          nextValidationNote !== existing.validationNote ||
          nextGpsValidationStatus !== existing.gpsValidationStatus ||
          nextGpsValidationNote !== existing.gpsValidationNote ||
          nextOutlet !== existing.customerOutletName ||
          nextInvoice !== existing.invoiceNumber ||
          nextItemName !== existing.issueItemName ||
          nextItemQty !== existing.issueQty;

        if (isDiff) {
          const merged: DriverHelperReport = {
            ...existing,
            ...inc,
            solution: nextSolution,
            solutionBy: incHasSol ? inc.solutionBy : existing.solutionBy,
            solutionAt: incHasSol ? inc.solutionAt : existing.solutionAt,
            validationDecision: nextValidationDecision,
            validationNote: nextValidationNote,
            validatedBy: inc.validatedBy || existing.validatedBy,
            validatedAt: inc.validatedAt || existing.validatedAt,
            gpsValidationStatus: nextGpsValidationStatus,
            gpsValidationNote: nextGpsValidationNote,
            gpsValidatedBy: inc.gpsValidatedBy || existing.gpsValidatedBy,
            gpsValidatedAt: inc.gpsValidatedAt || existing.gpsValidatedAt,
            status: nextStatus,
            checkoutTimeFormatted: nextCheckout,
            customerOutletName: nextOutlet,
            invoiceNumber: nextInvoice,
            issueItemName: nextItemName,
            issueQty: nextItemQty,
            fuelLocation: inc.fuelLocation || existing.fuelLocation,
            fuelUrgentReason: inc.fuelUrgentReason || existing.fuelUrgentReason,
            photoUrl: inc.photoUrl || existing.photoUrl,
            photoUrls: (Array.isArray(inc.photoUrls) && inc.photoUrls.length > 0) ? inc.photoUrls : existing.photoUrls
          };
          map.set(inc.id, merged);
          changedReport = merged;
          hasMeaningfulChange = true;
        }
      }
    }
    if (!hasMeaningfulChange) {
      return;
    }
    const mergedList = this.normalizeList(
      Array.from(map.values()).sort(
        (a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime()
      )
    );
    this.persistListInternal(mergedList, broadcastToPeers);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: changedReport || mergedList[0] }));
    }
  }

  private getStoredReports(): DriverHelperReport[] {
    this.loadDeletedReportIds();
    if (this.memoryReports !== null) {
      return this.memoryReports;
    }
    this.memoryReports = [];
    return this.memoryReports;
  }

  private persistListInternal(list: DriverHelperReport[], broadcastToPeers: boolean = true): void {
    const normalized = this.normalizeList(list);
    this.memoryReports = normalized;

    if (broadcastToPeers && this.channel) {
      try {
        this.channel.postMessage({ reports: normalized.slice(0, 30) });
      } catch {}
    }
  }

  private saveReports(list: DriverHelperReport[]): void {
    this.persistListInternal(list, true);
  }

  public getReports(): DriverHelperReport[] {
    return this.getStoredReports();
  }

  public addReport(
    report: Omit<DriverHelperReport, 'id' | 'timestamp' | 'status'> & { status?: 'pending' | 'verified' | 'follow_up' | 'resolved' }
  ): DriverHelperReport {
    const list = [...this.getReports()];
    const now = new Date();
    this.seqCounter += 1;
    let uniqueId = `REP-${now.getFullYear()}-${Date.now().toString().slice(-4)}${Math.floor(10 + Math.random() * 90)}`;
    while (list.some(r => r.id === uniqueId)) {
      uniqueId = `REP-${now.getFullYear()}-${Date.now().toString().slice(-4)}${Math.floor(10 + Math.random() * 90)}-${this.seqCounter}`;
    }
    const isConstraintCategory =
      report.category === 'kendala_jalan' ||
      report.category === 'mode_offline' ||
      report.category === 'retur' ||
      report.category === 'kurang_muat' ||
      report.category === 'lebih_muat' ||
      report.category === 'salah_muat';
    const defaultStatus = isConstraintCategory ? 'pending' : 'verified';
    const photoUrls = Array.isArray(report.photoUrls) && report.photoUrls.length > 0
      ? report.photoUrls
      : report.photoUrl
      ? [report.photoUrl]
      : [];
    const newReport: DriverHelperReport = {
      ...report,
      plateNumber: sanitizeOperationalPlate(report.plateNumber),
      helperName: stripHelperSelfDuplicate(report.driverName, report.helperName, report.userRole),
      id: uniqueId,
      photoUrl: report.photoUrl || photoUrls[0] || null,
      photoUrls,
      timestamp: now.toISOString(),
      date: getLocalDateStr(now),
      status: report.status || defaultStatus
    };
    list.unshift(newReport);
    this.saveReports(list);
    this.pushReportToServer(newReport);

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: newReport }));
    }
    return newReport;
  }

  /**
   * Mencatat Check-In atau menggabungkan Check-Out ke dalam satu laporan terpadu di Laporan Kiriman Kru
   */
  public upsertShiftCheckinCheckoutReport(params: {
    shiftId: string;
    driverId: string;
    driverName: string;
    userRole?: string;
    helperName?: string;
    plateNumber: string;
    areaName?: string;
    checkinTimeFormatted: string;
    checkoutTimeFormatted?: string;
    securityPin?: string;
  }): DriverHelperReport {
    const list = this.getReports();
    const today = getLocalDateStr();
    const normCompact = (v?: string) => String(v || '').trim().toLowerCase().replace(/[^a-z0-9]/g, '');
    const normPlate = (v?: string) => String(v || '').replace(/\s+/g, '').toLowerCase();
    const targetNameCompact = normCompact(params.driverName);
    const targetPlateNorm = normPlate(params.plateNumber);

    const safePlate = sanitizeOperationalPlate(params.plateNumber);
    const resolveHelperText = (h?: string) => {
      return stripHelperSelfDuplicate(params.driverName, h, params.userRole) || '';
    };

    const matchesPersonOrShift = (r: DriverHelperReport) => {
      if (r.category !== 'presensi_shift') return false;
      if (params.shiftId && r.shiftId === params.shiftId) return true;
      const isClosed = Boolean(r.checkoutTimeFormatted && r.checkoutTimeFormatted.trim() !== '' && r.checkoutTimeFormatted.trim() !== '-');
      if (isClosed) return false;
      const sameId = Boolean(r.driverId && params.driverId && r.driverId.replace(/^crw-/, '') === params.driverId.replace(/^crw-/, ''));
      const sameName = Boolean(targetNameCompact && normCompact(r.driverName) === targetNameCompact);
      if (r.date === today && (sameId || sameName)) return true;
      // When checking out a recent open shift, match by name + plate even across midnight / earlier open row
      if (params.checkoutTimeFormatted && (sameId || sameName)) {
        if (!targetPlateNorm || targetPlateNorm === '-' || normPlate(r.plateNumber) === targetPlateNorm) {
          return true;
        }
      }
      return false;
    };

    const existingIdx = list.findIndex(matchesPersonOrShift);

    if (existingIdx >= 0) {
      const existing = list[existingIdx];
      const mergedCheckout = params.checkoutTimeFormatted || existing.checkoutTimeFormatted;
      const nextRole = params.userRole || existing.userRole;
      const isHelperRole = String(nextRole || '').toLowerCase().includes('helper');
      const mergedHelperName = isHelperRole
        ? undefined
        : (resolveHelperText(params.helperName) || resolveHelperText(existing.helperName) || undefined);
      const helperSuffix = mergedHelperName ? ` | Helper: ${mergedHelperName}` : '';
      const mergedPin = '****';
      const updatedNotes = mergedCheckout
        ? `[PRESENSI SHIFT TERPADU] Check-In: ${existing.checkinTimeFormatted || params.checkinTimeFormatted} | Check-Out: ${mergedCheckout}${helperSuffix} | PIN Keamanan: Terverifikasi`
        : `[PRESENSI CHECK-IN] Waktu Masuk: ${params.checkinTimeFormatted} (Status: Sedang Bertugas)${helperSuffix} | PIN Keamanan: Terverifikasi`;

      list[existingIdx] = {
        ...existing,
        driverName: params.driverName || existing.driverName,
        userRole: nextRole,
        helperName: mergedHelperName,
        plateNumber: safePlate !== '-' ? safePlate : sanitizeOperationalPlate(existing.plateNumber),
        areaName: params.areaName || existing.areaName,
        checkoutTimeFormatted: mergedCheckout,
        securityPin: mergedPin,
        notes: updatedNotes,
        status: 'verified',
        verifiedBy: 'Sistem Presensi Terpadu',
        verifiedAt: new Date().toISOString(),
        timestamp: new Date().toISOString()
      };

      this.saveReports(list);
      this.pushReportToServer(list[existingIdx]);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: list[existingIdx] }));
      }
      return list[existingIdx];
    }

    const isHelperRole = String(params.userRole || '').toLowerCase().includes('helper');
    const cleanHelper = isHelperRole ? undefined : (resolveHelperText(params.helperName) || undefined);
    const helperSuffix = cleanHelper ? ` | Helper: ${cleanHelper}` : '';
    const pinStr = '****';
    const initialNotes = params.checkoutTimeFormatted
      ? `[PRESENSI SHIFT TERPADU] Check-In: ${params.checkinTimeFormatted} | Check-Out: ${params.checkoutTimeFormatted}${helperSuffix} | PIN Keamanan: Terverifikasi`
      : `[PRESENSI CHECK-IN] Waktu Masuk: ${params.checkinTimeFormatted} (Status: Sedang Bertugas)${helperSuffix} | PIN Keamanan: Terverifikasi`;

    return this.addReport({
      driverId: params.driverId,
      driverName: params.driverName,
      userRole: params.userRole || 'Driver',
      helperName: cleanHelper,
      plateNumber: safePlate,
      category: 'presensi_shift',
      areaName: params.areaName || 'Presensi Operasional DC',
      notes: initialNotes,
      shiftId: params.shiftId,
      checkinTimeFormatted: params.checkinTimeFormatted,
      checkoutTimeFormatted: params.checkoutTimeFormatted,
      securityPin: pinStr,
      status: 'verified',
      verifiedBy: 'Sistem Presensi Terpadu'
    });
  }

  public closeOpenPresensiReportsForTeam(params: {
    shiftIds?: string[];
    crewNames?: Array<string | undefined>;
    plateNumber?: string;
    areaName?: string;
    checkoutTimeFormatted: string;
  }): number {
    const list = this.getReports();
    const normCompact = (v?: string) => String(v || '').trim().toLowerCase().replace(/[^a-z0-9]/g, '');
    const normPlate = (v?: string) => String(v || '').replace(/\s+/g, '').toLowerCase();
    const shiftIdSet = new Set((params.shiftIds || []).filter(Boolean));
    const nameSet = new Set((params.crewNames || []).map(normCompact).filter(v => Boolean(v && v.length >= 3)));
    const targetPlate = normPlate(params.plateNumber);
    const today = getLocalDateStr();
    const yesterday = getLocalDateStr(new Date(Date.now() - 24 * 3600 * 1000));

    let updatedCount = 0;
    const updatedReports: DriverHelperReport[] = [];

    const nextList = list.map(r => {
      if (r.category !== 'presensi_shift') return r;
      const alreadyClosed = Boolean(r.checkoutTimeFormatted && r.checkoutTimeFormatted.trim() !== '' && r.checkoutTimeFormatted.trim() !== '-');
      if (alreadyClosed) return r;

      const byShiftId = Boolean(r.shiftId && shiftIdSet.has(r.shiftId));
      const rDate = r.date || getLocalDateStr(new Date(r.timestamp));
      const recentDate = rDate === today || rDate === yesterday;
      const byName = nameSet.has(normCompact(r.driverName));
      const byPlate = Boolean(targetPlate && targetPlate !== '-' && normPlate(r.plateNumber) === targetPlate && recentDate);

      if (byShiftId || (recentDate && byName) || byPlate) {
        const helperSuffix = r.helperName ? ` | Helper: ${r.helperName}` : '';
        const updatedRow: DriverHelperReport = {
          ...r,
          checkoutTimeFormatted: params.checkoutTimeFormatted,
          notes: `[PRESENSI SHIFT TERPADU] Check-In: ${r.checkinTimeFormatted || '-'} | Check-Out: ${params.checkoutTimeFormatted}${helperSuffix} | PIN Keamanan: Terverifikasi`,
          status: 'verified',
          verifiedBy: 'Sistem Presensi Terpadu',
          verifiedAt: new Date().toISOString()
        };
        updatedCount += 1;
        updatedReports.push(updatedRow);
        return updatedRow;
      }
      return r;
    });

    if (updatedCount > 0) {
      this.saveReports(nextList);
      updatedReports.forEach(rep => this.pushReportToServer(rep));
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: updatedReports[0] }));
      }
    }
    return updatedCount;
  }

  /**
   * Mencatat perubahan / pembuatan PIN Keamanan baru (2x verifikasi) ke dalam Laporan Kiriman Kru
   */
  public recordPinChangeReport(params: {
    driverId: string;
    driverName: string;
    userRole?: string;
    plateNumber: string;
    areaName?: string;
    newPin: string;
  }): DriverHelperReport {
    const list = this.getReports();
    const today = getLocalDateStr();

    // Update juga securityPin pada laporan presensi hari ini jika sudah ada
    const activeShiftIdx = list.findIndex(
      r => r.category === 'presensi_shift' && r.driverId === params.driverId && r.date === today
    );
    if (activeShiftIdx >= 0) {
      list[activeShiftIdx].securityPin = '****';
      this.saveReports(list);
      this.pushReportToServer(list[activeShiftIdx]);
    }

    return this.addReport({
      driverId: params.driverId,
      driverName: params.driverName,
      userRole: params.userRole || 'Driver',
      plateNumber: params.plateNumber || '-',
      category: 'pin_keamanan',
      areaName: params.areaName || 'Keamanan Akun Kru DC',
      securityPin: '****',
      notes: `[DATA PIN KEAMANAN KRU] Pengguna memperbarui / mengaktifkan PIN Keamanan (Verifikasi 2x).`,
      status: 'verified',
      verifiedBy: 'Otentikasi PIN 2x Verifikasi'
    });
  }

  public updateReportSolution(
    id: string,
    solution: string,
    solutionBy: string = 'SPV Logistik DC',
    newStatus: 'verified' | 'follow_up' | 'pending' | 'resolved' = 'resolved'
  ): boolean {
    const list = [...this.getReports()];
    const idx = list.findIndex(r => r.id === id);
    if (idx >= 0) {
      list[idx] = {
        ...list[idx],
        solution,
        solutionBy,
        solutionAt: new Date().toISOString(),
        status: newStatus === 'pending' ? 'resolved' : newStatus,
        driverAcknowledged: false
      };
      this.saveReports(list);

      if (typeof window !== 'undefined' && typeof fetch !== 'undefined') {
        fetch(`/api/driver-reports/${encodeURIComponent(id)}/solution`, {
          method: 'PATCH',
          headers: this.getAuthHeaders(),
          credentials: 'include',
          body: JSON.stringify({
            solution,
            solutionBy,
            status: list[idx].status,
            reportSnapshot: list[idx]
          })
        }).catch(() => {});
      }

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: list[idx] }));
      }
      return true;
    }
    return false;
  }

  public acknowledgeReportSolution(id: string): boolean {
    const list = [...this.getReports()];
    const idx = list.findIndex(r => r.id === id);
    if (idx >= 0) {
      list[idx] = {
        ...list[idx],
        driverAcknowledged: true,
        driverAcknowledgedAt: new Date().toISOString()
      };
      this.saveReports(list);

      if (typeof window !== 'undefined' && typeof fetch !== 'undefined') {
        fetch(`/api/driver-reports/${encodeURIComponent(id)}/acknowledge`, {
          method: 'PATCH',
          headers: this.getAuthHeaders(),
          credentials: 'include'
        }).catch(() => {});
      }

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: list[idx] }));
      }
      return true;
    }
    return false;
  }

  public updateReportStatus(
    id: string,
    status: 'verified' | 'follow_up' | 'pending' | 'resolved',
    verifiedBy: string = 'SPV Logistik'
  ): boolean {
    const list = [...this.getReports()];
    const idx = list.findIndex(r => r.id === id);
    if (idx >= 0) {
      list[idx] = {
        ...list[idx],
        status,
        verifiedBy,
        verifiedAt: new Date().toISOString()
      };
      this.saveReports(list);
      this.pushReportToServer(list[idx]);

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: list[idx] }));
      }
      return true;
    }
    return false;
  }

  public validateItemIssueReport(params: {
    id: string;
    decision: 'approved' | 'follow_up' | 'rejected';
    note: string;
    validatedBy: string;
    gpsValidationStatus?: 'valid' | 'mismatch' | 'unchecked';
    gpsValidationNote?: string;
  }): DriverHelperReport | null {
    const list = [...this.getReports()];
    const idx = list.findIndex(r => r.id === params.id);
    if (idx < 0) return null;

    const nowIso = new Date().toISOString();
    const cleanNote = String(params.note || '').trim();
    const mappedStatus: DriverHelperReport['status'] =
      params.decision === 'approved'
        ? 'verified'
        : params.decision === 'follow_up'
        ? 'follow_up'
        : 'resolved';

    const decisionLabel =
      params.decision === 'approved'
        ? 'Disetujui / Valid'
        : params.decision === 'follow_up'
        ? 'Perlu Tindak Lanjut'
        : 'Ditolak / Tidak Sesuai';

    const feedbackText = cleanNote
      ? `[${decisionLabel}] ${cleanNote}`
      : `Laporan telah divalidasi dengan status: ${decisionLabel}.`;

    const nextGpsStatus = params.gpsValidationStatus || list[idx].gpsValidationStatus;
    const nextGpsNote = params.gpsValidationNote !== undefined ? params.gpsValidationNote : list[idx].gpsValidationNote;

    list[idx] = {
      ...list[idx],
      status: mappedStatus,
      validationDecision: params.decision,
      validationNote: cleanNote || decisionLabel,
      validatedBy: params.validatedBy,
      validatedAt: nowIso,
      verifiedBy: params.validatedBy,
      verifiedAt: nowIso,
      gpsValidationStatus: nextGpsStatus,
      gpsValidationNote: nextGpsNote,
      gpsValidatedBy: params.gpsValidationStatus ? params.validatedBy : list[idx].gpsValidatedBy,
      gpsValidatedAt: params.gpsValidationStatus ? nowIso : list[idx].gpsValidatedAt,
      solution: feedbackText,
      solutionBy: params.validatedBy,
      solutionAt: nowIso,
      driverAcknowledged: false
    };

    this.saveReports(list);
    this.pushReportToServer(list[idx]);

    if (typeof window !== 'undefined' && typeof fetch !== 'undefined') {
      fetch(`/api/driver-reports/${encodeURIComponent(params.id)}/solution`, {
        method: 'PATCH',
        headers: this.getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({
          solution: feedbackText,
          solutionBy: params.validatedBy,
          status: mappedStatus,
          reportSnapshot: list[idx]
        })
      }).catch(() => {});
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: list[idx] }));
    }
    return list[idx];
  }

  public validateReportGpsLocation(params: {
    id: string;
    gpsStatus: 'valid' | 'mismatch';
    note?: string;
    validatedBy: string;
  }): DriverHelperReport | null {
    const list = [...this.getReports()];
    const idx = list.findIndex(r => r.id === params.id);
    if (idx < 0) return null;

    const nowIso = new Date().toISOString();
    const gpsNoteText = String(params.note || '').trim() ||
      (params.gpsStatus === 'valid'
        ? 'Titik koordinat GPS sesuai dengan lokasi toko/rute pengiriman.'
        : 'Titik koordinat GPS tidak sesuai / berada di luar jangkauan toko tujuan.');

    list[idx] = {
      ...list[idx],
      gpsValidationStatus: params.gpsStatus,
      gpsValidatedBy: params.validatedBy,
      gpsValidatedAt: nowIso,
      gpsValidationNote: gpsNoteText
    };

    this.saveReports(list);
    this.pushReportToServer(list[idx]);

    if (typeof window !== 'undefined' && typeof fetch !== 'undefined') {
      fetch(`/api/driver-reports/${encodeURIComponent(params.id)}/solution`, {
        method: 'PATCH',
        headers: this.getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({
          solution: list[idx].solution || `[Validasi GPS: ${params.gpsStatus === 'valid' ? 'Valid' : 'Tidak Sesuai'}] ${gpsNoteText}`,
          solutionBy: list[idx].solutionBy || params.validatedBy,
          status: list[idx].status,
          reportSnapshot: list[idx]
        })
      }).catch(() => {});
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: list[idx] }));
    }
    return list[idx];
  }

  public deleteReport(id: string): boolean {
    const cleanId = String(id || '').trim();
    if (!cleanId) return false;
    this.deletedReportIds.add(cleanId);
    this.saveDeletedReportIds();

    const list = this.getReports();
    const filtered = list.filter(r => r.id !== cleanId);
    this.memoryReports = filtered;
    this.saveReports(filtered);

    if (this.channel) {
      try {
        this.channel.postMessage({ deletedId: cleanId });
      } catch {}
    }

    if (typeof window !== 'undefined' && typeof fetch !== 'undefined') {
      fetch(`/api/driver-reports/${encodeURIComponent(cleanId)}`, {
        method: 'DELETE',
        headers: this.getAuthHeaders(),
        credentials: 'include'
      }).catch(() => {});
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('driver-report-updated'));
    }
    return true;
  }

  /**
   * Mencatat siapa saja kru yang mengaktifkan Mode Offline sebagai peringatan bagi Tim Pengiriman
   * agar segera di-online-kan kembali.
   */
  public recordOfflineModeActivation(params: {
    driverId: string;
    driverName: string;
    userRole?: string;
    helperName?: string;
    plateNumber: string;
    areaName?: string;
    modeType?: 'simulasi' | 'jaringan';
  }): DriverHelperReport {
    const list = this.getReports();
    const today = getLocalDateStr();
    const now = new Date();
    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ' WIB';

    const existingIdx = list.findIndex(
      r =>
        r.category === 'mode_offline' &&
        r.date === today &&
        r.offlineStatus === 'masih_offline' &&
        (r.driverId === params.driverId || r.driverName.toLowerCase() === params.driverName.toLowerCase())
    );

    const warningNote = `[PERINGATAN MODE OFFLINE AKTIF] ${params.driverName} (${params.userRole || 'Driver'}${params.helperName ? ` • Helper: ${params.helperName}` : ''}) mengaktifkan Mode Offline pada pukul ${timeStr}. PERINGATAN TIM PENGIRIMAN: Harap segera di-online-kan kembali agar sinkronisasi data & GPS berjalan real-time!`;

    if (existingIdx >= 0) {
      list[existingIdx] = {
        ...list[existingIdx],
        driverName: params.driverName || list[existingIdx].driverName,
        userRole: params.userRole || list[existingIdx].userRole,
        helperName: params.helperName || list[existingIdx].helperName,
        plateNumber: params.plateNumber || list[existingIdx].plateNumber,
        areaName: params.areaName || list[existingIdx].areaName,
        offlineStatus: 'masih_offline',
        offlineActivatedAt: list[existingIdx].offlineActivatedAt || timeStr,
        onlineRestoredAt: undefined,
        notes: warningNote,
        status: 'pending',
        timestamp: now.toISOString()
      };
      this.saveReports(list);
      this.pushReportToServer(list[existingIdx]);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: list[existingIdx] }));
      }
      return list[existingIdx];
    }

    return this.addReport({
      driverId: params.driverId,
      driverName: params.driverName,
      userRole: params.userRole || 'Driver',
      helperName: params.helperName,
      plateNumber: params.plateNumber || '-',
      category: 'mode_offline',
      areaName: params.areaName || 'Rute Pengiriman Aktif',
      offlineStatus: 'masih_offline',
      offlineActivatedAt: timeStr,
      notes: warningNote,
      status: 'pending'
    });
  }

  /**
   * Menandai bahwa kru yang sebelumnya mengaktifkan Mode Offline sudah kembali Online
   */
  public markOfflineModeRestored(params: {
    reportId?: string;
    driverId?: string;
    driverName?: string;
    restoredBy?: string;
  }): DriverHelperReport | null {
    const list = this.getReports();
    const now = new Date();
    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ' WIB';
    let updatedReport: DriverHelperReport | null = null;

    list.forEach((r, idx) => {
      if (r.category !== 'mode_offline') return;
      const matchById = params.reportId && r.id === params.reportId;
      const matchByDriver =
        !params.reportId &&
        r.offlineStatus === 'masih_offline' &&
        ((params.driverId && r.driverId === params.driverId) ||
          (params.driverName && r.driverName.toLowerCase() === params.driverName.toLowerCase()));

      if (matchById || matchByDriver) {
        const cleanBaseNote = r.notes.replace(/\s*\|\s*\[SUDAH ONLINE KEMBALI.*?\]/g, '');
        list[idx] = {
          ...r,
          offlineStatus: 'sudah_online',
          onlineRestoredAt: timeStr,
          status: 'verified',
          verifiedBy: params.restoredBy || 'Tim Pengiriman (Online Kembali)',
          verifiedAt: now.toISOString(),
          notes: `${cleanBaseNote} | [SUDAH ONLINE KEMBALI pukul ${timeStr} oleh ${params.restoredBy || r.driverName}]`,
          solution:
            r.solution && r.solution.trim()
              ? r.solution
              : `Mode Offline telah dimatikan dan perangkat kembali Online pada pukul ${timeStr}.`,
          solutionBy: r.solutionBy || params.restoredBy || 'Sistem Monitoring Online',
          solutionAt: r.solutionAt || now.toISOString(),
          driverAcknowledged: true,
          driverAcknowledgedAt: now.toISOString()
        };
        updatedReport = list[idx];
      }
    });

    if (updatedReport) {
      this.saveReports(list);
      this.pushReportToServer(updatedReport);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: updatedReport }));
        window.dispatchEvent(new CustomEvent('akk-force-online-mode'));
      }
    }
    return updatedReport;
  }

  /**
   * Mencatat ketika kru mengalami kendala sedang mengantri di customer,
   * lalu beberapa menit kemudian baru keluar dari customer tersebut.
   */
  public startCustomerQueueReport(params: {
    driverId: string;
    driverName: string;
    userRole?: string;
    helperName?: string;
    plateNumber: string;
    areaName: string;
    customerOutletName?: string;
    deliveryId?: string;
    notes?: string;
    photoUrl?: string | null;
    latitude?: number;
    longitude?: number;
    gmapsUrl?: string;
  }): DriverHelperReport {
    const list = this.getReports();
    const today = getLocalDateStr();
    const now = new Date();
    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ' WIB';
    const outlet = params.customerOutletName || params.areaName || 'Customer / Toko Tujuan';

    const normalizeQueueKey = (value?: string) => (value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '');
    const requestAreaKey = normalizeQueueKey(params.areaName);
    const requestPlateKey = normalizeQueueKey(params.plateNumber);
    const existingIdx = list.findIndex(r => {
      if (
        r.category !== 'kendala_jalan' ||
        r.date !== today ||
        r.customerQueueStatus !== 'sedang_mengantri' ||
        !(r.driverId === params.driverId || r.driverName.toLowerCase() === params.driverName.toLowerCase())
      ) return false;
      // ID schedule is authoritative. Never overwrite a different route's queue report
      // merely because the same driver/helper or truck appears on both trips.
      if (params.deliveryId) return r.deliveryId === params.deliveryId;
      if (r.deliveryId) return false;
      return normalizeQueueKey(r.areaName) === requestAreaKey &&
        normalizeQueueKey(r.plateNumber) === requestPlateKey;
    });

    const queueNote = params.notes?.trim()
      ? `[ANTRI DI CUSTOMER: ${outlet}] Mulai Mengantri: ${timeStr} (Status: Sedang Mengantri di Customer) — ${params.notes.trim()}`
      : `[ANTRI DI CUSTOMER: ${outlet}] Mulai Mengantri: ${timeStr} (Status: Sedang Mengantri Bongkar/Muat di Customer, menunggu keluar dari customer).`;

    if (existingIdx >= 0) {
      list[existingIdx] = {
        ...list[existingIdx],
        areaName: params.areaName || list[existingIdx].areaName,
        customerOutletName: outlet,
        customerQueueStatus: 'sedang_mengantri',
        customerQueueStartIso: list[existingIdx].customerQueueStartIso || now.toISOString(),
        customerQueueStartFormatted: list[existingIdx].customerQueueStartFormatted || timeStr,
        photoUrl: params.photoUrl || list[existingIdx].photoUrl,
        notes: queueNote,
        timestamp: now.toISOString()
      };
      this.saveReports(list);
      this.pushReportToServer(list[existingIdx]);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: list[existingIdx] }));
      }
      return list[existingIdx];
    }

    return this.addReport({
      driverId: params.driverId,
      driverName: params.driverName,
      userRole: params.userRole || 'Driver',
      helperName: params.helperName,
      plateNumber: params.plateNumber,
      category: 'kendala_jalan',
      areaName: params.areaName,
      deliveryId: params.deliveryId,
      customerOutletName: outlet,
      customerQueueStatus: 'sedang_mengantri',
      customerQueueStartIso: now.toISOString(),
      customerQueueStartFormatted: timeStr,
      notes: queueNote,
      photoUrl: params.photoUrl,
      latitude: params.latitude,
      longitude: params.longitude,
      gmapsUrl: params.gmapsUrl,
      status: 'pending'
    });
  }

  /**
   * Menyelesaikan antrean ketika kru sudah keluar dari customer setelah selang beberapa menit
   */
  public completeCustomerQueueExit(params: {
    reportId?: string;
    deliveryId?: string;
    driverId?: string;
    driverName?: string;
    simulatedExtraMinutes?: number;
    exitNotes?: string;
  }): DriverHelperReport | null {
    const list = this.getReports();
    const now = new Date();
    let targetIdx = -1;

    if (params.reportId) {
      targetIdx = list.findIndex(r => r.id === params.reportId);
    }
    if (targetIdx < 0 && params.deliveryId) {
      targetIdx = list.findIndex(
        r => r.customerQueueStatus === 'sedang_mengantri' && r.deliveryId === params.deliveryId
      );
    }
    if (targetIdx < 0 && !params.deliveryId) {
      const candidates = list
        .map((r, index) => ({ r, index }))
        .filter(({ r }) =>
          r.customerQueueStatus === 'sedang_mengantri' &&
          !r.deliveryId &&
          ((params.driverId && r.driverId === params.driverId) ||
            (params.driverName && r.driverName.toLowerCase() === params.driverName.toLowerCase()))
        );
      // Do not close an arbitrary queue report if the same crew has multiple active trips.
      if (candidates.length === 1) targetIdx = candidates[0].index;
    }

    if (targetIdx < 0) return null;

    const existing = list[targetIdx];
    const startMs = existing.customerQueueStartIso ? new Date(existing.customerQueueStartIso).getTime() : new Date(existing.timestamp).getTime();
    const extraMs = (params.simulatedExtraMinutes || 0) * 60000;
    const effectiveExitDate = new Date(Math.max(now.getTime(), startMs + 60000) + extraMs);
    const durationMin = Math.max(1, Math.round((effectiveExitDate.getTime() - startMs) / 60000));

    const startFormatted =
      existing.customerQueueStartFormatted ||
      new Date(startMs).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ' WIB';
    const exitFormatted =
      effectiveExitDate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ' WIB';
    const outlet = existing.customerOutletName || existing.areaName || 'Customer';

    const extraNoteText = params.exitNotes?.trim() ? ` | Catatan Keluar: ${params.exitNotes.trim()}` : '';
    const updatedNotes = `[SELESAI ANTRI & KELUAR DARI CUSTOMER: ${outlet}] Mulai Antri: ${startFormatted} ➔ Keluar dari Customer: ${exitFormatted} (Selang Waktu Mengantri: ${durationMin} Menit)${extraNoteText}`;

    list[targetIdx] = {
      ...existing,
      customerQueueStatus: 'selesai_antri',
      customerQueueStartFormatted: startFormatted,
      customerQueueExitFormatted: exitFormatted,
      customerQueueDurationMinutes: durationMin,
      notes: updatedNotes,
      status: existing.solution && existing.solution.trim() ? 'resolved' : 'verified',
      verifiedBy: existing.verifiedBy || 'Konfirmasi Keluar Customer (Kru)',
      verifiedAt: now.toISOString()
    };

    this.saveReports(list);
    this.pushReportToServer(list[targetIdx]);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('driver-report-updated', { detail: list[targetIdx] }));
    }
    return list[targetIdx];
  }

  public submitReport(params: {
    driverId: string;
    driverName: string;
    driverPhone?: string;
    plateNumber: string;
    category: 'kendala_jalan' | 'akhir_kiriman' | 'istirahat' | 'update_lokasi' | 'presensi_shift' | 'pin_keamanan' | 'mode_offline' | 'isi_bbm' | 'retur' | 'kurang_muat' | 'lebih_muat' | 'salah_muat';
    reportText?: string;
    notes?: string;
    latitude?: number;
    longitude?: number;
    locationName?: string;
    areaName?: string;
    helperName?: string;
    photoUrl?: string;
    fuelLocation?: 'Farly' | 'Gajah Mada' | string;
    fuelLiters?: string;
  }): DriverHelperReport {
    return this.addReport({
      driverId: params.driverId,
      driverName: params.driverName,
      helperName: params.helperName,
      plateNumber: params.plateNumber,
      category: params.category,
      areaName: params.areaName || params.locationName || 'Lokasi Kendala Lapangan',
      notes: params.notes || params.reportText || '',
      latitude: params.latitude,
      longitude: params.longitude,
      photoUrl: params.photoUrl
    });
  }

  public resolveReport(
    id: string,
    solution: string,
    solutionBy: string = 'SPV Logistik DC'
  ): DriverHelperReport | null {
    const success = this.updateReportSolution(id, solution, solutionBy, 'resolved');
    if (success) {
      return this.getReports().find(r => r.id === id) || null;
    }
    return null;
  }
}

export const driverReportService = new DriverReportService();