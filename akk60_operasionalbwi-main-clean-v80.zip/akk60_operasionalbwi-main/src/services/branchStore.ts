import { UserPermissions, UserRole } from '../types';
import { getDefaultPermissionsForRole, MODERN_SUBMENU_KEYS_BY_MODULE, LEGACY_SUBMENU_KEY_MAP } from '../utils/rbac';

export interface BranchRecord {
  id: string;
  name: string;
  warehouseName: string;
  slug: string;
  sortOrder: number;
  template: 'Classic / Default' | 'Modern B2B' | 'Enterprise WMS';
  isActive: boolean;
  isFrontlineActive: boolean;
  city: string;
  address: string;
  phone?: string;
  createdAt: string;
}

export interface UserBranchPermissionEntry {
  branchId: string;
  enabled: boolean;
  allAccess: boolean;
  modules: UserPermissions['modules'];
}

export type UserBranchPermissionsMap = Record<string, Record<string, UserBranchPermissionEntry>>;

const LS_BRANCHES_KEY = 'akk_multi_store_branches_v1';
const LS_ACTIVE_BRANCH_KEY = 'akk_active_origin_branch_v1';
const LS_USER_BRANCH_PERMS_KEY = 'akk_user_branch_permissions_v1';
const LS_ENTITY_BRANCH_MAP_KEY = 'akk_entity_branch_assignments_v1';

export interface EntityBranchAssignments {
  schedules: Record<string, string>; // scheduleId -> branchId
  fleets: Record<string, string>;    // fleetId -> branchId
  crews: Record<string, string>;     // crewId -> branchId
  inventory: Record<string, string>; // skuId -> branchId
}

const DEFAULT_BRANCHES: BranchRecord[] = [
  {
    id: 'cab-sidoarjo',
    name: 'Sidoarjo',
    warehouseName: 'Gudang Sidoarjo',
    slug: 'sidoarjo',
    sortOrder: 1,
    template: 'Classic / Default',
    isActive: true,
    isFrontlineActive: true,
    city: 'Sidoarjo',
    address: 'Kawasan Industri Rungkut / Berbek, Sidoarjo, Jawa Timur',
    phone: '031-8912345',
    createdAt: '2026-01-10'
  },
  {
    id: 'cab-banyuwangi',
    name: 'Nusantara',
    warehouseName: 'Gudang Nusantara',
    slug: 'banyuwangi',
    sortOrder: 2,
    template: 'Classic / Default',
    isActive: true,
    isFrontlineActive: true,
    city: 'Banyuwangi',
    address: 'Jl. Argopuro No. 60, Ketapang - Banyuwangi, Jawa Timur',
    phone: '0333-421889',
    createdAt: '2026-01-01'
  }
];

class BranchStoreService {
  private branches: BranchRecord[] = [];
  private activeBranchId: string = 'cab-banyuwangi'; // Always separate Nusantara ('cab-banyuwangi') & Sidoarjo ('cab-sidoarjo')
  private userBranchPerms: UserBranchPermissionsMap = {};
  private entityBranches: EntityBranchAssignments = {
    schedules: {},
    fleets: {},
    crews: {},
    inventory: {}
  };
  private listeners: Set<() => void> = new Set();

  private isSyncingFromServer = false;
  private lastServerSyncAt = 0;
  private persistTimer: any = null;

  constructor() {
    this.clearLegacyLocalStorage();
    this.branches = [...DEFAULT_BRANCHES];
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        void this.syncFromServer();
      }, 150);
    }
  }

  private clearLegacyLocalStorage() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.removeItem(LS_BRANCHES_KEY);
      localStorage.removeItem(LS_ACTIVE_BRANCH_KEY);
      localStorage.removeItem(LS_USER_BRANCH_PERMS_KEY);
      localStorage.removeItem(LS_ENTITY_BRANCH_MAP_KEY);
    } catch {}
  }

  private getAuthHeaders(): Record<string, string> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    try {
      const token =
        (typeof localStorage !== 'undefined'
          ? localStorage.getItem('akk_session_token') || localStorage.getItem('session_token')
          : null) ||
        (typeof sessionStorage !== 'undefined' ? sessionStorage.getItem('akk_session_token') : null) ||
        '';
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
        headers['x-akk-session-token'] = token;
      }
    } catch {}
    return headers;
  }

  public async syncFromServer(force = false): Promise<void> {
    if (typeof window === 'undefined' || typeof fetch === 'undefined') return;
    if (this.isSyncingFromServer) return;
    const now = Date.now();
    if (!force && this.lastServerSyncAt > 0 && now - this.lastServerSyncAt < 8000) return;
    this.isSyncingFromServer = true;
    this.lastServerSyncAt = now;
    try {
      const res = await fetch('/api/branch-state', {
        credentials: 'same-origin',
        headers: this.getAuthHeaders()
      });
      if (!res.ok) return;
      const json = await res.json();
      const st = json?.state;
      if (!st || typeof st !== 'object') return;

      if (Array.isArray(st.branches) && st.branches.length > 0) {
        const cleaned = st.branches
          .filter(
            (b: BranchRecord) =>
              b &&
              typeof b === 'object' &&
              typeof b.id === 'string' &&
              typeof b.name === 'string' &&
              b.id !== 'cab-jember' &&
              b.slug !== 'nx-jember' &&
              (b.name || '').trim().toUpperCase() !== 'NX'
          )
          .map((b: BranchRecord, idx: number) => ({
            ...b,
            slug: b.slug || b.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
            city: b.city || b.name,
            sortOrder: typeof b.sortOrder === 'number' ? b.sortOrder : idx + 1,
            isActive: b.isActive !== undefined ? Boolean(b.isActive) : true,
            isFrontlineActive: b.isFrontlineActive !== undefined ? Boolean(b.isFrontlineActive) : true,
            warehouseName: (b.warehouseName || `Gudang ${b.name}`).replace(/Gudang Pusat\s*/gi, 'Gudang ')
          }));
        DEFAULT_BRANCHES.forEach(defBr => {
          if (!cleaned.some((c: BranchRecord) => c.id === defBr.id)) {
            cleaned.push({ ...defBr });
          }
        });
        if (cleaned.length > 0) this.branches = cleaned;
      }

      if (st.userBranchPerms && typeof st.userBranchPerms === 'object' && !Array.isArray(st.userBranchPerms)) {
        this.userBranchPerms = {
          ...st.userBranchPerms,
          ...this.userBranchPerms
        };
      }

      if (st.entityBranches && typeof st.entityBranches === 'object') {
        this.entityBranches = {
          schedules: { ...(st.entityBranches.schedules || {}), ...this.entityBranches.schedules },
          fleets: { ...(st.entityBranches.fleets || {}), ...this.entityBranches.fleets },
          crews: { ...(st.entityBranches.crews || {}), ...this.entityBranches.crews },
          inventory: { ...(st.entityBranches.inventory || {}), ...this.entityBranches.inventory }
        };
      }

      this.listeners.forEach(listener => listener());
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('akk-branch-updated'));
      }
    } catch {
      // ignore network error
    } finally {
      this.isSyncingFromServer = false;
    }
  }

  private scheduleServerPersist() {
    if (typeof window === 'undefined' || typeof fetch === 'undefined') return;
    if (this.persistTimer) clearTimeout(this.persistTimer);
    this.persistTimer = setTimeout(() => {
      void this.persistToServerNow();
    }, 250);
  }

  private async persistToServerNow(): Promise<void> {
    if (typeof window === 'undefined' || typeof fetch === 'undefined') return;
    try {
      await fetch('/api/branch-state', {
        method: 'PUT',
        credentials: 'same-origin',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({
          branches: this.branches,
          userBranchPerms: this.userBranchPerms,
          entityBranches: this.entityBranches
        })
      });
    } catch {}
  }

  public hydrateUserBranchPermissionsFromUsers(
    users: Array<{ id: string; fullName?: string; role: UserRole; permissions?: UserPermissions }>
  ) {
    if (!Array.isArray(users) || users.length === 0) return;
    let updated = false;
    users.forEach(u => {
      if (!u?.id) return;
      const bp = u.permissions?.branchPermissions;
      if (bp && typeof bp === 'object' && Object.keys(bp).length > 0) {
        this.userBranchPerms[u.id] = JSON.parse(JSON.stringify(bp));
        const sdaEnabled = Boolean(bp['cab-sidoarjo']?.enabled);
        const bwiEnabled = Boolean(bp['cab-banyuwangi']?.enabled);
        const sdaDpFull =
          sdaEnabled &&
          Boolean(bp['cab-sidoarjo']?.modules?.logistics?.enabled) &&
          (bp['cab-sidoarjo']?.modules?.logistics?.subMenus?.driver_portal === 'full_access' ||
            bp['cab-sidoarjo']?.modules?.logistics?.subMenus?.portal_driver === 'full_access');
        const bwiDpFull =
          bwiEnabled &&
          Boolean(bp['cab-banyuwangi']?.modules?.logistics?.enabled) &&
          (bp['cab-banyuwangi']?.modules?.logistics?.subMenus?.driver_portal === 'full_access' ||
            bp['cab-banyuwangi']?.modules?.logistics?.subMenus?.portal_driver === 'full_access');
        const resolvedBranch =
          sdaDpFull && !bwiDpFull
            ? 'cab-sidoarjo'
            : bwiDpFull && !sdaDpFull
            ? 'cab-banyuwangi'
            : sdaEnabled && !bwiEnabled
            ? 'cab-sidoarjo'
            : bwiEnabled && !sdaEnabled
            ? 'cab-banyuwangi'
            : '';
        if (resolvedBranch) {
          this.syncCrewBranchIdSilent(u.id, resolvedBranch, u.fullName);
          this.syncCrewBranchIdSilent(`crw-${u.id}`, resolvedBranch, u.fullName);
        }
        updated = true;
      }
    });
    if (updated) {
      this.listeners.forEach(listener => listener());
    }
  }

  private saveToStorage() {
    this.clearLegacyLocalStorage();
    this.scheduleServerPersist();
  }

  private notify() {
    this.saveToStorage();
    this.listeners.forEach(listener => listener());
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('akk-branch-updated'));
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public getBranches(): BranchRecord[] {
    return [...this.branches].sort((a, b) => a.sortOrder - b.sortOrder);
  }

  public getActiveBranches(): BranchRecord[] {
    return this.getBranches().filter(b => b.isActive);
  }

  public getBranchById(branchId: string): BranchRecord | undefined {
    if (!branchId) return undefined;
    return this.branches.find(
      b =>
        b.id === branchId ||
        b.slug === branchId ||
        b.name.toLowerCase() === branchId.toLowerCase()
    );
  }

  public getSelectedOriginBranchId(): string {
    if (!this.activeBranchId || this.activeBranchId === 'ALL' || !this.branches.some(b => b.id === this.activeBranchId)) {
      this.activeBranchId = 'cab-banyuwangi';
    }
    return this.activeBranchId;
  }

  public getSelectedOriginBranch(): BranchRecord | null {
    const id = this.getSelectedOriginBranchId();
    return this.branches.find(b => b.id === id) || null;
  }

  public setSelectedOriginBranchId(branchId: string) {
    this.activeBranchId = branchId;
    this.notify();
  }

  public setActiveBranchId(branchId: string) {
    this.setSelectedOriginBranchId(branchId);
  }

  public addBranch(input: {
    name: string;
    warehouseName?: string;
    slug?: string;
    sortOrder?: number;
    template?: BranchRecord['template'];
    isActive?: boolean;
    isFrontlineActive?: boolean;
    city?: string;
    address?: string;
  }): BranchRecord {
    const cleanName = input.name.trim();
    const autoSlug =
      (input.slug || '').trim().toLowerCase().replace(/[^a-z0-9-]+/g, '-') ||
      cleanName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') ||
      `cabang-${this.branches.length + 1}`;

    const newBranch: BranchRecord = {
      id: `cab-${autoSlug}-${Date.now().toString(36)}`,
      name: cleanName,
      warehouseName: input.warehouseName?.trim() || `Gudang ${cleanName}`,
      slug: autoSlug,
      sortOrder: input.sortOrder !== undefined ? Number(input.sortOrder) : this.branches.length + 1,
      template: input.template || 'Classic / Default',
      isActive: input.isActive !== undefined ? input.isActive : true,
      isFrontlineActive: input.isFrontlineActive !== undefined ? input.isFrontlineActive : true,
      city: input.city?.trim() || cleanName,
      address: input.address?.trim() || `Gudang Distribusi ${cleanName}`,
      createdAt: new Date().toISOString().slice(0, 10)
    };

    this.branches.push(newBranch);
    this.notify();
    return newBranch;
  }

  public updateBranch(branchId: string, patch: Partial<BranchRecord>): boolean {
    const idx = this.branches.findIndex(b => b.id === branchId);
    if (idx === -1) return false;
    this.branches[idx] = {
      ...this.branches[idx],
      ...patch
    };
    this.notify();
    return true;
  }

  public deleteBranch(branchId: string): boolean {
    if (this.branches.length <= 1) return false;
    const prevLen = this.branches.length;
    this.branches = this.branches.filter(b => b.id !== branchId);
    if (this.activeBranchId === branchId) {
      this.activeBranchId = 'ALL';
    }
    if (this.branches.length !== prevLen) {
      this.notify();
      return true;
    }
    return false;
  }

  // ============================================================
  // ENTITY <-> ORIGIN WAREHOUSE (CABANG) ASSIGNMENT & RESOLUTION
  // ============================================================
  public getFleetBranchId(
    fleetId: string,
    plateNumber?: string,
    initialCode?: string,
    explicitBranchId?: string
  ): string {
    if (explicitBranchId && this.branches.some(b => b.id === explicitBranchId)) {
      this.entityBranches.fleets[fleetId] = explicitBranchId;
      return explicitBranchId;
    }

    const cleanPlate = (plateNumber || '').trim().toUpperCase().replace(/\s+/g, ' ');
    const compactPlate = cleanPlate.replace(/\s+/g, '');
    const cleanInit = (initialCode || '').trim().toUpperCase();
    const initTokens = cleanInit
      .split(/[\s/\-_]+/)
      .map(t => t.trim())
      .filter(Boolean);

    // Known Nusantara (Banyuwangi) fleets (12 canonical units including NMR DS4 & DS5)
    const nusantaraSpecificTokens = new Set([
      'NP1', 'NP3', 'NS1', 'NS2', 'NS3', 'NL1', 'NL2', 'DS1', 'DS2', 'DS3', 'DS4', 'DS5',
      'N1', 'A3', 'N3', 'N4', 'N5', 'N20', 'N21', 'N22', 'N23', 'S5'
    ]);
    const nusantaraWPlates = new Set(['W8229US', 'W8603PG']);

    // Known Sidoarjo fleets by initial code (A1, A2, A4, S1, S2, S3, S4, SDA) or L/W plate prefix (excluding Nusantara DS4/DS5)
    const sidoarjoSpecificTokens = new Set(['A1', 'A2', 'A4', 'A5', 'A6', 'S1', 'S2', 'S3', 'S4', 'SDA']);
    const hasNusantaraToken = initTokens.some(t => nusantaraSpecificTokens.has(t));
    const hasSidoarjoToken = initTokens.some(t => sidoarjoSpecificTokens.has(t));

    if (hasSidoarjoToken && !hasNusantaraToken) {
      return 'cab-sidoarjo';
    }
    if (
      compactPlate &&
      !nusantaraWPlates.has(compactPlate) &&
      !hasNusantaraToken &&
      (cleanPlate.startsWith('L ') ||
        /^L\d/.test(compactPlate) ||
        cleanPlate.startsWith('W ') ||
        /^W\d/.test(compactPlate))
    ) {
      return 'cab-sidoarjo';
    }
    if (hasNusantaraToken || cleanPlate.startsWith('P ') || /^P\d/.test(compactPlate) || nusantaraWPlates.has(compactPlate)) {
      const mapped = this.entityBranches.fleets[fleetId];
      if (mapped && this.branches.some(b => b.id === mapped) && !hasNusantaraToken) {
        return mapped;
      }
      return 'cab-banyuwangi';
    }

    const mapped = this.entityBranches.fleets[fleetId];
    if (mapped && this.branches.some(b => b.id === mapped)) {
      return mapped;
    }
    return 'cab-banyuwangi';
  }

  public syncFleetBranchIdSilent(fleetId: string, branchId?: string) {
    if (!fleetId || !branchId || !this.branches.some(b => b.id === branchId)) return;
    this.entityBranches.fleets[fleetId] = branchId;
  }

  public setFleetBranchId(fleetId: string, branchId: string) {
    this.entityBranches.fleets[fleetId] = branchId;
    this.notify();
  }

  public getCrewBranchId(crewId: string, crewName?: string): string {
    const rawUserId = (crewId || '').replace(/^crw-/, '');
    const userMap = this.userBranchPerms[rawUserId] || this.userBranchPerms[crewId];
    if (userMap && Object.keys(userMap).length > 0) {
      const hasPortalFull = (entry?: UserBranchPermissionEntry) =>
        Boolean(
          entry?.enabled &&
            entry?.modules?.logistics?.enabled &&
            (entry.modules.logistics.subMenus?.driver_portal === 'full_access' ||
              entry.modules.logistics.subMenus?.portal_driver === 'full_access')
        );
      const sdaPortal = hasPortalFull(userMap['cab-sidoarjo']);
      const bwiPortal = hasPortalFull(userMap['cab-banyuwangi']);
      if (sdaPortal && !bwiPortal) return 'cab-sidoarjo';
      if (bwiPortal && !sdaPortal) return 'cab-banyuwangi';

      const sdaEnabled = Boolean(userMap['cab-sidoarjo']?.enabled);
      const bwiEnabled = Boolean(userMap['cab-banyuwangi']?.enabled);
      if (sdaEnabled && !bwiEnabled) return 'cab-sidoarjo';
      if (bwiEnabled && !sdaEnabled) return 'cab-banyuwangi';
    }
    const mapped = this.entityBranches.crews[crewId] || (rawUserId ? this.entityBranches.crews[rawUserId] : undefined);
    if (mapped && this.branches.some(b => b.id === mapped)) {
      return mapped;
    }
    if (crewName && this.entityBranches.crews[crewName.toLowerCase()]) {
      const byName = this.entityBranches.crews[crewName.toLowerCase()];
      if (this.branches.some(b => b.id === byName)) return byName;
    }
    return 'cab-banyuwangi';
  }

  public syncCrewBranchIdSilent(crewId: string, branchId: string, crewName?: string) {
    if (!branchId || !this.branches.some(b => b.id === branchId)) return;
    this.entityBranches.crews[crewId] = branchId;
    const rawUserId = crewId.replace(/^crw-/, '');
    if (rawUserId) {
      this.entityBranches.crews[rawUserId] = branchId;
    }
    if (crewName) {
      this.entityBranches.crews[crewName.toLowerCase()] = branchId;
    }
  }

  public setCrewBranchId(crewId: string, branchId: string, crewName?: string) {
    this.syncCrewBranchIdSilent(crewId, branchId, crewName);
    this.notify();
  }

  // Strict branch mapping: do not silently treat an unclassified schedule as Banyuwangi.
  public getExplicitScheduleBranchId(scheduleId?: string): string | null {
    if (!scheduleId) return null;
    const mapped = this.entityBranches.schedules[scheduleId];
    return mapped && this.branches.some(b => b.id === mapped) ? mapped : null;
  }

  public getScheduleBranchId(scheduleId?: string, originName?: string, fleetId?: string): string {
    if (scheduleId) {
      const mapped = this.entityBranches.schedules[scheduleId];
      if (mapped && this.branches.some(b => b.id === mapped)) {
        return mapped;
      }
    }
    if (originName) {
      const lower = originName.toLowerCase();
      if (
        lower.includes('sidoarjo') ||
        lower.includes('surabaya') ||
        lower.includes('bliketut') ||
        lower.includes('ponomadi') ||
        lower.includes('latubo') ||
        lower.includes('prolujem') ||
        lower.includes('madura') ||
        lower === 'malang'
      ) {
        return 'cab-sidoarjo';
      }
      if (lower.includes('nusantara') || lower.includes('banyuwangi')) return 'cab-banyuwangi';
      const customMatch = this.branches.find(
        b => lower.includes(b.name.toLowerCase()) || lower.includes(b.slug.toLowerCase())
      );
      if (customMatch) return customMatch.id;
    }
    if (fleetId && this.entityBranches.fleets[fleetId]) {
      const fltBranch = this.entityBranches.fleets[fleetId];
      if (this.branches.some(b => b.id === fltBranch)) return fltBranch;
    }
    return 'cab-banyuwangi';
  }

  public setScheduleBranchId(scheduleId: string, branchId: string) {
    this.entityBranches.schedules[scheduleId] = branchId;
    this.notify();
  }

  public getInventoryBranchId(skuId: string, cabangName?: string): string {
    const mapped = this.entityBranches.inventory[skuId];
    if (mapped && this.branches.some(b => b.id === mapped)) {
      return mapped;
    }
    if (cabangName) {
      const lower = cabangName.toLowerCase();
      const matched = this.branches.find(
        b => b.name.toLowerCase() === lower || b.slug.toLowerCase() === lower || b.city.toLowerCase() === lower
      );
      if (matched) return matched.id;
    }
    const num = parseInt(skuId.replace(/\D/g, '') || '1', 10);
    if (num % 5 === 0) return 'cab-sidoarjo';
    return 'cab-banyuwangi';
  }

  public setInventoryBranchId(skuId: string, branchId: string) {
    this.entityBranches.inventory[skuId] = branchId;
    this.notify();
  }

  public getFleetBranch(
    fleetId: string,
    plateNumber?: string,
    initialCode?: string,
    explicitBranchId?: string
  ): BranchRecord {
    const id = this.getFleetBranchId(fleetId, plateNumber, initialCode, explicitBranchId);
    return this.getBranchById(id) || this.branches[0] || DEFAULT_BRANCHES[1];
  }

  public setFleetBranch(fleetId: string, branchId: string) {
    this.setFleetBranchId(fleetId, branchId);
  }

  public getCrewBranch(crewId: string, crewName?: string): BranchRecord {
    const id = this.getCrewBranchId(crewId, crewName);
    return this.getBranchById(id) || this.branches[0] || DEFAULT_BRANCHES[1];
  }

  public setCrewBranch(crewId: string, branchId: string, crewName?: string) {
    this.setCrewBranchId(crewId, branchId, crewName);
  }

  public getScheduleBranch(scheduleId?: string, originName?: string, fleetId?: string): BranchRecord {
    const id = this.getScheduleBranchId(scheduleId, originName, fleetId);
    return this.getBranchById(id) || this.branches[0] || DEFAULT_BRANCHES[1];
  }

  public setScheduleBranch(scheduleId: string, branchId: string) {
    this.setScheduleBranchId(scheduleId, branchId);
  }

  public getInventoryBranch(skuId: string, cabangName?: string): BranchRecord {
    const id = this.getInventoryBranchId(skuId, cabangName);
    return this.getBranchById(id) || this.branches[0] || DEFAULT_BRANCHES[1];
  }

  public setInventoryBranch(skuId: string, branchId: string) {
    this.setInventoryBranchId(skuId, branchId);
  }

  // ============================================================
  // PER-USER, PER-BRANCH RBAC PERMISSIONS
  // ============================================================
  public getUserBranchPermissions(
    userId: string,
    role: UserRole,
    existingUserModules?: UserPermissions['modules'],
    serverBranchPerms?: UserPermissions['branchPermissions']
  ): Record<string, UserBranchPermissionEntry> {
    const hasServerBranchPerms = Boolean(
      serverBranchPerms && typeof serverBranchPerms === 'object' && Object.keys(serverBranchPerms).length > 0
    );
    const rawSaved = hasServerBranchPerms
      ? serverBranchPerms!
      : (this.userBranchPerms?.[userId] || {});
    const savedForUser = rawSaved && typeof rawSaved === 'object' ? rawSaved : {};
    const result: Record<string, UserBranchPermissionEntry> = {};
    const roleDefaults = getDefaultPermissionsForRole(role);

    this.getBranches().forEach(branch => {
      if (savedForUser[branch.id] && typeof savedForUser[branch.id] === 'object') {
        const cloned = JSON.parse(JSON.stringify(savedForUser[branch.id])) as UserBranchPermissionEntry;
        if (!cloned.modules || typeof cloned.modules !== 'object') {
          cloned.modules = {};
        }
        const isBranchEnabled = Boolean(cloned.enabled);
        Object.keys(roleDefaults).forEach(modId => {
          const modernKeys = MODERN_SUBMENU_KEYS_BY_MODULE[modId] || Object.keys(roleDefaults[modId]?.subMenus || {});
          if (!cloned.modules[modId] || typeof cloned.modules[modId] !== 'object') {
            const sourceMod = isBranchEnabled ? (existingUserModules?.[modId] || roleDefaults[modId]) : undefined;
            const cleanSubs: Record<string, 'none' | 'read_only' | 'full_access'> = {};
            modernKeys.forEach(subId => {
              cleanSubs[subId] = (isBranchEnabled && sourceMod?.enabled) ? (sourceMod?.subMenus?.[subId] || 'none') : 'none';
            });
            const hasActive = modernKeys.some(k => cleanSubs[k] === 'full_access' || cleanSubs[k] === 'read_only');
            cloned.modules[modId] = {
              enabled: Boolean(isBranchEnabled && sourceMod?.enabled && hasActive),
              subMenus: cleanSubs
            };
          } else {
            const cleanSubs: Record<string, 'none' | 'read_only' | 'full_access'> = {};
            modernKeys.forEach(subId => {
              let val = cloned.modules[modId].subMenus?.[subId];
              if (val === undefined && cloned.modules[modId].subMenus) {
                const legacyKeys = LEGACY_SUBMENU_KEY_MAP[subId];
                if (legacyKeys) {
                  for (const lk of legacyKeys) {
                    if (cloned.modules[modId].subMenus[lk] !== undefined) {
                      val = cloned.modules[modId].subMenus[lk];
                      break;
                    }
                  }
                }
              }
              if (val === undefined) {
                val = cloned.modules[modId].enabled ? (roleDefaults[modId]?.subMenus?.[subId] || 'none') : 'none';
              }
              cleanSubs[subId] = cloned.modules[modId].enabled ? val : 'none';
            });
            const hasActive = modernKeys.some(k => cleanSubs[k] === 'full_access' || cleanSubs[k] === 'read_only');
            cloned.modules[modId] = {
              enabled: Boolean(cloned.modules[modId].enabled && hasActive),
              subMenus: cleanSubs
            };
          }
        });
        const activeCountInBranch = this.countActiveModulesInBranch(cloned.modules);
        cloned.enabled = Boolean(isBranchEnabled && activeCountInBranch > 0);
        result[branch.id] = cloned;
      } else {
        // Default: Nusantara (Banyuwangi) is enabled by default only if no other branch is explicitly enabled
        const anyOtherBranchExplicitlyEnabled = Object.entries(savedForUser).some(
          ([bId, bVal]) => bId !== branch.id && Boolean(bVal?.enabled)
        );
        const isDefaultEnabled =
          role === 'super_admin' || (branch.id === 'cab-banyuwangi' && !anyOtherBranchExplicitlyEnabled);
        const baseModules: UserPermissions['modules'] = {};

        Object.keys(roleDefaults).forEach(modId => {
          const modernKeys = MODERN_SUBMENU_KEYS_BY_MODULE[modId] || Object.keys(roleDefaults[modId]?.subMenus || {});
          if (isDefaultEnabled) {
            const sourceMod = existingUserModules?.[modId] !== undefined ? existingUserModules[modId] : roleDefaults[modId];
            const cleanSubs: Record<string, 'none' | 'read_only' | 'full_access'> = {};
            modernKeys.forEach(subId => {
              let savedVal = sourceMod?.subMenus?.[subId];
              if (savedVal === undefined && sourceMod?.subMenus) {
                const legacyKeys = LEGACY_SUBMENU_KEY_MAP[subId];
                if (legacyKeys) {
                  for (const lk of legacyKeys) {
                    if (sourceMod.subMenus[lk] !== undefined) {
                      savedVal = sourceMod.subMenus[lk];
                      break;
                    }
                  }
                }
              }
              cleanSubs[subId] = sourceMod?.enabled ? (savedVal || 'none') : 'none';
            });
            const hasActive = modernKeys.some(k => cleanSubs[k] === 'full_access' || cleanSubs[k] === 'read_only');
            baseModules[modId] = {
              enabled: Boolean(sourceMod?.enabled && hasActive),
              subMenus: cleanSubs
            };
          } else {
            const emptySubs: Record<string, 'none' | 'read_only' | 'full_access'> = {};
            modernKeys.forEach(subId => {
              emptySubs[subId] = 'none';
            });
            baseModules[modId] = {
              enabled: false,
              subMenus: emptySubs
            };
          }
        });

        const activeCount = this.countActiveModulesInBranch(baseModules);
        const totalModules = Object.keys(roleDefaults).length;

        result[branch.id] = {
          branchId: branch.id,
          enabled: isDefaultEnabled && activeCount > 0,
          allAccess: isDefaultEnabled && activeCount === totalModules,
          modules: baseModules
        };
      }
    });

    if (hasServerBranchPerms) {
      this.userBranchPerms[userId] = JSON.parse(JSON.stringify(result));
    }

    return result;
  }

  public saveUserBranchPermissions(
    userId: string,
    branchPerms: Record<string, UserBranchPermissionEntry>
  ) {
    this.userBranchPerms[userId] = JSON.parse(JSON.stringify(branchPerms));
    const sdaEnabled = Boolean(branchPerms['cab-sidoarjo']?.enabled);
    const bwiEnabled = Boolean(branchPerms['cab-banyuwangi']?.enabled);
    if (sdaEnabled && !bwiEnabled) {
      this.syncCrewBranchIdSilent(userId, 'cab-sidoarjo');
      this.syncCrewBranchIdSilent(`crw-${userId}`, 'cab-sidoarjo');
    } else if (bwiEnabled && !sdaEnabled) {
      this.syncCrewBranchIdSilent(userId, 'cab-banyuwangi');
      this.syncCrewBranchIdSilent(`crw-${userId}`, 'cab-banyuwangi');
    }
    this.notify();
  }

  public canUserAccessBranch(
    user: { id: string; role: UserRole; permissions?: UserPermissions } | null | undefined,
    branchId: string
  ): boolean {
    if (!user) return true;
    if (user.role === 'super_admin') return true;
    const perms = this.getUserBranchPermissions(
      user.id,
      user.role,
      user.permissions?.modules,
      user.permissions?.branchPermissions
    );
    return Boolean(perms[branchId]?.enabled);
  }

  public getAccessibleBranchesForUser(
    user?: { id: string; role: UserRole; permissions?: UserPermissions } | null
  ): BranchRecord[] {
    const active = this.getActiveBranches();
    if (!user || user.role === 'super_admin') return active;
    const filtered = active.filter(b => this.canUserAccessBranch(user, b.id));
    return filtered.length > 0 ? filtered : active;
  }

  public countActiveModulesInBranch(modules: UserPermissions['modules']): number {
    if (!modules) return 0;
    return Object.entries(modules).filter(([modId, m]) => {
      if (!m || !m.enabled) return false;
      const modernKeys = MODERN_SUBMENU_KEYS_BY_MODULE[modId];
      const entries = Object.entries(m.subMenus || {});
      const filtered = modernKeys ? entries.filter(([k]) => modernKeys.includes(k)) : entries;
      return filtered.some(([, v]) => v === 'full_access' || v === 'read_only');
    }).length;
  }

  public countActiveSubMenusInModule(mod?: {
    enabled: boolean;
    subMenus: Record<string, 'read_only' | 'full_access' | 'none'>;
  }): number {
    if (!mod || !mod.enabled) return 0;
    const allModernKeys = new Set(Object.values(MODERN_SUBMENU_KEYS_BY_MODULE).flat());
    return Object.entries(mod.subMenus || {}).filter(
      ([k, v]) => allModernKeys.has(k) && (v === 'full_access' || v === 'read_only')
    ).length;
  }

  public getUsersCountForBranch(
    branchId: string,
    usersOrTotalCount?: number | Array<{ id: string; role: UserRole; permissions?: UserPermissions; status?: string }>
  ): number {
    if (Array.isArray(usersOrTotalCount)) {
      let count = 0;
      usersOrTotalCount.forEach(u => {
        if (u.status === 'rejected') return;
        const perms = this.getUserBranchPermissions(
          u.id,
          u.role,
          u.permissions?.modules,
          u.permissions?.branchPermissions
        );
        if (perms[branchId]?.enabled) {
          count++;
        }
      });
      return count;
    }

    let customCount = 0;
    Object.values(this.userBranchPerms).forEach(userMap => {
      if (userMap[branchId]?.enabled) customCount++;
    });
    if (customCount > 0) return customCount;
    if (branchId === 'cab-banyuwangi') return typeof usersOrTotalCount === 'number' ? usersOrTotalCount : 29;
    return 1;
  }
}

export const branchStore = new BranchStoreService();
