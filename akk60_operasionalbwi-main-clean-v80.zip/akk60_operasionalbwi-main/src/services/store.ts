import {
  Fleet,
  Crew,
  RetailStore,
  Schedule,
  TracksolidDevice,
  UserProfile,
  UserRole,
  UserApprovalStatus,
  UserPermissions,
  CrewDeliveryHistory,
  AreaDeliveryStat,
  AreaApprovalRequest,
  SalesOrder,
  AdminActivity,
  AdminSchedule,
  LoadingDurationRecord,
  AdminSkillProfile,
  JobdeskConfig,
  SystemActivity,
  SparePart,
  SparePartUsage,
  SparePartCategory,
  FuelLog,
  FuelType,
  EfficiencyStatus,
  FleetFuelSummary,
  DriverFuelScore,
  ShipmentStatus,
  SwapShiftRequest,
  FleetTireWearPrediction,
  TaxKirReminderItem,
  TaxKirType,
  TaxKirUrgency,
  ImageRecord,
  AutoSyncStatus,
  ScannedDocumentLog,
  ScannedDocumentType,
  SecurityGateLog,
  ChatMessage
} from '../types';

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-101',
    senderId: 'usr-spv-01',
    senderName: 'Budi Santoso',
    senderRole: 'spv_logistik',
    receiverId: 'usr-driver-01',
    receiverName: 'Agus Setiawan',
    receiverRole: 'driver',
    content: 'Pak Agus, tolong cek muatan boks armada DS-1 untuk rute Denpasar esok pagi.',
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    isRead: true,
    cabangId: 'sidoarjo'
  },
  {
    id: 'msg-102',
    senderId: 'usr-driver-01',
    senderName: 'Agus Setiawan',
    senderRole: 'driver',
    receiverId: 'usr-spv-01',
    receiverName: 'Budi Santoso',
    receiverRole: 'spv_logistik',
    content: 'Siap Pak SPV, armada DS-1 sudah selesai muat barang dan gate-out terkonfirmasi.',
    timestamp: new Date(Date.now() - 3600000 * 1.5).toISOString(),
    isRead: true,
    cabangId: 'sidoarjo'
  },
  {
    id: 'msg-103',
    senderId: 'usr-operasional-01',
    senderName: 'Bambang Supeno',
    senderRole: 'operasional',
    receiverId: 'all',
    receiverName: 'Semua Pengguna Logistik',
    receiverRole: 'all',
    content: 'Pengumuman: Jadwal muat malam ini di Gudang Sidoarjo berjalan sesuai rencana.',
    timestamp: new Date(Date.now() - 3600000 * 0.5).toISOString(),
    isRead: false,
    cabangId: 'sidoarjo'
  }
];

import {
  INITIAL_FLEETS,
  INITIAL_CREWS,
  INITIAL_STORES,
  INITIAL_SCHEDULES,
  INITIAL_TRACKSOLID_DEVICES,
  INITIAL_PROFILES,
  INITIAL_CREW_HISTORY,
  INITIAL_AREA_APPROVALS,
  INITIAL_SCANNED_DOCUMENTS,
  resolveCanonicalFleetMeta,
  sortFleetsByCanonicalOrder
} from '../data/mockData';
import {
  INITIAL_SALES_ORDERS,
  INITIAL_ADMIN_ACTIVITIES,
  INITIAL_ADMIN_SCHEDULES,
  INITIAL_LOADING_RECORDS,
  INITIAL_SKILL_PROFILES,
  INITIAL_JOBDESK_CONFIGS
} from '../data/salesMockData';
import {
  INITIAL_SPARE_PARTS,
  INITIAL_SPARE_PART_USAGES
} from '../data/sparePartsMockData';
import {
  INITIAL_FUEL_LOGS,
  FUEL_TARGET_RATIOS
} from '../data/fuelMockData';
import { canAccess, canEdit, getDefaultPermissionsForRole, normalizeUserPermissions } from '../utils/rbac';
import { branchStore, UserBranchPermissionEntry } from './branchStore';
import { AREA_CODE_MAP, standardizeAreaName } from '../utils/areaNormalizer';
import { supabaseRealtimeSync } from './supabaseRealtimeSync';
import {
  createFleetInSupabase,
  updateFleetInSupabase,
  deleteFleetInSupabase,
  createCrewInSupabase,
  updateCrewInSupabase,
  deleteCrewInSupabase,
  syncFleetsAndCrewsWithSupabase as syncSupabaseFleetsAndCrews
} from './supabaseService';

export interface ScheduleChangeLogEntry {
  id: string;
  timestamp: string;
  fileName: string;
  userName: string;
  userRole: string;
  actionType: 'upload_excel' | 'tambah_jadwal' | 'edit_jadwal' | 'hapus_jadwal' | 'manual_create' | 'manual_edit' | 'delete_schedule';
  summary: string;
  changes: string[];
  status?: 'Sukses' | 'Sebagian' | 'Gagal' | 'Peringatan';
  rowCount?: number;
}

const STORAGE_KEYS = {
  FLEETS: 'akk_fleets_v1',
  CREWS: 'akk_crews_v2',
  STORES: 'akk_stores_v1',
  SCHEDULES: 'akk_schedules_v1',
  DEVICES: 'akk_devices_v1',
  CURRENT_USER: 'akk_user_v2',
  AUTH_SESSION: 'akk_auth_session_active_v1',
  SESSION_TOKEN: 'akk_session_token_v1',
  USERS: 'akk_users_list_v5',
  SUPABASE_CONFIG: 'akk_supabase_config_v1',
  CREW_HISTORY: 'akk_crew_history_v1',
  AREA_APPROVALS: 'akk_area_approvals_v1',
  AREA_THRESHOLD: 'akk_area_threshold_v1',
  SALES_ORDERS: 'akk_sales_orders_v1',
  ADMIN_ACTIVITIES: 'akk_admin_activities_v1',
  ADMIN_SCHEDULES: 'akk_admin_schedules_v1',
  LOADING_RECORDS: 'akk_loading_records_v1',
  SKILL_PROFILES: 'akk_skill_profiles_v1',
  JOBDESK_CONFIGS: 'akk_jobdesk_configs_v1',
  SPARE_PARTS: 'akk_spare_parts_v1',
  SPARE_PART_USAGES: 'akk_spare_part_usages_v1',
  FUEL_LOGS: 'akk_fuel_logs_v1',
  IMAGES: 'akk_images_storage_v1',
  SCANNED_DOCUMENTS: 'akk_scanned_documents_v1',
  SECURITY_LOGS: 'akk_security_logs_v1',
  SCHEDULE_CHANGE_LOGS: 'akk_schedule_change_logs_v1',
  MESSAGES: 'akk_chat_messages_v1'
};

const MYSQL_BACKED_STORAGE_KEYS = new Set<string>([
  STORAGE_KEYS.FLEETS,
  STORAGE_KEYS.CREWS,
  STORAGE_KEYS.STORES,
  STORAGE_KEYS.SCHEDULES,
  STORAGE_KEYS.CREW_HISTORY,
  STORAGE_KEYS.AREA_APPROVALS,
  STORAGE_KEYS.AREA_THRESHOLD,
  STORAGE_KEYS.FUEL_LOGS,
  STORAGE_KEYS.SCANNED_DOCUMENTS,
  STORAGE_KEYS.SPARE_PARTS,
  STORAGE_KEYS.SPARE_PART_USAGES,
  STORAGE_KEYS.SALES_ORDERS,
  STORAGE_KEYS.ADMIN_ACTIVITIES,
  STORAGE_KEYS.ADMIN_SCHEDULES,
  STORAGE_KEYS.LOADING_RECORDS,
  STORAGE_KEYS.SKILL_PROFILES,
  STORAGE_KEYS.JOBDESK_CONFIGS,
  STORAGE_KEYS.IMAGES,
  STORAGE_KEYS.SECURITY_LOGS,
  STORAGE_KEYS.SCHEDULE_CHANGE_LOGS,
  STORAGE_KEYS.DEVICES,
  STORAGE_KEYS.MESSAGES,
  'akk_offline_sync_queue',
  'akk_system_activities_v1',
  'akk_admin_schedule_weeks_cache',
  'akk_last_admin_schedule_sync_time',
  'akk_last_admin_schedule_auto_synced',
  'akk_fuel_logs_empty_init_v2'
]);

export const GUEST_USER_PROFILE: UserProfile = {
  id: 'guest',
  email: 'guest@akk-packaging.co.id',
  fullName: 'Tamu / Belum Login',
  role: 'unassigned',
  department: 'Tamu',
  status: 'pending'
};

export const INITIAL_SCHEDULE_CHANGE_LOGS: ScheduleChangeLogEntry[] = [
  {
    id: 'scl-101',
    timestamp: '2026-10-09T21:30:00+07:00',
    fileName: 'Roster_DC_Banyuwangi_Jan2026.xlsx',
    userName: 'Muhammad Syaiful Bahri',
    userRole: 'SPV Logistik',
    actionType: 'upload_excel',
    summary: '121 Baris Tervalidasi • Periode Januari 2026',
    changes: [
      'Menambahkan 38 ritase pengiriman baru pada Minggu 1 - Minggu 4 Januari 2026',
      'Memperbarui alokasi armada DS3 (Supriyanto & Rifaldi) untuk rute DENPASAR 1',
      'Memperbarui penugasan kru Budi Santoso & Rizal untuk rute PURWO PASAR (NS1)',
      'Menyelaraskan 25 nama area kirim dengan standar katalog distribusi AKK'
    ],
    status: 'Sukses'
  },
  {
    id: 'scl-102',
    timestamp: '2026-10-05T14:15:00+07:00',
    fileName: 'Schedule_Sheet_ALL_v2.csv',
    userName: 'Super Admin',
    userRole: 'Super Admin',
    actionType: 'upload_excel',
    summary: '115 Baris Tervalidasi • Sinkronisasi Jadwal Pengiriman',
    changes: [
      'Mengimpor 115 baris jadwal pengiriman dari Sheet ALL',
      'Menyesuaikan rotasi supir luar kota (Bali & Situbondo-Bondowoso)',
      'Memvalidasi 19 personel kru pengemudi dan helper aktif'
    ],
    status: 'Sukses'
  }
];

export const INITIAL_SECURITY_LOGS: SecurityGateLog[] = [
  { id: 'SEC-101', timestamp: new Date(Date.now() - 3600000 * 5).toISOString(), time: '08:15 WIB', type: 'Kendaraan Masuk', entity: 'Truk Box Isuzu W 8229 US', driver: 'Ach Taufiq', purpose: 'Muat Karton Box Ekspedisi Bali', status: 'Diizinkan', plateNumber: 'W 8229 US', securityOfficer: 'Regu A (Bripka Joko)' },
  { id: 'SEC-102', timestamp: new Date(Date.now() - 3600000 * 4).toISOString(), time: '09:30 WIB', type: 'Tamu Rekanan', entity: 'PT Surya Paperindo Utama', driver: 'Ir. Hendra (Vendor Kertas)', purpose: 'Inspeksi Bahan Baku Roll', status: 'Selesai', securityOfficer: 'Regu A (Hairul Rozikin)' },
  { id: 'SEC-103', timestamp: new Date(Date.now() - 3600000 * 2).toISOString(), time: '11:00 WIB', type: 'Kendaraan Keluar', entity: 'Pick Up Box P 8125 VC [N1]', initialCode: 'N1', driver: 'Zainul Agustiar', purpose: 'Pengiriman Retail Banyuwangi', status: 'Gate-Out', plateNumber: 'P 8125 VC', securityOfficer: 'Regu A (Hairul Rozikin)' },
  { id: 'SEC-104', timestamp: new Date(Date.now() - 1800000).toISOString(), time: '13:45 WIB', type: 'Patroli Satpam', entity: 'Area Gudang DC & Tangki Solar', driver: 'Regu A (Bripka Joko dkk)', purpose: 'Pengecekan Segel Gerbang & APAR', status: 'Aman', securityOfficer: 'Regu A (Bripka Joko)' }
];

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConnected: boolean;
}

export interface OfflineScheduleStatusUpdate {
  id: string;
  scheduleId: string;
  trackingNumber: string;
  status: Schedule['status'];
  extraNotes?: string;
  podData?: {
    podPhotoUrl?: string;
    podReceiverName?: string;
    podConditionNote?: string;
    podPhotoTimestamp?: string;
  };
  timestamp: string;
}

/**
 * Filter helper to ensure delivery route areas / destinations are NOT treated as retail stores.
 */
export function isAreaRouteItem(store: Partial<RetailStore>): boolean {
  if (!store) return false;
  if (store.id && (store.id.startsWith('str-smart-') || store.id.startsWith('area-dest-') || store.id.startsWith('area-'))) return true;
  if (store.storeCode && (
    store.storeCode.startsWith('STR-DEN-') ||
    store.storeCode.startsWith('STR-SIT-') ||
    store.storeCode.startsWith('STR-BON-') ||
    store.storeCode.startsWith('STR-JEM-') ||
    store.storeCode.startsWith('STR-BUL-') ||
    store.storeCode.startsWith('STR-BAN-') ||
    store.storeCode.startsWith('STR-') ||
    store.storeCode.startsWith('ARE-') ||
    store.storeCode.startsWith('AREA-')
  )) return true;

  const AREA_DESTINATION_NAMES = new Set([
    'denpasar 1 retail utama',
    'denpasar 2 supermarket hub',
    'situbondo retail cluster',
    'bondowoso distribution hub',
    'susulan genteng - rogojampi',
    'jember selatan retail hub',
    'singaraja bali distribution',
    'sumberayu retail store',
    'galekan retail mart',
    'grosir 1 banyuwangi kota',
    'susulan sanggar - jajag',
    'genteng retail store',
    'rogojampi retail store',
    'muncar pasar central',
    'muncar pinggir retail',
    'susulan singaraja bali',
    'susulan situbondo - bondowoso',
    'jember barat distribution',
    'grosir 2 retail hub',
    'songgon retail mart',
    'bwi kota selatan retail',
    'ketapang - wongsorejo store',
    'sanggar retail mart',
    'kalibaru retail hub',
    'grosir 3 distribution',
    'susulan rogojampi - muncar',
    'sempu stail retail store',
    'negara bali barat mart',
    'jember kota central mall hub',
    'purwo pasar central',
    'purwo dambuntung retail',
    'jajag retail hub',
    'srono retail store',
    'grosir 4 hub banyuwangi'
  ]);

  const nameLower = (store.storeName || '').trim().toLowerCase();
  if (AREA_DESTINATION_NAMES.has(nameLower)) return true;
  if (/^toko\s+ritel\b/i.test(nameLower)) return true;
  if (/indomar(e|ke)t|alfamart/i.test(nameLower)) return true;
  return false;
}

export const KNOWN_PO_AREA_MAP: Record<string, string> = {
  'PO-AKK-20260105-DS3-1': 'DENPASAR 1',
  'PO-AKK-20260105-DS1-2': 'DENPASAR 2',
  'PO-AKK-20260105-NS3-3': 'BONDOWOSO',
  'PO-AKK-20260105-DS2-4': 'SITUBONDO',
  'PO-AKK-20260105-DS4-5': 'SUSULAN GENTENG - ROGOJAMPI',
  'PO-AKK-20260105-NS2-6': 'PURWO DAMBUNTUNG',
  'PO-AKK-20260105-NS1-7': 'PURWO PASAR',
  'PO-AKK-20260105-N20-8': 'JAJAG RETAIL',
  'PO-AKK-20260106-DS5-1': 'SINGARAJA',
  'PO-AKK-20260106-NL2-2': 'SUMBERAYU RETAIL',
  'PO-AKK-20260106-NL1-3': 'GALEKAN',
  'PO-AKK-20260106-DS4-4': 'GROSIR BWI - ROGOJAMPI',
  'PO-AKK-20260106-NS1-5': 'SUSULAN SANGGAR JAJAG',
};

export const SMART_ROUTE_AREA_MAP: Record<string, string> = {
  'str-smart-senin-0': 'Denpasar 1',
  'str-smart-senin-1': 'Denpasar 2',
  'str-smart-senin-2': 'Situbondo',
  'str-smart-senin-3': 'Bondowoso',
  'str-smart-senin-4': 'Susulan Genteng - Rogojampi',
  'str-smart-selasa-0': 'Jember Selatan',
  'str-smart-selasa-1': 'Singaraja Bali',
  'str-smart-selasa-2': 'Sumberayu',
  'str-smart-selasa-3': 'Galekan',
  'str-smart-selasa-4': 'Grosir 1 Banyuwangi Kota',
  'str-smart-selasa-5': 'Susulan Sanggar - Jajag',
  'str-smart-rabu-0': 'Denpasar 1',
  'str-smart-rabu-1': 'Denpasar 2',
  'str-smart-rabu-2': 'Genteng',
  'str-smart-rabu-3': 'Rogojampi',
  'str-smart-rabu-4': 'Muncar Pasar Central',
  'str-smart-rabu-5': 'Muncar Pinggir',
  'str-smart-kamis-0': 'Susulan Singaraja Bali',
  'str-smart-kamis-1': 'Susulan Situbondo - Bondowoso',
  'str-smart-kamis-2': 'Jember Barat',
  'str-smart-kamis-3': 'Grosir 2 Banyuwangi',
  'str-smart-kamis-4': 'Songgon',
  'str-smart-kamis-5': 'BWI Kota Selatan',
  'str-smart-jumat-0': 'Ketapang - Wongsorejo',
  'str-smart-jumat-1': 'Sanggar',
  'str-smart-jumat-2': 'Kalibaru',
  'str-smart-jumat-3': 'Grosir 3 Banyuwangi',
  'str-smart-jumat-4': 'Susulan Rogojampi - Muncar',
  'str-smart-jumat-5': 'Sempu Stail',
  'str-smart-sabtu-0': 'Negara Bali Barat',
  'str-smart-sabtu-1': 'Jember Kota',
  'str-smart-sabtu-2': 'Purwo Pasar Central',
  'str-smart-sabtu-3': 'Purwo Dambuntung',
  'str-smart-sabtu-4': 'Jajag',
  'str-smart-sabtu-5': 'Srono',
  'str-smart-sabtu-6': 'Grosir 4 Banyuwangi'
};

export const INITIAL_TRK_AREA_MAP: Record<string, string> = {
  'TRK-2026-09-082': 'Denpasar 1 (Bali)',
  'TRK-2026-09-083': 'Situbondo - Probolinggo',
  'TRK-2026-09-084': 'Balikpapan & Luar Pulau',
  'TRK-2026-09-085': 'Jember Kota',
  'TRK-2026-09-079': 'Singaraja (Bali Utara)',
};

/**
 * Resolves the official Delivery Area Name (Nama Area Kirim) for any schedule,
 * preventing accidental display of customer store names like "BU TIWI GENTENG"
 */
export function resolveScheduleAreaName(sch: Partial<Schedule>): string {
  if (!sch) return 'Area Pengiriman';

  // 0. If explicit areaName is provided and valid, prioritize it
  if (sch.areaName && sch.areaName.trim() && !sch.areaName.startsWith('str-') && !sch.areaName.startsWith('RET-') && !sch.areaName.toLowerCase().includes('tiwi') && !sch.areaName.toLowerCase().includes('holly')) {
    const cleanArea = sch.areaName.trim();
    const upperClean = cleanArea.toUpperCase();
    if (upperClean === 'DENPASAR 1 & 2' || upperClean === 'DENPASAR 1&2' || upperClean === 'DENPASAR 1 / 2' || upperClean === 'DENPASAR') {
      return 'DENPASAR 1';
    }
    if (AREA_CODE_MAP[upperClean]) {
      return AREA_CODE_MAP[upperClean];
    }
    return standardizeAreaName(cleanArea);
  }

  // 1. Direct storeId match against AREA_CODE_MAP or SMART_ROUTE_AREA_MAP
  const sId = (sch.storeId || sch.store?.id || '').trim();
  const sIdUpper = sId.toUpperCase();
  if (AREA_CODE_MAP[sIdUpper]) return AREA_CODE_MAP[sIdUpper];
  if ( sIdUpper === 'SITUBONDO') return 'SITUBONDO';
  if (sIdUpper === 'TOKO_DR_SOETOMO' || sIdUpper === 'TOKO DR. SOETOMO') return 'TOKO DR. SOETOMO';
  if (sIdUpper === 'NUSANTARA_EXPAND' || sIdUpper === 'NUSANTARA EXPAND') return 'NUSANTARA EXPAND';
  if (SMART_ROUTE_AREA_MAP[sId]) return SMART_ROUTE_AREA_MAP[sId];

  // 2. Direct tracking number / PO match
  const trk = (sch.trackingNumber || '').trim().toUpperCase();
  if (KNOWN_PO_AREA_MAP[trk]) return KNOWN_PO_AREA_MAP[trk];
  if (INITIAL_TRK_AREA_MAP[trk]) return INITIAL_TRK_AREA_MAP[trk];

  // 3. Extract from cargoDescription (e.g. "Karton Box & Sheet Kemasan - Area DENPASAR 2")
  if (sch.cargoDescription) {
    const areaMatch = sch.cargoDescription.match(/Area\s+([^,•\n\-]+)/i);
    if (areaMatch && areaMatch[1] && areaMatch[1].trim()) {
      return areaMatch[1].trim().toUpperCase();
    }
  }

  // 4. Extract from notes
  if (sch.notes) {
    const noteMatch = sch.notes.match(/Area\s+([^,•\n\-]+)/i);
    if (noteMatch && noteMatch[1] && noteMatch[1].trim()) {
      return noteMatch[1].trim();
    }
  }

  // 5. If store exists, check its storeName
  if (sch.store) {
    if (isAreaRouteItem(sch.store)) {
      return sch.store.storeName
        .replace(/(Retail Utama|Supermarket Hub|Retail Cluster|Distribution Hub|Store|Mart)$/i, '')
        .trim();
    }
    if (sch.store.city && sch.store.city !== 'Banyuwangi') {
      return sch.store.city.replace(/^Banyuwangi\s*\((.*?)\)$/i, '$1').trim();
    }
  }

  return 'Area Pengiriman';
}

/**
 * Safe localStorage writer that handles QuotaExceededError automatically by purging temporary caches
 */
export function safeSetItem(key: string, value: string): boolean {
  try {
    localStorage.setItem(key, value);
    return true;
  } catch {
    // Purge temporary/cached keys silently to free quota without crashing or throwing
    const tempKeysToPurge = [
      'akk_simulasi_weeks_v2',
      'akk_schedule_grid_v2',
      'akk_backup_acc_grid_v2',
      'akk_checklist_history',
      'procurement_form_draft',
      'service_form_draft',
      'akk_offline_sync_queue',
      'akk_notifications_v1',
      'RAW_ADMIN_SPREADSHEET_CSV',
      'akk_csv_raw_backup',
      'akk_admin_schedule_weeks_cache',
      'akk_system_activities_v1',
      'akk_gsheets_sync_logs_v1',
      'akk_crew_history_v1'
    ];

    tempKeysToPurge.forEach(k => {
      try { localStorage.removeItem(k); } catch {}
    });

    // Try saving again
    try {
      localStorage.setItem(key, value);
      return true;
    } catch {
      // If still fails, clear old monthly caches and non-essential history keys
      try {
        Object.keys(localStorage).forEach(lk => {
          if (lk.startsWith('akk_admin_schedule_cache_') || lk.startsWith('akk_images_')) {
            try { localStorage.removeItem(lk); } catch {}
          }
        });
        localStorage.setItem(key, value);
        return true;
      } catch {
        // Return false silently so app continues operating smoothly in memory without crashing React
        return false;
      }
    }
  }
}

export type EntityType = 'schedule' | 'fleet' | 'crew' | 'store' | 'image' | 'manifest' | 'admin_schedule' | 'fuel' | 'approval';
export type EntityAction = 'create' | 'update' | 'delete' | 'status_change' | 'upload';

export interface EntityChangeEvent<T = any> {
  entityType: EntityType;
  action: EntityAction;
  id: string;
  data: T;
  previousData?: T;
  timestamp: string;
  metadata?: Record<string, any>;
}

export type StoreMiddleware = (event: EntityChangeEvent) => Promise<void> | void;

class LogisticsStore {
  private fleets: Fleet[] = [];
  private crews: Crew[] = [];
  private stores: RetailStore[] = [];
  private schedules: Schedule[] = [];
  private devices: TracksolidDevice[] = [];
  private users: UserProfile[] = [];
  private currentUser: UserProfile;
  private supabaseConfig: SupabaseConfig;
  private crewHistory: CrewDeliveryHistory[] = [];
  private areaApprovals: AreaApprovalRequest[] = [];
  private areaThreshold: number = 3;
  private salesOrders: SalesOrder[] = [];
  private adminActivities: AdminActivity[] = [];
  private adminSchedules: AdminSchedule[] = [];
  private loadingRecords: LoadingDurationRecord[] = [];
  private skillProfiles: AdminSkillProfile[] = [];
  private jobdeskConfigs: JobdeskConfig[] = [];
  private systemActivities: SystemActivity[] = [];
  private spareParts: SparePart[] = [];
  private sparePartUsages: SparePartUsage[] = [];
  private fuelLogs: FuelLog[] = [];
  private pendingFuelLogUpserts: Map<string, FuelLog> = new Map();
  private pendingFuelLogDeletes: Set<string> = new Set();
  private imageRecords: ImageRecord[] = [];
  private scannedDocuments: ScannedDocumentLog[] = [];
  private securityLogs: SecurityGateLog[] = [];
  private scheduleChangeLogs: ScheduleChangeLogEntry[] = [];
  private messages: ChatMessage[] = [];
  private adminScheduleWeeksCache: Record<string, any[]> = {};
  private lastAdminScheduleWeeksList: any[] = [];
  private autoSyncStatus: AutoSyncStatus = {
    isSyncing: false,
    lastSyncTime: null,
    syncedCount: 0,
    pendingQueue: 0,
    lastError: null,
    lastSyncedEntity: null
  };
  private autoSyncListeners: Array<(status: AutoSyncStatus) => void> = [];
  private listeners: Array<() => void> = [];
  private notificationListeners: Array<(notif: any) => void> = [];
  private middlewares: StoreMiddleware[] = [];
  private offlineScheduleQueue: OfflineScheduleStatusUpdate[] = [];

  private previewSessionPromise: Promise<boolean> | null = null;

  public isPreviewEnvironment(): boolean {
    if (!import.meta?.env?.PROD) return true;
    if (typeof window !== 'undefined') {
      const host = (window.location.hostname || '').toLowerCase();
      if (host.endsWith('.run.app') || host === 'localhost' || host === '127.0.0.1') {
        return true;
      }
    }
    return false;
  }

  public async ensurePreviewServerSession(force: boolean = false): Promise<boolean> {
    if (!this.isPreviewEnvironment() || typeof fetch === 'undefined') return false;
    if (this.previewSessionPromise && !force) return this.previewSessionPromise;
    const candidate = this.resolveLocalCandidateUser();
    if (!candidate) return false;
    if (!force) {
      const existingToken =
        (typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.SESSION_TOKEN) : null) ||
        (typeof sessionStorage !== 'undefined' ? sessionStorage.getItem(STORAGE_KEYS.SESSION_TOKEN) : null) ||
        '';
      if (existingToken) return true;
    }
    const run = (async () => {
      try {
        const res = await fetch('/api/auth/preview-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify({
            id: candidate.id,
            email: candidate.email,
            fullName: candidate.fullName,
            role: candidate.role,
            department: candidate.department,
            phone: candidate.phone,
            permissions: candidate.permissions,
            notes: candidate.notes
          })
        });
        const payload = await res.json().catch(() => ({}));
        if (!res.ok || !payload?.sessionToken) return false;
        try {
          if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEYS.SESSION_TOKEN, String(payload.sessionToken));
          if (typeof sessionStorage !== 'undefined') sessionStorage.setItem(STORAGE_KEYS.SESSION_TOKEN, String(payload.sessionToken));
        } catch {}
        return true;
      } catch {
        return false;
      }
    })();
    this.previewSessionPromise = run;
    try {
      return await run;
    } finally {
      if (this.previewSessionPromise === run) this.previewSessionPromise = null;
    }
  }

  constructor() {
    const isProd = Boolean(import.meta?.env?.PROD) && !this.isPreviewEnvironment();
    // Bersihkan kunci localStorage bisnis lama agar data tidak tersimpan di localStorage browser (100% MySQL Hostinger)
    if (typeof localStorage !== 'undefined') {
      try {
        MYSQL_BACKED_STORAGE_KEYS.forEach((k) => localStorage.removeItem(k));
        Object.keys(localStorage).forEach((k) => {
          if (k.startsWith('akk_admin_schedule_cache_')) {
            localStorage.removeItem(k);
          }
        });
      } catch {}
    }

    this.offlineScheduleQueue = [];
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => {
        this.syncOfflineQueueToSupabase();
      });
      setInterval(() => {
        if (navigator.onLine && this.offlineScheduleQueue.length > 0) {
          this.syncOfflineQueueToSupabase();
        }
      }, 30000);
    }
    this.fleets = isProd ? [] : INITIAL_FLEETS;
    this.crews = isProd ? [] : INITIAL_CREWS;
    this.stores = [...INITIAL_STORES];
    this.schedules = [];
    this.devices = isProd ? [] : INITIAL_TRACKSOLID_DEVICES;
    this.users = this.loadFromStorage(STORAGE_KEYS.USERS, isProd ? [] : INITIAL_PROFILES);
    this.messages = [];

    // Passwords are never stored in browser state; authentication is handled by Hostinger MySQL in production.
    // In preview environment, ensure INITIAL_PROFILES are merged so preview login always recognizes standard accounts.
    if (!isProd) {
      const existingById = new Map((this.users || []).map(u => [u.id, u]));
      const existingByEmail = new Map(
        (this.users || [])
          .filter(u => u.email)
          .map(u => [u.email.trim().toLowerCase(), u])
      );
      const mergedUsers: UserProfile[] = [...(this.users || [])];
      INITIAL_PROFILES.forEach(initU => {
        const cleanEmail = (initU.email || '').trim().toLowerCase();
        const existing = existingById.get(initU.id) || (cleanEmail ? existingByEmail.get(cleanEmail) : undefined);
        if (!existing) {
          mergedUsers.push({
            ...initU,
            password: undefined
          } as UserProfile);
        }
      });
      this.users = mergedUsers;
    }
    const isObsoleteMuhammadShoim = (u: Partial<UserProfile> | null | undefined): boolean => {
      if (!u) return false;
      const cleanId = String(u.id || '').trim().toLowerCase();
      const cleanEmail = String(u.email || '').trim().toLowerCase();
      const cleanName = String(u.fullName || '').trim().toLowerCase().replace(/\s+/g, ' ');
      return (
        cleanId === 'usr-sales' ||
        cleanEmail === 'shoim.sales@gmail.com' ||
        cleanName === 'muhammad shoim'
      );
    };

    this.users = (this.users || [])
      .filter(u => !isObsoleteMuhammadShoim(u))
      .map(u => ({ ...u, password: undefined } as UserProfile));
    this.saveToStorage(STORAGE_KEYS.USERS, this.users);

    // Initial authentication session from sessionStorage or localStorage
    const sessionUserId =
      (typeof sessionStorage !== 'undefined' ? sessionStorage.getItem(STORAGE_KEYS.AUTH_SESSION) : null) ||
      (typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.AUTH_SESSION) : null);
    const savedCurrentUser = this.loadFromStorage<UserProfile | null>(STORAGE_KEYS.CURRENT_USER, null);

    if (sessionUserId) {
      const activeMatch =
        this.users.find(u => u.id === sessionUserId && u.status === 'approved') ||
        (savedCurrentUser && savedCurrentUser.id !== 'guest' && savedCurrentUser.status === 'approved' ? savedCurrentUser : undefined);
      this.currentUser = activeMatch ? { ...activeMatch } : { ...GUEST_USER_PROFILE };
    } else if (savedCurrentUser && savedCurrentUser.id !== 'guest' && savedCurrentUser.status === 'approved') {
      this.currentUser = { ...savedCurrentUser };
      try {
        if (typeof sessionStorage !== 'undefined') sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, savedCurrentUser.id);
        if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, savedCurrentUser.id);
      } catch {}
    } else {
      this.currentUser = { ...GUEST_USER_PROFILE };
    }

    // Sync active session if authenticated
    if (this.currentUser && this.currentUser.id !== 'guest') {
      const match = this.users.find(u => (u.id === this.currentUser.id || (u.email && this.currentUser.email && u.email.toLowerCase() === this.currentUser.email.toLowerCase())) && u.status === 'approved');
      if (match) {
        this.currentUser = { ...match };
        this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
        try {
          if (typeof sessionStorage !== 'undefined') sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, this.currentUser.id);
          if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, this.currentUser.id);
        } catch {}
      } else if (this.currentUser.status === 'approved') {
        this.users = [this.currentUser, ...this.users];
        this.saveToStorage(STORAGE_KEYS.USERS, this.users);
        this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
        try {
          if (typeof sessionStorage !== 'undefined') sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, this.currentUser.id);
          if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, this.currentUser.id);
        } catch {}
      } else {
        this.currentUser = { ...GUEST_USER_PROFILE };
        try {
          if (typeof sessionStorage !== 'undefined') sessionStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
          if (typeof localStorage !== 'undefined') localStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
        } catch {}
      }
    }
    this.crewHistory = [];
    this.areaApprovals = [];
    this.areaThreshold = 3;
    this.salesOrders = isProd ? [] : INITIAL_SALES_ORDERS;
    this.adminActivities = isProd ? [] : INITIAL_ADMIN_ACTIVITIES;
    this.adminSchedules = isProd ? [] : INITIAL_ADMIN_SCHEDULES;
    this.loadingRecords = isProd ? [] : INITIAL_LOADING_RECORDS;
    this.skillProfiles = isProd ? [] : INITIAL_SKILL_PROFILES;
    this.jobdeskConfigs = isProd ? [] : INITIAL_JOBDESK_CONFIGS;
    this.spareParts = isProd ? [] : INITIAL_SPARE_PARTS;
    this.sparePartUsages = isProd ? [] : INITIAL_SPARE_PART_USAGES;
    this.fuelLogs = [];
    this.imageRecords = [];
    this.scannedDocuments = [];
    this.securityLogs = isProd ? [] : INITIAL_SECURITY_LOGS;
    this.scheduleChangeLogs = isProd ? [] : INITIAL_SCHEDULE_CHANGE_LOGS;
    this.systemActivities = [];
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        if (this.isAuthenticated()) {
          void this.hydrateSystemActivitiesFromServer();
        }
      }, 1800);
    }
    // Legacy config object retained only so older UI state does not crash after migration.
    // No Supabase URL/key is embedded in the browser anymore; Hostinger MySQL is accessed via /api/*.
    const savedSupabaseConf = this.loadFromStorage(STORAGE_KEYS.SUPABASE_CONFIG, {
      url: '',
      anonKey: '',
      isConnected: true
    });
    this.supabaseConfig = {
      url: savedSupabaseConf?.url || '',
      anonKey: savedSupabaseConf?.anonKey || '',
      isConnected: savedSupabaseConf?.isConnected ?? true
    };

    // Synchronize crew pool directly with User Management (driver & crew_helper)
    if (!this.crews || !Array.isArray(this.crews)) {
      this.crews = [];
    }

    if (!isProd) {
      const isCorruptedStackedStores = this.stores && this.stores.length > 5 && this.stores.filter(s => Math.abs(s.latitude - (-8.36)) < 0.01 && Math.abs(s.longitude - 114.15) < 0.01).length > this.stores.length * 0.8;
      if (!this.stores || this.stores.length === 0 || isCorruptedStackedStores) {
        this.stores = [...INITIAL_STORES];
        this.saveToStorage(STORAGE_KEYS.STORES, this.stores);
      } else {
        let storesUpdated = false;
        const filteredStores = this.stores.filter(s => !isAreaRouteItem(s));
        if (filteredStores.length !== this.stores.length) {
          storesUpdated = true;
        }
        this.stores = filteredStores.map((s, idx) => {
          const ref = INITIAL_STORES.find(initS => initS.id === s.id || initS.storeCode === s.storeCode || initS.storeName.toLowerCase() === (s.storeName || '').toLowerCase());
          const nextKecamatan = s.kecamatan || ref?.kecamatan || ((s.city || '').match(/\((.*?)\)/)?.[1]) || s.city || 'Genteng';
          const nextKabupaten = s.kabupaten || ref?.kabupaten || (s.city || '').replace(/\s*\(.*?\)/g, '').replace(/^Kota\s+/i, '') || 'Banyuwangi';
          const nextNomor = s.nomor ?? ref?.nomor ?? idx + 1;
          if (s.kecamatan !== nextKecamatan || s.kabupaten !== nextKabupaten || s.nomor !== nextNomor) {
            storesUpdated = true;
            return {
              ...s,
              nomor: nextNomor,
              kecamatan: nextKecamatan,
              kabupaten: nextKabupaten
            };
          }
          return s;
        });

        if (storesUpdated) {
          this.saveToStorage(STORAGE_KEYS.STORES, this.stores);
        }
      }
    } else {
      this.stores = Array.isArray(this.stores) ? this.stores.filter(s => !isAreaRouteItem(s)) : [];
    }

    this.runDataMigrations();
  }

  private deduplicateSuperAdmins(usersList: UserProfile[]): UserProfile[] {
    const isProd = Boolean(import.meta?.env?.PROD) && !this.isPreviewEnvironment();
    let primarySuperAdmin: UserProfile | null = null;
    const seenIds = new Set<string>();
    const seenEmails = new Set<string>();
    const filtered: UserProfile[] = [];

    for (const rawUser of usersList) {
      const cleanEmail = (rawUser.email || '').trim().toLowerCase();
      const rawFullName = (rawUser.fullName || '').trim();

      // Pastikan akun Hendri (hendri123@gmail.com / usr-hendri) tidak pernah berubah nama menjadi "Super Admin"
      // dan tidak pernah digabung dengan akun utama akkoperasional60@gmail.com
      const isHendriAccount =
        rawUser.id === 'usr-hendri' ||
        cleanEmail === 'hendri123@gmail.com' ||
        rawFullName.toLowerCase() === 'hendri';

      const u: UserProfile = isHendriAccount
        ? {
            ...rawUser,
            fullName: (!rawFullName || rawFullName.toLowerCase() === 'super admin') ? 'Hendri' : rawFullName
          }
        : rawUser;

      // Hanya gabungkan duplikat akun Super Admin generik/utama (akkoperasional60@gmail.com / admin@gmail.com / bootstrap / preview),
      // JANGAN gabungkan user berbeda yang kebetulan memiliki role super_admin (seperti hendri123@gmail.com).
      const isGenericPrimarySuperAdmin =
        !isHendriAccount &&
        (
          cleanEmail === 'akkoperasional60@gmail.com' ||
          cleanEmail === 'admin@gmail.com' ||
          u.id === 'usr-001' ||
          u.id.startsWith('usr-preview-') ||
          u.id.startsWith('usr-bootstrap-') ||
          (u.role === 'super_admin' && (!cleanEmail || rawFullName.toLowerCase() === 'super admin'))
        );

      if (isGenericPrimarySuperAdmin) {
        if (!primarySuperAdmin) {
          primarySuperAdmin = {
            ...u,
            fullName: rawFullName || 'Super Admin',
            role: 'super_admin',
            department: u.department || 'Manajemen & Direksi',
            status: 'approved',
            permissions: u.permissions?.modules ? u.permissions : { modules: getDefaultPermissionsForRole('super_admin') }
          };
          seenIds.add(primarySuperAdmin.id);
          if (cleanEmail) seenEmails.add(cleanEmail);
          filtered.push(primarySuperAdmin);
        } else if (cleanEmail === 'akkoperasional60@gmail.com' && (primarySuperAdmin.email || '').toLowerCase() !== 'akkoperasional60@gmail.com') {
          // Utamakan record resmi akkoperasional60@gmail.com dari MySQL dibanding placeholder lokal
          const idx = filtered.indexOf(primarySuperAdmin);
          primarySuperAdmin = {
            ...u,
            fullName: rawFullName || 'Super Admin',
            role: 'super_admin',
            department: u.department || 'Manajemen & Direksi',
            status: 'approved',
            permissions: u.permissions?.modules ? u.permissions : { modules: getDefaultPermissionsForRole('super_admin') }
          };
          if (idx >= 0) filtered[idx] = primarySuperAdmin;
          seenIds.add(primarySuperAdmin.id);
          seenEmails.add(cleanEmail);
        }
        continue;
      }

      if (seenIds.has(u.id) || (cleanEmail && seenEmails.has(cleanEmail))) {
        continue;
      }
      seenIds.add(u.id);
      if (cleanEmail) seenEmails.add(cleanEmail);
      filtered.push(u);
    }

    // Hanya preview/development yang boleh memiliki fallback user lokal.
    // Production harus mengambil user dari Hostinger MySQL; database kosong berarti UI kosong.
    if (!primarySuperAdmin && !isProd) {
      const previewDefault = INITIAL_PROFILES.find(u => u.role === 'super_admin');
      if (previewDefault) filtered.unshift({ ...previewDefault, password: undefined } as UserProfile);
    }

    return filtered;
  }

  private runDataMigrations() {
    // 1. Deduplicate Super Admin accounts so only 1 primary Super Admin exists
    this.users = this.deduplicateSuperAdmins(this.users);

    // 2. Ensure each user has valid, normalized permissions for their role without overwriting custom read_only/none settings
    this.users = this.users.map(u => ({
      ...u,
      permissions: normalizeUserPermissions(u.role, u.permissions)
    }));
    this.saveToStorage(STORAGE_KEYS.USERS, this.users);

    if (this.currentUser && this.currentUser.id !== 'guest') {
      const currEmail = (this.currentUser.email || '').trim().toLowerCase();
      const matchedUser = this.users.find(
        u =>
          u.id === this.currentUser.id ||
          (currEmail && (u.email || '').trim().toLowerCase() === currEmail)
      );
      if (matchedUser) {
        this.currentUser = {
          ...matchedUser,
          permissions: normalizeUserPermissions(matchedUser.role, matchedUser.permissions)
        };
        this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
        try {
          if (typeof sessionStorage !== 'undefined') sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, this.currentUser.id);
          if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, this.currentUser.id);
        } catch {}
      } else {
        this.currentUser = {
          ...this.currentUser,
          permissions: normalizeUserPermissions(this.currentUser.role, this.currentUser.permissions)
        };
        this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
      }
    }

    // Synchronize crews strictly with User Management (driver & crew_helper)
    this.syncUsersWithCrews();

    let updatedFleets = false;

    // Purge any fleet whose plate number ends with 'AKK' or is a phantom FLT-* placeholder
    const isPhantomFleet = (plate?: string): boolean => {
      const p = String(plate || '').trim().toUpperCase();
      return !p || p.endsWith('AKK') || /^FLT-\d+$/i.test(p);
    };
    const filteredFleets = this.fleets.filter(f => !isPhantomFleet(f.plateNumber));
    if (filteredFleets.length !== this.fleets.length) {
      this.fleets = filteredFleets;
      updatedFleets = true;
    }

    // Merge initial fleets only in development/preview mode
    if (this.isPreviewEnvironment()) {
      INITIAL_FLEETS.forEach(initF => {
        const cleanInitPlate = String(initF.plateNumber || '').replace(/\s+/g, '').toUpperCase();
        const exists = this.fleets.some(
          f => f.id === initF.id || String(f.plateNumber || '').replace(/\s+/g, '').toUpperCase() === cleanInitPlate
        );
        if (!exists && !isPhantomFleet(initF.plateNumber)) {
          this.fleets.push({ ...initF });
          updatedFleets = true;
        }
      });
    }

    // Deduplicate fleets by normalized plateNumber so no doubles remain
    const seenInitPlates = new Set<string>();
    const dedupedInitFleets = this.fleets.filter(f => {
      const cleanP = String(f.plateNumber || '').replace(/\s+/g, '').toUpperCase();
      if (!cleanP || isPhantomFleet(f.plateNumber)) return false;
      if (seenInitPlates.has(cleanP)) return false;
      seenInitPlates.add(cleanP);
      return true;
    });
    if (dedupedInitFleets.length !== this.fleets.length) {
      this.fleets = dedupedInitFleets;
      updatedFleets = true;
    }

    this.fleets = this.fleets.map((f, idx) => {
      let changed = false;

      // Migrate legacy Jakarta plate B 9421 UXT to P 8125 VC (Mitsubishi L300)
      if (f.plateNumber === 'B 9421 UXT') {
        return {
          ...f,
          id: 'flt-01',
          plateNumber: 'P 8125 VC',
          vehicleType: f.vehicleType || 'Pick Up Box',
          initialCode: f.initialCode || 'N1 / NP1',
          brand: f.brand || 'Mitsubishi L300',
          engineCc: f.engineCc || '2477 CC',
          boxCapacityM3: f.boxCapacityM3 || 5.5,
          boxDimensions: f.boxDimensions || '2.4 x 1.6 x 1.4 m',
          year: f.year || 2004,
          gpsImei: f.gpsImei || '',
          lastMaintenance: f.lastMaintenance || '2026-12-23',
          taxDueDate: f.taxDueDate || '2027-06-25',
          stnkExpiryDate: f.stnkExpiryDate || '2029-06-25'
        };
      }

      // Migrate legacy Jakarta plate B 9128 UYX to P 8509 VQ (Traga Pick Up Box)
      if (f.plateNumber === 'B 9128 UYX') {
        return {
          ...f,
          id: 'flt-02',
          plateNumber: 'P 8509 VQ',
          vehicleType: f.vehicleType || 'Pick Up Box',
          initialCode: f.initialCode || 'A3 / NP3',
          brand: f.brand || 'Traga',
          engineCc: f.engineCc || '2499 CC',
          boxCapacityM3: f.boxCapacityM3 || 6.2,
          boxDimensions: f.boxDimensions || '2.8 x 1.6 x 1.4 m',
          year: f.year || 2021,
          gpsImei: f.gpsImei || '',
          lastMaintenance: f.lastMaintenance || '2027-02-05',
          taxDueDate: f.taxDueDate || '2027-08-03',
          stnkExpiryDate: f.stnkExpiryDate || '2031-08-03'
        };
      }

      // Migrate legacy Jakarta plate B 9802 KLS to P 8848 U (Mitsubishi Canter Engkel STD)
      if (f.plateNumber === 'B 9802 KLS') {
        return {
          ...f,
          id: 'flt-03',
          plateNumber: 'P 8848 U',
          vehicleType: f.vehicleType || 'Engkel STD',
          initialCode: f.initialCode || 'N3 / NS1',
          brand: f.brand || 'Mitsubishi Canter',
          engineCc: f.engineCc || '3908 CC',
          boxCapacityM3: f.boxCapacityM3 || 9.0,
          boxDimensions: f.boxDimensions || '3.1 x 1.7 x 1.7 m',
          year: f.year || 2008,
          gpsImei: f.gpsImei || '',
          lastMaintenance: f.lastMaintenance || '2027-01-29',
          taxDueDate: f.taxDueDate || '2027-08-03',
          stnkExpiryDate: f.stnkExpiryDate || '2027-08-03'
        };
      }

      // Migrate legacy Jakarta plate B 9301 TXR to P 9677 VB (Mitsubishi Canter Engkel STD)
      if (f.plateNumber === 'B 9301 TXR') {
        return {
          ...f,
          id: 'flt-04',
          plateNumber: 'P 9677 VB',
          vehicleType: f.vehicleType || 'Engkel STD',
          initialCode: f.initialCode || 'N4 / NS2',
          brand: f.brand || 'Mitsubishi Canter',
          engineCc: f.engineCc || '3298 CC',
          boxCapacityM3: f.boxCapacityM3 || 9.0,
          boxDimensions: f.boxDimensions || '3.1 x 1.7 x 1.7 m',
          year: f.year || 2005,
          gpsImei: f.gpsImei || '',
          lastMaintenance: f.lastMaintenance || '2026-11-27',
          taxDueDate: f.taxDueDate || '2027-05-17',
          stnkExpiryDate: f.stnkExpiryDate || '2029-05-27'
        };
      }

      // Migrate legacy Jakarta plate B 9655 PQZ to P 8801 UV (Mitsubishi Canter Engkel STD)
      if (f.plateNumber === 'B 9655 PQZ') {
        return {
          ...f,
          id: 'flt-05',
          plateNumber: 'P 8801 UV',
          vehicleType: f.vehicleType || 'Engkel STD',
          initialCode: f.initialCode || 'N5 / NS3',
          brand: f.brand || 'Mitsubishi Canter',
          engineCc: f.engineCc || '3908 CC',
          boxCapacityM3: f.boxCapacityM3 || 9.0,
          boxDimensions: f.boxDimensions || '3.1 x 1.7 x 1.7 m',
          year: f.year || 2008,
          gpsImei: f.gpsImei || '',
          lastMaintenance: f.lastMaintenance || '2026-08-11',
          taxDueDate: f.taxDueDate || '2026-10-07',
          stnkExpiryDate: f.stnkExpiryDate || '2026-10-07'
        };
      }

      // Migrate legacy Jakarta plate B 9044 MLK to P 8381 VE (Hino Engkel Long)
      if (f.plateNumber === 'B 9044 MLK') {
        return {
          ...f,
          id: 'flt-06',
          plateNumber: 'P 8381 VE',
          vehicleType: f.vehicleType || 'Engkel Long',
          initialCode: f.initialCode || 'N20 / NL1',
          brand: f.brand || 'Hino',
          engineCc: f.engineCc || '4009 CC',
          boxCapacityM3: f.boxCapacityM3 || 14.0,
          boxDimensions: f.boxDimensions || '4.2 x 1.8 x 1.8 m',
          year: f.year || 2013,
          gpsImei: f.gpsImei || '',
          lastMaintenance: f.lastMaintenance || '2026-12-01',
          taxDueDate: f.taxDueDate || '2027-01-16',
          stnkExpiryDate: f.stnkExpiryDate || '2030-01-16'
        };
      }

      let initialCode = f.initialCode;
      if (!initialCode) {
        changed = true;
        const prefix = f.vehicleType.includes('Wingbox') ? 'WB' :
                       f.vehicleType.includes('Fuso') ? 'FS' :
                       f.vehicleType.includes('CDD') ? 'CD' :
                       f.vehicleType.includes('CDE') ? 'CH' :
                       f.vehicleType.includes('Container') ? 'CT' : 'ARM';
        initialCode = `${prefix}-0${idx + 1}`;
      }
      let taxDueDate = f.taxDueDate;
      if (!taxDueDate) {
        changed = true;
        taxDueDate = '2026-11-20';
      }
      let stnkExpiryDate = f.stnkExpiryDate;
      if (!stnkExpiryDate) {
        changed = true;
        stnkExpiryDate = '2028-11-20';
      }
      let boxCapacityM3 = f.boxCapacityM3;
      let boxDimensions = f.boxDimensions;
      if (!boxCapacityM3) {
        changed = true;
        const matchingInit = INITIAL_FLEETS.find(initF => initF.id === f.id || initF.plateNumber === f.plateNumber);
        if (matchingInit && matchingInit.boxCapacityM3) {
          boxCapacityM3 = matchingInit.boxCapacityM3;
          boxDimensions = matchingInit.boxDimensions;
        } else if (f.vehicleType === 'Pick Up Box') {
          boxCapacityM3 = (f.brand || '').toLowerCase().includes('traga') ? 6.2 : 5.5;
          boxDimensions = (f.brand || '').toLowerCase().includes('traga') ? '2.8 x 1.6 x 1.4 m' : '2.4 x 1.6 x 1.4 m';
        } else if (f.vehicleType === 'Engkel Long') {
          boxCapacityM3 = 14.0;
          boxDimensions = '4.2 x 1.8 x 1.8 m';
        } else if (f.vehicleType === 'Engkel STD') {
          boxCapacityM3 = 9.0;
          boxDimensions = '3.1 x 1.7 x 1.7 m';
        } else if (f.vehicleType === 'Double STD') {
          boxCapacityM3 = (f.brand || '').toLowerCase().includes('isuzu') ? 18.0 : 17.5;
          boxDimensions = (f.brand || '').toLowerCase().includes('isuzu') ? '4.4 x 2.0 x 2.0 m' : '4.3 x 2.0 x 2.0 m';
        } else {
          boxCapacityM3 = 10.0;
          boxDimensions = '3.5 x 1.8 x 1.8 m';
        }
      }
      // Sinkronkan kirExpiryDate dengan lastMaintenance agar tanggal jatuh tempo KIR di tabel selalu sesuai dengan tanggal yang diinput/disimpan
      const unifiedKir = f.lastMaintenance !== undefined && f.lastMaintenance !== ''
        ? f.lastMaintenance
        : (f.kirExpiryDate || '');
      if (f.kirExpiryDate !== unifiedKir || f.lastMaintenance !== unifiedKir) {
        changed = true;
      }

      if (changed) {
        updatedFleets = true;
        return {
          ...f,
          initialCode,
          lastMaintenance: unifiedKir,
          kirExpiryDate: unifiedKir,
          taxDueDate,
          stnkExpiryDate,
          boxCapacityM3,
          boxDimensions
        };
      }
      return f;
    });

    // Auto-migrate any cached state from Cikarang DC to Banyuwangi DC & sanitize combined Denpasar 1 & 2
    // Serta memulihkan jadwal baru (>= 2026-11-12) yang sempat terdampak bug status 'delivered' tanpa bukti POD / tanpa bypass checklist
    let updatedSchedules = false;
    this.schedules = this.schedules.map(s => {
      let nextS = s;
      if (s.originCoords && s.originCoords[0] === -6.3262) {
        updatedSchedules = true;
        nextS = {
          ...nextS,
          originName: 'Gudang Pusat Banyuwangi DC',
          originCoords: [-8.1906, 114.3708] as [number, number]
        };
      }
      const rawA = (nextS.areaName || nextS.store?.storeName || '').trim().toUpperCase();
      if (rawA === 'DENPASAR 1 & 2' || rawA === 'DENPASAR 1&2' || rawA === 'DENPASAR') {
        updatedSchedules = true;
        nextS = {
          ...nextS,
          areaName: 'DENPASAR 1',
          store: nextS.store ? { ...nextS.store, storeName: 'DENPASAR 1', address: 'Area Pengiriman Distribusi DENPASAR 1' } : nextS.store
        };
      }
      return nextS;
    });
    if (updatedSchedules) {
      this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules, true);
    }

    // Sinkronisasi status armada (Ready / Kirim / Servis) dengan jadwal aktif hari ini (WIB)
    this.reconcileFleetAndScheduleStatuses(false);

    let updatedFuel = false;
    this.fuelLogs = this.fuelLogs.map(l => {
      if (l.literPerKm === undefined || l.literPer100Km === undefined) {
        updatedFuel = true;
        const dist = l.distanceKm > 0 ? l.distanceKm : Math.max(0, l.endOdometerKm - l.startOdometerKm);
        return {
          ...l,
          distanceKm: dist,
          literPerKm: dist > 0 ? Number((l.liters / dist).toFixed(4)) : 0,
          literPer100Km: dist > 0 ? Number(((l.liters / dist) * 100).toFixed(2)) : 0
        };
      }
      return l;
    });
    if (updatedFuel) {
      this.saveToStorage(STORAGE_KEYS.FUEL_LOGS, this.fuelLogs);
    }

    // Ensure GPS devices in development preview mode only (do not inject mock devices in production)
    if (!import.meta?.env?.PROD) {
      const hasLeadDevice = this.devices.some(d => d.imei === '353701090461274');
      if (!hasLeadDevice || this.devices.length !== INITIAL_TRACKSOLID_DEVICES.length) {
        this.devices = [...INITIAL_TRACKSOLID_DEVICES];
        this.saveToStorage(STORAGE_KEYS.DEVICES, this.devices);
      } else {
        let updatedDevices = false;
        this.devices = this.devices.map(d => {
          if (d.latitude === -6.3262 && d.longitude === 107.1518) {
            updatedDevices = true;
            return {
              ...d,
              latitude: -8.1906,
              longitude: 114.3708,
              address: 'Staging Area Gudang Pusat Banyuwangi DC (Gate 2, Jl. Argopuro No.60)'
            };
          }
          return d;
        });
        if (updatedDevices) {
          this.saveToStorage(STORAGE_KEYS.DEVICES, this.devices);
        }
      }
    }

    // Auto-sync all active schedules directly into Crew Delivery History & Authorization
    this.syncSchedulesToCrewHistory(this.schedules);

    // Register built-in Middleware: Automated write to backend / Google Sheets / Image Storage / Activity Audit
    this.registerDefaultMiddlewares();

    // Auto-sync active user session with driver portal identity
    this.syncCurrentUserToCrew();
  }

  /**
   * RBAC Middleware Guard: Evaluates user status rather than blocking by role label so users with custom Hak Akses can operate across modules.
   */
  public verifyDriverAccess(_actionCategory: string): void {
    const user = this.getCurrentUser();
    if (user && (user.status === 'inactive' || user.status === 'rejected')) {
      throw new Error(`Akses Ditolak: Akun '${user.fullName}' sedang berstatus nonaktif/ditolak.`);
    }
  }

  /**
   * RBAC Helper: Checks if a user has access to specific sub-menu or operation based on Hak Akses
   */
  public hasSubMenuAccess(role?: string, module?: string, subMenu?: string, _accessLevel?: string): boolean {
    const user = this.getCurrentUser();
    if (user && module) {
      return canAccess(user, module, subMenu);
    }
    if (!role) return true;
    return true;
  }

  public hasMenuAccess(role?: string, menuId?: string): boolean {
    const user = this.getCurrentUser();
    if (user && menuId) {
      return canAccess(user, menuId);
    }
    if (!role) return true;
    return true;
  }

  /**
   * Register core middlewares that automatically process writes, Google Sheets sync, images, and telemetry
   */
  private registerDefaultMiddlewares() {
    // 1. Backend Auto-Writer & Queue Middleware
    this.use(async (event: EntityChangeEvent) => {
      await this.handleBackendAutoWrite(event);
    });

    // 2. Image & Document Storage Middleware
    this.use(async (event: EntityChangeEvent) => {
      await this.handleImageStorageAutoSync(event);
    });
  }

  /**
   * Backend auto-writer that asynchronously sends entity updates to /api/sync-entity with debounce and retry handling
   */
  private async handleBackendAutoWrite(event: EntityChangeEvent) {
    // Skip single-item backend sync on bulk/batch operations to prevent network flooding and thread lockup
    if (event.metadata?.isBatch || event.metadata?.source === 'google_sheets_sync') {
      return;
    }

    // Non-blocking background sync
    setTimeout(async () => {
      this.autoSyncStatus = {
        ...this.autoSyncStatus,
        isSyncing: true,
        pendingQueue: this.autoSyncStatus.pendingQueue + 1
      };
      this.notifyAutoSync();

      try {
        const response = await fetch('/api/sync-entity', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(event)
        });

        if (response.ok) {
          this.autoSyncStatus = {
            isSyncing: false,
            lastSyncTime: new Date().toISOString(),
            syncedCount: this.autoSyncStatus.syncedCount + 1,
            pendingQueue: Math.max(0, this.autoSyncStatus.pendingQueue - 1),
            lastError: null,
            lastSyncedEntity: `${event.entityType}:${event.action}`
          };
        } else {
          this.autoSyncStatus = {
            ...this.autoSyncStatus,
            isSyncing: false,
            pendingQueue: Math.max(0, this.autoSyncStatus.pendingQueue - 1)
          };
        }
      } catch {
        this.autoSyncStatus = {
          ...this.autoSyncStatus,
          isSyncing: false,
          pendingQueue: Math.max(0, this.autoSyncStatus.pendingQueue - 1),
          lastError: null,
          lastSyncTime: new Date().toISOString()
        };
      }
      this.notifyAutoSync();
    }, 10);
  }

  /**
   * Google Sheets auto-write handler for schedules and admin spreadsheet weeks
   */
  private async handleGoogleSheetsAutoWrite(event: EntityChangeEvent) {
    // Prevent recursion if the change originated from Google Sheets sync or is a batch import
    if (event.metadata?.source === 'google_sheets_sync' || event.metadata?.isBatch) {
      return;
    }

    // Run in background timeout so main thread is never frozen
    setTimeout(async () => {
      try {
        if (event.entityType === 'schedule') {
          if (event.action === 'create' || event.action === 'update' || event.action === 'status_change') {
            const { googleSheetsApiService } = await import('./googleSheetsApiService');
            googleSheetsApiService.writeScheduleToGoogleSheets(event.data, event.action === 'status_change' ? 'update' : event.action).catch(() => {});
          }
        }
      } catch (err) {
        console.warn('[Google Sheets Auto-Write Middleware Warning]', err);
      }
    }, 20);
  }

  /**
   * Fleet and crew status auto-sync handler
   */
  private async handleFleetCrewStatusAutoSync(event: EntityChangeEvent) {
    if (event.metadata?.isBatch) return;

    setTimeout(async () => {
      try {
        if (event.entityType === 'fleet' && (event.action === 'status_change' || event.action === 'update')) {
          const { googleSheetsApiService } = await import('./googleSheetsApiService');
          googleSheetsApiService.writeFleetStatusToGoogleSheets(
            event.id,
            event.data?.status || 'available',
            event.data
          ).catch(() => {});
        }
      } catch (err) {
        console.warn('[Fleet Status Auto-Sync Warning]', err);
      }
    }, 20);
  }

  /**
   * Image and document storage auto-sync handler
   */
  private async handleImageStorageAutoSync(event: EntityChangeEvent) {
    try {
      if (event.entityType === 'image' || event.entityType === 'manifest') {
        const payload = event.data || {};
        const newImg: ImageRecord = {
          id: payload.id || `img-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
          entityId: payload.entityId || payload.scheduleId || event.id,
          entityType: payload.entityType || (event.entityType === 'manifest' ? 'manifest' : 'schedule'),
          imageUrl: payload.imageUrl || payload.url || '',
          category: payload.category || payload.type || 'proof_of_delivery',
          title: payload.title || `Unggah ${payload.type || 'Gambar'}`,
          notes: payload.notes,
          uploadedBy: payload.uploadedBy || this.currentUser.fullName,
          timestamp: payload.timestamp || new Date().toISOString(),
          syncedToCloud: true
        };

        // Store image record
        const exists = this.imageRecords.some(img => img.id === newImg.id);
        if (!exists) {
          this.imageRecords = [newImg, ...this.imageRecords];
          this.saveToStorage(STORAGE_KEYS.IMAGES, this.imageRecords);
        }

        // Send to backend attachment proxy lazily
        void import('./googleSheetsApiService')
          .then(({ googleSheetsApiService }) =>
            googleSheetsApiService.writeImageAttachmentToBackend(
              newImg.entityId,
              newImg.imageUrl,
              newImg.category,
              newImg.notes
            )
          )
          .catch(() => {});
      }
    } catch (err) {
      console.warn('[Image Auto-Sync Warning]', err);
    }
  }

  /**
   * System audit activity auto-sync handler (dinonaktifkan untuk perubahan teknis web/middleware;
   * Log Aktivitas hanya mencatat akun pengguna yang menambah, merubah, atau mengurangi data)
   */
  private async handleSystemAuditMiddleware(_event: EntityChangeEvent) {
    return;
  }

  /**
   * Register a custom middleware that runs automatically on every entity creation, update, or status change
   */
  public use(middleware: StoreMiddleware): () => void {
    this.middlewares.push(middleware);
    return () => {
      this.middlewares = this.middlewares.filter(m => m !== middleware);
    };
  }

  /**
   * Dispatch an entity change event across all registered middlewares
   */
  public async dispatchMiddleware(event: EntityChangeEvent) {
    for (const mw of this.middlewares) {
      try {
        await mw(event);
      } catch (err) {
        console.warn(`[Store Middleware Error] ${event.entityType}:${event.action}`, err);
      }
    }
  }

  /**
   * Auto-Sync Status Observers
   */
  public getAutoSyncStatus(): AutoSyncStatus {
    return { ...this.autoSyncStatus };
  }

  public onAutoSyncStatusChange(listener: (status: AutoSyncStatus) => void): () => void {
    this.autoSyncListeners.push(listener);
    // Immediately invoke with current state
    try {
      listener({ ...this.autoSyncStatus });
    } catch {}
    return () => {
      this.autoSyncListeners = this.autoSyncListeners.filter(l => l !== listener);
    };
  }

  private notifyAutoSync() {
    this.autoSyncListeners.forEach(l => {
      try {
        l({ ...this.autoSyncStatus });
      } catch {}
    });
  }

  /**
   * Upload and manage entity images with automatic middleware dispatch
   */
  public uploadImage(record: Omit<ImageRecord, 'id' | 'timestamp'>): ImageRecord {
    const newRecord: ImageRecord = {
      ...record,
      id: `img-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      uploadedBy: record.uploadedBy || this.currentUser.fullName,
      syncedToCloud: true
    };

    this.imageRecords = [newRecord, ...this.imageRecords];
    this.saveToStorage(STORAGE_KEYS.IMAGES, this.imageRecords);

    this.dispatchMiddleware({
      entityType: 'image',
      action: 'upload',
      id: newRecord.entityId,
      data: newRecord,
      timestamp: newRecord.timestamp
    });

    this.logActivity('Unggah Gambar', newRecord.entityId, `Unggah ${newRecord.category}: ${newRecord.title || newRecord.id}`);
    this.notify();
    return newRecord;
  }

  public getImagesByEntity(entityId: string): ImageRecord[] {
    return this.imageRecords.filter(img => img.entityId === entityId);
  }

  public getAllImages(): ImageRecord[] {
    return [...this.imageRecords];
  }

  public deleteImage(id: string): void {
    const target = this.imageRecords.find(img => img.id === id);
    this.imageRecords = this.imageRecords.filter(img => img.id !== id);
    this.saveToStorage(STORAGE_KEYS.IMAGES, this.imageRecords);

    if (target) {
      this.dispatchMiddleware({
        entityType: 'image',
        action: 'delete',
        id: target.id,
        data: target,
        timestamp: new Date().toISOString()
      });
    }
    this.notify();
  }

  public attachFleetPhoto(fleetId: string, imageUrl: string, notes?: string) {
    this.uploadImage({
      entityId: fleetId,
      entityType: 'fleet',
      imageUrl,
      category: 'vehicle_condition',
      title: `Foto Kondisi Armada ${fleetId}`,
      notes
    });
  }

  public attachFuelReceiptPhoto(fuelLogId: string, imageUrl: string, notes?: string) {
    this.uploadImage({
      entityId: fuelLogId,
      entityType: 'fuel',
      imageUrl,
      category: 'fuel_receipt',
      title: `Foto Struk/Nota BBM ${fuelLogId}`,
      notes
    });
  }

  private loadFromStorage<T>(key: string, fallback: T): T {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : fallback;
    } catch {
      return fallback;
    }
  }

  private cachedFleets: Fleet[] | null = null;
  private cachedCrews: Crew[] | null = null;
  private cachedStores: RetailStore[] | null = null;
  private cachedSchedules: Schedule[] | null = null;
  private hydratePromise: Promise<boolean> | null = null;
  private lastHydrateAt = 0;
  private hydrateRateLimitedUntil = 0;

  private invalidateReadCaches() {
    this.cachedFleets = null;
    this.cachedCrews = null;
    this.cachedStores = null;
    this.cachedSchedules = null;
  }

  private saveToStorage(key: string, data: any, silent = false) {
    this.invalidateReadCaches();
    // Data operasional bisnis disimpan di Hostinger MySQL (/api/*), bukan localStorage browser
    if (MYSQL_BACKED_STORAGE_KEYS.has(key) || key.startsWith('akk_admin_schedule_cache_')) {
      try {
        if (typeof localStorage !== 'undefined') {
          localStorage.removeItem(key);
        }
      } catch {}
      if (!silent) this.notify();
      return;
    }
    try {
      safeSetItem(key, JSON.stringify(data));
    } catch {
      // Safe fallback - in-memory state remains fully intact
    }
    if (!silent) this.notify();
  }

  private notify() {
    this.invalidateReadCaches();
    queueMicrotask(() => {
      this.listeners.forEach(l => {
        try {
          l();
        } catch (err) {
          console.error('[Store] listener error:', err);
        }
      });
    });
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  public onNotification(listener: (notif: any) => void): () => void {
    this.notificationListeners.push(listener);
    return () => {
      this.notificationListeners = this.notificationListeners.filter(l => l !== listener);
    };
  }

  public emitNotification(type: 'delivery' | 'checker' | 'schedule' | 'sla_warning' | 'geofence', title: string, message: string, urgent?: boolean, data?: any) {
    // Jika pengguna aktif adalah Driver atau Helper dan notifikasi terkait jadwal tertentu,
    // pastikan hanya driver yang ditugaskan pada jadwal tersebut yang menerima notifikasi.
    if (data?.schedule) {
      const role = String(this.currentUser?.role || '').toLowerCase();
      if (role === 'driver' || role === 'crew_helper') {
        const activeCrew = this.getActiveDriverCrew();
        const targetId = (activeCrew?.id || this.currentUser?.id || '').trim().toLowerCase();
        const targetName = (activeCrew?.name || this.currentUser?.fullName || '').trim().toLowerCase();
        const sch = data.schedule as Schedule;
        const crewIds = [sch.crewId, sch.crewHelperId, sch.crewHelper2Id, sch.crew?.id]
          .filter(Boolean)
          .map(x => String(x).trim().toLowerCase());
        const crewNames = [sch.crew?.name, sch.crewHelper?.name, sch.crewHelper2?.name]
          .filter(Boolean)
          .map(x => String(x).trim().toLowerCase());

        const strippedTargetId = targetId.replace(/^(usr-|crw-)/, '');
        const idMatched = Boolean(
          targetId &&
            crewIds.some(cid => cid === targetId || (strippedTargetId.length >= 3 && cid.replace(/^(usr-|crw-)/, '') === strippedTargetId))
        );
        const nameMatched = Boolean(
          targetName &&
            targetName.length >= 3 &&
            crewNames.some(cname => cname === targetName || cname.includes(targetName) || targetName.includes(cname))
        );

        if (!idMatched && !nameMatched) {
          return;
        }
      }
    }
    this.notificationListeners.forEach(l => l({ type, title, message, urgent, data }));
  }

  // Getters
  public getSecurityLogs(): SecurityGateLog[] {
    return [...this.securityLogs];
  }

  public addSecurityLog(logData: Omit<SecurityGateLog, 'id' | 'timestamp'>): SecurityGateLog {
    const newLog: SecurityGateLog = {
      ...logData,
      id: `SEC-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString()
    };
    this.securityLogs = [newLog, ...this.securityLogs].slice(0, 100);
    this.saveToStorage(STORAGE_KEYS.SECURITY_LOGS, this.securityLogs);
    this.notify();
    return newLog;
  }

  public recordGateOut(
    scheduleId: string | undefined,
    plateNumber: string,
    driverName: string,
    destination: string,
    initialCode?: string
  ): SecurityGateLog {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} WIB`;
    const fleetInitial = initialCode || (this.fleets.find(f => f.plateNumber.replace(/\s+/g, '') === (plateNumber || '').replace(/\s+/g, ''))?.initialCode);
    const initialText = fleetInitial ? ` [${fleetInitial}]` : '';

    if (scheduleId) {
      const sch = this.schedules.find(s => s.id === scheduleId);
      if (sch && (sch.status === 'scheduled' || sch.status === 'picked_up')) {
        sch.status = 'in_transit';
        sch.actualDeparture = sch.actualDeparture || now.toISOString();
        sch.updatedAt = now.toISOString();
        this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
        this.persistSchedulesSnapshotToBackend('gate_out_sync');
      }
    }

    const newLog = this.addSecurityLog({
      time: timeStr,
      type: 'Kendaraan Keluar',
      entity: `${plateNumber}${initialText}`,
      initialCode: fleetInitial,
      driver: driverName || 'Driver AKK',
      purpose: `Pengiriman ke ${destination || 'Area Distribusi'} (Gate-Out)`,
      status: 'Gate-Out',
      scheduleId,
      plateNumber,
      securityOfficer: 'Pos Satpam Gerbang DC'
    });

    this.emitNotification(
      'schedule',
      'Kendaraan Keluar (Gate-Out)',
      `Armada ${plateNumber}${initialText} (${driverName}) resmi dicatat Gate-Out oleh Security.`,
      false
    );
    return newLog;
  }

  public recordGateIn(
    scheduleId: string | undefined,
    plateNumber: string,
    driverName: string,
    notes?: string,
    initialCode?: string
  ): SecurityGateLog {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} WIB`;
    const fleetInitial = initialCode || (this.fleets.find(f => f.plateNumber.replace(/\s+/g, '') === (plateNumber || '').replace(/\s+/g, ''))?.initialCode);
    const initialText = fleetInitial ? ` [${fleetInitial}]` : '';

    if (scheduleId) {
      const sch = this.schedules.find(s => s.id === scheduleId);
      if (sch) {
        sch.actualArrival = `${now.toISOString().split('T')[0]} ${timeStr}`;
        sch.status = 'delivered';
        sch.updatedAt = now.toISOString();
        this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
        this.persistSchedulesSnapshotToBackend('gate_in_sync');
      }
    }

    const newLog = this.addSecurityLog({
      time: timeStr,
      type: 'Kendaraan Masuk',
      entity: `${plateNumber}${initialText}`,
      initialCode: fleetInitial,
      driver: driverName || 'Driver AKK',
      purpose: notes || 'Armada Tiba Kembali di Gudang DC Banyuwangi',
      status: 'Tiba di Gudang',
      scheduleId,
      plateNumber,
      notes,
      securityOfficer: 'Pos Satpam Gerbang DC'
    });

    this.emitNotification(
      'delivery',
      'Armada Tiba di Gudang',
      `Armada ${plateNumber}${initialText} (${driverName}) telah tiba di gudang dan berhasil dicatat di sistem database Security.`,
      false
    );
    return newLog;
  }

  private enrichFleetItem(f: Fleet, existingLocal?: Fleet): Fleet {
    const canonical = resolveCanonicalFleetMeta(f) || resolveCanonicalFleetMeta(existingLocal);
    const localRef = existingLocal || this.fleets.find(item => item.id === f.id || item.plateNumber === f.plateNumber);

    const pickStr = (...vals: Array<string | undefined | null>) => {
      for (const v of vals) {
        if (typeof v === 'string' && v.trim() !== '') return v.trim();
      }
      return undefined;
    };

    const pickExplicitStr = (primary: string | undefined | null, localVal?: string, canonVal?: string) => {
      if (primary !== undefined && primary !== null) return String(primary).trim();
      if (localVal !== undefined) return localVal;
      return canonVal;
    };

    const pickNum = (...vals: Array<number | undefined | null>) => {
      for (const v of vals) {
        if (typeof v === 'number' && Number.isFinite(v) && v > 0) return v;
      }
      return undefined;
    };

    const boxCapacityM3 = pickNum(f.boxCapacityM3, localRef?.boxCapacityM3, canonical?.boxCapacityM3) ?? 5.5;
    const boxInnerMultiplierPercent = pickNum(f.boxInnerMultiplierPercent, localRef?.boxInnerMultiplierPercent, canonical?.boxInnerMultiplierPercent) ?? 90;
    const boxInnerCapacityM3 =
      pickNum(f.boxInnerCapacityM3, localRef?.boxInnerCapacityM3, canonical?.boxInnerCapacityM3) ??
      Number((boxCapacityM3 * (boxInnerMultiplierPercent / 100)).toFixed(2));

    const resolvedId = pickStr(f.id, localRef?.id, canonical?.id) || f.id;
    const rawPlate = pickStr(canonical?.plateNumber, f.plateNumber, localRef?.plateNumber) || f.plateNumber;
    const resolvedPlate = String(rawPlate || '').trim().replace(/\s+/g, ' ').toUpperCase();
    const rawInitial = pickExplicitStr(f.initialCode, localRef?.initialCode, canonical?.initialCode);
    const normalizeCompactToken = (val?: string) =>
      String(val || '').toUpperCase().replace(/[\s\-_/()]+/g, '');
    const canonInitParts = canonical?.initialCode
      ? canonical.initialCode.split(/[/]+/).map(p => normalizeCompactToken(p)).filter(Boolean)
      : [];
    const rawInitCompact = normalizeCompactToken(rawInitial);
    // Standardize legacy single-alias or formatting variants (e.g. "DS2", "N23", "N23/DS2") to canonical "N23 / DS2"
    const resolvedInitial =
      canonical?.initialCode &&
      (!rawInitCompact ||
        normalizeCompactToken(canonical.initialCode) === rawInitCompact ||
        canonInitParts.includes(rawInitCompact))
        ? canonical.initialCode
        : rawInitial;
    const explicitBranch = pickStr(f.branchId, localRef?.branchId, canonical?.branchId);
    const resolvedBranchId = branchStore.getFleetBranchId(resolvedId, resolvedPlate, resolvedInitial, explicitBranch);
    branchStore.syncFleetBranchIdSilent(resolvedId, resolvedBranchId);

    return {
      ...(canonical || ({} as Fleet)),
      ...(localRef || ({} as Fleet)),
      ...f,
      id: resolvedId,
      plateNumber: resolvedPlate,
      initialCode: resolvedInitial,
      branchId: resolvedBranchId,
      vehicleType: (pickStr(f.vehicleType, localRef?.vehicleType, canonical?.vehicleType) || 'Engkel STD') as Fleet['vehicleType'],
      brand: pickExplicitStr(f.brand, localRef?.brand, canonical?.brand),
      engineCc: pickExplicitStr(f.engineCc, localRef?.engineCc, canonical?.engineCc),
      year: pickNum(f.year, localRef?.year, canonical?.year) ?? 2020,
      boxCapacityM3,
      boxDimensions: pickExplicitStr(f.boxDimensions, localRef?.boxDimensions, canonical?.boxDimensions),
      boxInnerMultiplierPercent,
      boxInnerCapacityM3,
      lastMaintenance: pickExplicitStr(
        f.lastMaintenance !== undefined ? f.lastMaintenance : f.kirExpiryDate,
        localRef?.lastMaintenance ?? localRef?.kirExpiryDate,
        canonical?.lastMaintenance ?? canonical?.kirExpiryDate
      ),
      taxDueDate: pickExplicitStr(f.taxDueDate, localRef?.taxDueDate, canonical?.taxDueDate),
      stnkExpiryDate: pickExplicitStr(f.stnkExpiryDate, localRef?.stnkExpiryDate, canonical?.stnkExpiryDate),
      kirExpiryDate: pickExplicitStr(
        f.lastMaintenance !== undefined ? f.lastMaintenance : f.kirExpiryDate,
        localRef?.lastMaintenance ?? localRef?.kirExpiryDate,
        canonical?.lastMaintenance ?? canonical?.kirExpiryDate
      ),
      kirDocUrl: pickExplicitStr(f.kirDocUrl, localRef?.kirDocUrl, canonical?.kirDocUrl),
      kirDocFileName: pickExplicitStr(f.kirDocFileName, localRef?.kirDocFileName, canonical?.kirDocFileName),
      kirDocUploadedAt: pickExplicitStr(f.kirDocUploadedAt, localRef?.kirDocUploadedAt, canonical?.kirDocUploadedAt),
      photos3d: f.photos3d !== undefined ? f.photos3d : (localRef?.photos3d ?? canonical?.photos3d),
      driverId: pickExplicitStr(f.driverId, localRef?.driverId, canonical?.driverId),
      tonnageCapacity: pickNum(f.tonnageCapacity, localRef?.tonnageCapacity, canonical?.tonnageCapacity) ?? 3.5,
      odometerKm: typeof f.odometerKm === 'number' && Number.isFinite(f.odometerKm) && f.odometerKm >= 0
        ? f.odometerKm
        : (pickNum(localRef?.odometerKm, canonical?.odometerKm) ?? 0)
    };
  }

  public getFleets(): Fleet[] {
    if (this.cachedFleets !== null && this.cachedFleets.length > 0) {
      return this.cachedFleets;
    }
    const sourceFleets = this.fleets && this.fleets.length > 0 ? this.fleets : INITIAL_FLEETS;
    this.cachedFleets = sortFleetsByCanonicalOrder(sourceFleets.map(f => this.enrichFleetItem(f)));
    return this.cachedFleets;
  }

  public findFleetByCodeOrPlate(codeOrPlate?: string | null, areaName?: string): Fleet | undefined {
    const all = this.getFleets();
    const cleanStr = String(codeOrPlate || '').trim();

    if (cleanStr && cleanStr !== '-') {
      // 1. Canonical resolver (checks exact initialCode, slash tokens like N4 / NS2, NMR / DS4, plateNumber, id)
      const canonical = resolveCanonicalFleetMeta(cleanStr);
      if (canonical) {
        const matchInStore = all.find(
          f =>
            f.id === canonical.id ||
            (f.plateNumber && canonical.plateNumber && f.plateNumber.replace(/\s+/g, '').toUpperCase() === canonical.plateNumber.replace(/\s+/g, '').toUpperCase())
        );
        return matchInStore || this.enrichFleetItem(canonical);
      }

      // 2. Normalized comparison across active store fleets and INITIAL_FLEETS
      const norm = (s: string) => (s || '').toUpperCase().replace(/[\s\-_/()]+/g, '');
      const clean = norm(cleanStr);
      const upperRaw = cleanStr.toUpperCase();

      const searchPool = [...all, ...INITIAL_FLEETS];
      const matched = searchPool.find(f => {
        if (f.id && f.id.toLowerCase() === cleanStr.toLowerCase()) return true;
        if (f.plateNumber && norm(f.plateNumber) === clean) return true;
        if (f.initialCode && norm(f.initialCode) === clean) return true;
        if (f.initialCode && f.initialCode.toUpperCase() === upperRaw) return true;
        if (f.initialCode) {
          const parts = f.initialCode.split(/[/]+/).map(p => norm(p)).filter(Boolean);
          if (parts.includes(clean)) return true;
        }
        if (clean.length >= 4 && f.plateNumber && norm(f.plateNumber).includes(clean)) return true;
        return false;
      });
      if (matched) {
        return this.enrichFleetItem(matched);
      }
    }

    // 3. Fallback by areaName ONLY when codeOrPlate was not provided
    const normArea = (areaName || '').trim().toLowerCase();
    if (!cleanStr && normArea.includes('muncar')) {
      const muncarFleet = all.find(
        f => (f.initialCode || '').includes('NS2') || (f.initialCode || '').includes('N4')
      );
      if (muncarFleet) return muncarFleet;
    }

    return undefined;
  }

  public setFleets(fleets: Fleet[]): void {
    const prevFleets = this.fleets || [];
    const validFleets = sortFleetsByCanonicalOrder(
      fleets
        .filter(f => !(f.plateNumber || '').trim().toUpperCase().endsWith('AKK'))
        .map(f => {
          const prev = prevFleets.find(pf => pf.id === f.id || pf.plateNumber === f.plateNumber);
          return this.enrichFleetItem(f, prev);
        })
    );
    this.fleets = validFleets;
    this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);
    this.notify();
  }

  public isSameCrewPersonName(nameA: string, nameB: string): boolean {
    const cleanA = (nameA || '').trim().toLowerCase();
    const cleanB = (nameB || '').trim().toLowerCase();
    if (!cleanA || !cleanB || cleanA === '-' || cleanB === '-') return false;
    if (cleanA === cleanB) return true;
    const norm = (s: string) =>
      s
        .replace(/\bulloh\b/g, 'ullah')
        .replace(/\bsaifur\b/g, 'saiful')
        .replace(/\bmoh\.?\b/g, 'muhammad')
        .replace(/\bmohammad\b/g, 'muhammad')
        .replace(/\bach\.?\b/g, 'achmad')
        .replace(/[^a-z0-9\s]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
    const nA = norm(cleanA);
    const nB = norm(cleanB);
    if (!nA || !nB) return false;
    if (nA === nB) return true;
    const compactA = nA.replace(/\s+/g, '');
    const compactB = nB.replace(/\s+/g, '');
    if (compactA && compactB && compactA === compactB) return true;
    if (nA.length >= 6 && nB.length >= 6 && (nA.includes(nB) || nB.includes(nA))) return true;
    if (compactA.length >= 6 && compactB.length >= 6 && (compactA.includes(compactB) || compactB.includes(compactA))) return true;
    return false;
  }

  /**
  /**
   * Mengecek apakah akun pengguna merupakan Kru Pengiriman aktif (Driver / Helper)
   * yang memiliki hak akses Full Access ('full_access') ke Portal Driver Mobile (driver_portal / portal_driver).
   * Akun dengan akses Hanya Lihat ('read_only') tidak masuk ke dalam daftar Stand By / Kru,
   * serta dipisahkan secara ketat antara Cabang Sidoarjo ('cab-sidoarjo') dan Cabang Nusantara ('cab-banyuwangi').
   */
  public isActiveDeliveryCrewUser(u: UserProfile | null | undefined, targetBranchId?: string): boolean {
    if (!u) return false;
    const normalizedStatus = String(u.status || '').trim().toLowerCase();
    if (normalizedStatus !== 'approved' || (u as any).isActive === false) return false;
    const cleanEmail = (u.email || '').trim().toLowerCase();
    const cleanName = (u.fullName || '').trim().toLowerCase();
    // Kecualikan akun sistem pusat / super admin / manajemen eksekutif non-lapangan
    if (
      u.role === 'super_admin' ||
      cleanName === 'super admin' ||
      cleanName === 'tamu / belum login' ||
      cleanEmail === 'akkoperasional60@gmail.com' ||
      cleanEmail === 'hendri123@gmail.com' ||
      cleanEmail === 'hendri.st@gmail.com' ||
      cleanEmail === 'bahri@gmail.com' ||
      cleanEmail === 'bayun791@gmail.com' ||
      u.id === 'usr-hendri' ||
      u.id === 'usr-operasional' ||
      u.id === 'usr-bahri'
    ) {
      return false;
    }

    const branchPerms = branchStore.getUserBranchPermissions(
      u.id,
      u.role,
      u.permissions?.modules,
      u.permissions?.branchPermissions
    );

    const hasBranchPortalFullAccess = (bEntry?: UserBranchPermissionEntry): boolean => {
      if (!bEntry || !bEntry.enabled) return false;
      const logMod = bEntry.modules?.logistics;
      if (!logMod || !logMod.enabled) return false;
      const subs = logMod.subMenus || {};
      const dpVal = subs.driver_portal ?? subs.portal_driver;
      // Hanya akses Full Access pada Portal Driver Mobile yang masuk ke daftar Kru / Stand By (Hanya Lihat / read_only tidak masuk)
      return dpVal === 'full_access';
    };

    if (targetBranchId && targetBranchId !== 'ALL') {
      return hasBranchPortalFullAccess(branchPerms[targetBranchId]);
    }

    const anyBranchHasPortalFullAccess = Object.values(branchPerms).some(bEntry =>
      hasBranchPortalFullAccess(bEntry)
    );
    return anyBranchHasPortalFullAccess;
  }

  public getCrewUserPrimaryBranchId(u: UserProfile): string {
    const branchPerms = branchStore.getUserBranchPermissions(
      u.id,
      u.role,
      u.permissions?.modules,
      u.permissions?.branchPermissions
    );
    const sdaEntry = branchPerms['cab-sidoarjo'];
    const bwiEntry = branchPerms['cab-banyuwangi'];

    const hasBranchPortalFullAccess = (entry?: UserBranchPermissionEntry) =>
      Boolean(
        entry?.enabled &&
          entry?.modules?.logistics?.enabled &&
          (entry.modules.logistics.subMenus?.driver_portal === 'full_access' ||
            entry.modules.logistics.subMenus?.portal_driver === 'full_access')
      );

    const sdaHasDp = hasBranchPortalFullAccess(sdaEntry);
    const bwiHasDp = hasBranchPortalFullAccess(bwiEntry);

    // Jika Cabang Sidoarjo memiliki akses penuh Portal Driver Mobile, prioritaskan sebagai kru Sidoarjo
    // (karena Cabang Sidoarjo hanya aktif jika diaktifkan secara eksplisit untuk kru Sidoarjo, sehingga tidak tercampur ke Nusantara)
    if (sdaHasDp) return 'cab-sidoarjo';
    if (bwiHasDp) return 'cab-banyuwangi';

    const sdaEnabled = Boolean(sdaEntry?.enabled);
    const bwiEnabled = Boolean(bwiEntry?.enabled);
    if (sdaEnabled && !bwiEnabled) return 'cab-sidoarjo';
    return 'cab-banyuwangi';
  }

  /**
   * Menghitung daftar kru yang tersinkronisasi dari Manajemen User (semua akun aktif yang memiliki akses Portal Driver Mobile atau Jadwal & Penugasan Armada)
   * tanpa memicu efek samping penyimpanan atau notifikasi listener.
   */
  private computeSyncedCrews(): Crew[] {
    const syncedCrews: Crew[] = [];
    const seenNames = new Set<string>();

    for (const u of this.users) {
      if (!this.isActiveDeliveryCrewUser(u)) continue;

      const cleanName = (u.fullName || '').trim();
      if (!cleanName) continue;
      const lowerName = cleanName.toLowerCase();
      const normalizeIdentityName = (value: string) => value
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '');
      const exactNameKey = normalizeIdentityName(cleanName);
      if (lowerName === 'super admin' || lowerName === 'tamu / belum login' || seenNames.has(lowerName)) continue;
      // User accounts are separate identities. Do not merge accounts just because one
      // person's short name is contained in another person's full name (e.g. Nur Hadi
      // vs Muhammad Nurhadi Muqorrobin).
      if (syncedCrews.some(sc => normalizeIdentityName(sc.name) === exactNameKey)) continue;

      const existingAccountCrew = (this.crews || []).find(c => c && c.id === `crw-${u.id}`);
      const existingExactNameCrew = (this.crews || []).find(
        c => c && c.name && normalizeIdentityName(c.name) === exactNameKey
      );
      const existingInStore = existingAccountCrew || existingExactNameCrew;
      const existingInInitial = INITIAL_CREWS.find(
        c => normalizeIdentityName(c.name) === exactNameKey
      );
      const refCrew = existingAccountCrew || existingExactNameCrew || existingInInitial;

      const crewId = refCrew?.id || `crw-${u.id}`;
      const crewRole: Crew['role'] = u.role !== 'crew_helper'
        ? (refCrew && !refCrew.role.includes('Helper') ? refCrew.role : 'Driver Utama')
        : 'Kernet / Helper';

      const crewStatus: Crew['status'] = existingInStore?.status === 'on-duty' ? 'on-duty' : 'available';

      const primaryBranchId = this.getCrewUserPrimaryBranchId(u);
      branchStore.syncCrewBranchIdSilent(crewId, primaryBranchId, cleanName);
      branchStore.syncCrewBranchIdSilent(u.id, primaryBranchId, cleanName);

      const crewItem: Crew = {
        id: crewId,
        name: cleanName,
        phone: u.phone && u.phone !== '-' ? u.phone : (refCrew?.phone || ''),
        role: crewRole,
        licenseNumber: refCrew?.licenseNumber || '',
        licenseType: u.role === 'driver' ? (refCrew?.licenseType || 'SIM B1 Umum') : 'SIM A',
        status: crewStatus,
        currentFleetId: existingInStore?.currentFleetId || refCrew?.currentFleetId || undefined,
        tripsCompleted: refCrew?.tripsCompleted ?? 0,
        rating: refCrew?.rating ?? 0
      };

      seenNames.add(lowerName);
      syncedCrews.push(crewItem);
    }

    // Jika daftar akun user belum dimuat (users kosong), pertahankan sementara entri non-off dari this.crews.
    // Begitu akun user sudah tersedia (users.length > 0), JANGAN pernah meloloskan nama kru yang belum terdaftar sebagai user akun!
    if ((this.users || []).length === 0) {
      for (const c of (this.crews || [])) {
        if (!c || !c.name) continue;
        const cleanName = c.name.trim();
        if (!cleanName) continue;
        const lowerName = cleanName.toLowerCase();
        if (lowerName === 'super admin' || lowerName === 'tamu / belum login' || seenNames.has(lowerName)) continue;
        if (c.status === 'off') continue;
        if (syncedCrews.some(sc => this.isSameCrewPersonName(sc.name, cleanName))) continue;

        seenNames.add(lowerName);
        syncedCrews.push(c);
      }
    }

    return syncedCrews;
  }

  /**
   * Sinkronisasi 2 arah antara Manajemen User (akun dengan akses Portal Driver Mobile) dan daftar Kru Jadwal Penugasan
   */
  public syncUsersWithCrews(): Crew[] {
    const syncedCrews = this.computeSyncedCrews();
    this.crews = syncedCrews;
    this.cachedCrews = syncedCrews;
    this.cachedSchedules = null;
    try {
      if (typeof localStorage !== 'undefined') localStorage.removeItem(STORAGE_KEYS.CREWS);
    } catch {}
    return syncedCrews;
  }

  public getCrews(): Crew[] {
    if (this.cachedCrews !== null) {
      return this.cachedCrews;
    }
    this.cachedCrews = this.computeSyncedCrews();
    return this.cachedCrews;
  }

  public getDriverCrews(branchId?: string): Crew[] {
    const all = this.computeSyncedCrews().filter(c => c.status !== 'off');
    const hasRegisteredUsers = (this.users || []).length > 0;
    const drivers = all.filter(c => {
      const linkedUser = this.users.find(
        u => `crw-${u.id}` === c.id || this.isSameCrewPersonName(u.fullName, c.name)
      );
      if (linkedUser) {
        return this.isActiveDeliveryCrewUser(linkedUser, branchId) && linkedUser.role !== 'crew_helper';
      }
      if (hasRegisteredUsers) return false;
      if (branchId && branchId !== 'ALL' && branchStore.getCrewBranchId(c.id, c.name) !== branchId) {
        return false;
      }
      return !(c.role || '').toLowerCase().includes('helper') && !(c.role || '').toLowerCase().includes('kernet');
    });
    return drivers;
  }

  public getHelperCrews(branchId?: string): Crew[] {
    const all = this.computeSyncedCrews().filter(c => c.status !== 'off');
    const hasRegisteredUsers = (this.users || []).length > 0;
    const helpers = all.filter(c => {
      const linkedUser = this.users.find(
        u => `crw-${u.id}` === c.id || this.isSameCrewPersonName(u.fullName, c.name)
      );
      if (linkedUser) {
        return this.isActiveDeliveryCrewUser(linkedUser, branchId);
      }
      if (hasRegisteredUsers) return false;
      if (branchId && branchId !== 'ALL' && branchStore.getCrewBranchId(c.id, c.name) !== branchId) {
        return false;
      }
      return true;
    });
    return helpers;
  }

  public setCrews(crews: Crew[]): void {
    const uniqueMap = new Map<string, Crew>();
    crews.forEach(c => {
      if (c && c.id && c.name.trim().toLowerCase() !== 'super admin') {
        uniqueMap.set(c.id, c);
      }
    });
    this.crews = Array.from(uniqueMap.values());
    this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);
    this.notify();
  }

  public getScheduleChangeLogs(): ScheduleChangeLogEntry[] {
    return [...this.scheduleChangeLogs];
  }

  public addScheduleChangeLog(
    entry: Omit<ScheduleChangeLogEntry, 'id' | 'timestamp' | 'userName' | 'userRole'> & {
      userName?: string;
      userRole?: string;
    }
  ): ScheduleChangeLogEntry {
    const current = this.getCurrentUser();
    const roleLabelMap: Record<string, string> = {
      super_admin: 'Super Admin',
      spv_logistik: 'SPV Logistik',
      koordinator_driver: 'Koordinator Driver',
      driver: 'Driver',
      crew_helper: 'Helper',
      sales_admin: 'Adm. Penjualan',
      spv_sales_admin: 'SPV Adm Penjualan',
      purchasing_admin: 'Adm. Pembelian',
      spv_purchasing_admin: 'SPV Adm Pembelian',
      warehouse_admin: 'Gudang',
      koordinator_gudang: 'Koordinator Gudang',
      marketing_online: 'Marketing Online',
      marketing_offline: 'Marketing Offline',
      spv_marketing_offline: 'SPV Marketing Offline',
      hr_admin: 'Human Resource Development',
      finance_tax_admin: 'Adm Finance & Tax',
      operasional: 'SPV Operasional',
      security: 'Security'
    };
    const newEntry: ScheduleChangeLogEntry = {
      id: 'scl-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toISOString(),
      fileName: entry.fileName,
      userName: entry.userName || current?.fullName || 'Super Admin',
      userRole: entry.userRole || roleLabelMap[current?.role || 'super_admin'] || current?.role || 'Admin',
      actionType: entry.actionType,
      summary: entry.summary,
      changes: entry.changes,
      status: entry.status
    };
    this.scheduleChangeLogs = [newEntry, ...this.scheduleChangeLogs].slice(0, 50);
    this.saveToStorage(STORAGE_KEYS.SCHEDULE_CHANGE_LOGS, this.scheduleChangeLogs);
    this.notify();
    return newEntry;
  }

  public getStores(): RetailStore[] {
    if (this.cachedStores !== null && this.cachedStores.length > 0) {
      return this.cachedStores;
    }
    const sourceStores = this.stores && this.stores.length > 0 ? this.stores : INITIAL_STORES;
    this.cachedStores = sourceStores.filter(s => !isAreaRouteItem(s));
    return this.cachedStores;
  }

  public getSchedules(): Schedule[] {
    if (this.cachedSchedules !== null) {
      return this.cachedSchedules;
    }
    const crewById = new Map<string, Crew>();
    const crewByName = new Map<string, Crew>();
    for (const c of this.crews) {
      if (c.id) crewById.set(c.id, c);
      if (c.name) crewByName.set(c.name.trim().toLowerCase(), c);
    }

    const normPlate = (p?: string) => (p || '').replace(/\s+/g, '').toUpperCase();
    const fleetById = new Map<string, Fleet>();
    const fleetByPlate = new Map<string, Fleet>();
    for (const f of this.fleets) {
      if (f.id) fleetById.set(f.id, f);
      if (f.plateNumber) fleetByPlate.set(normPlate(f.plateNumber), f);
    }

    const findMatchingCrew = (id?: string, refCrew?: Crew): Crew | undefined => {
      if (id) {
        const byId = crewById.get(id);
        if (byId) return byId;
      }
      if (refCrew?.name) {
        const byName = crewByName.get(refCrew.name.trim().toLowerCase());
        if (byName) return byName;
      }
      return refCrew;
    };

    this.cachedSchedules = this.schedules.map(sch => {
      const areaName = resolveScheduleAreaName(sch);
      const upperArea = areaName.toUpperCase();
      const isBali = sch.isInterIsland || upperArea.includes('BALI') || upperArea.includes('DENPASAR') || upperArea.includes('SINGARAJA') || upperArea.includes('NEGARA');

      const areaStore: RetailStore = {
        id: sch.storeId && !sch.storeId.startsWith('str-fix-') ? sch.storeId : `area-${areaName.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
        storeCode: `AREA-${areaName.substring(0, 4).toUpperCase().replace(/[^A-Z0-9]/g, '')}`,
        storeName: areaName, // ALWAYS NAMA AREA KIRIM
        island: isBali ? 'Bali & Nusa Tenggara' : 'Jawa',
        province: isBali ? 'Bali' : 'Jawa Timur',
        city: isBali ? 'Denpasar' : (upperArea.includes('JEMBER') ? 'Jember' : (upperArea.includes('SITUBONDO') ? 'Situbondo' : (upperArea.includes('BONDOWOSO') ? 'Bondowoso' : 'Banyuwangi'))),
        address: `Area Pengiriman Distribusi ${areaName}`,
        latitude: isBali ? -8.6705 : -8.219,
        longitude: isBali ? 115.2126 : 114.369,
        contactPerson: 'PIC Distribusi Area',
        phone: '-',
        deliveryWindow: '08:00 - 17:00',
        storeCategory: 'Distribution Hub'
      };

      let matchedFleet: Fleet | undefined = undefined;
      const explicitArmadaCode =
        (sch.armada && sch.armada !== '-' ? String(sch.armada).trim() : '') ||
        (sch.fleet?.initialCode ? String(sch.fleet.initialCode).trim() : '') ||
        (sch.fleet?.plateNumber ? String(sch.fleet.plateNumber).trim() : '');

      // Extract armada token from trackingNumber if formatted as PO-AKK-YYYYMMDD-<ARMADA>-<SUFFIX>
      let trackingArmadaToken = '';
      if (sch.trackingNumber) {
        const trkMatch = sch.trackingNumber.match(/^PO-AKK-\d{8}-(.+)-[A-Z0-9]+$/i);
        if (trkMatch && trkMatch[1] && trkMatch[1].toUpperCase() !== 'FLT') {
          trackingArmadaToken = trkMatch[1].trim();
        }
      }

      if (explicitArmadaCode) {
        matchedFleet = this.findFleetByCodeOrPlate(explicitArmadaCode);
      }
      if (!matchedFleet && sch.fleetId && sch.fleetId !== 'flt-01') {
        matchedFleet = fleetById.get(sch.fleetId) || this.findFleetByCodeOrPlate(sch.fleetId);
      }
      if (!matchedFleet && trackingArmadaToken) {
        matchedFleet = this.findFleetByCodeOrPlate(trackingArmadaToken);
      }
      if (!matchedFleet && sch.fleetId) {
        matchedFleet = fleetById.get(sch.fleetId) || this.findFleetByCodeOrPlate(sch.fleetId);
      }
      if (!matchedFleet && sch.fleet?.plateNumber) {
        matchedFleet = fleetByPlate.get(normPlate(sch.fleet.plateNumber));
      }
      if (!matchedFleet && sch.fleet) {
        matchedFleet = sch.fleet;
      }

      const enrichedFleet = matchedFleet ? this.enrichFleetItem(matchedFleet) : undefined;
      const resolvedArmada =
        enrichedFleet?.initialCode ||
        explicitArmadaCode ||
        trackingArmadaToken ||
        enrichedFleet?.plateNumber ||
        sch.armada;

      return {
        ...sch,
        areaName,
        store: areaStore,
        fleetId: enrichedFleet?.id || sch.fleetId,
        fleet: enrichedFleet,
        armada: resolvedArmada,
        crew: findMatchingCrew(sch.crewId, sch.crew),
        crewHelper: (sch.crewHelperId || sch.crewHelper) ? findMatchingCrew(sch.crewHelperId, sch.crewHelper) : undefined,
        crewHelper2: (sch.crewHelper2Id || sch.crewHelper2) ? findMatchingCrew(sch.crewHelper2Id, sch.crewHelper2) : undefined
      };
    });
    return this.cachedSchedules;
  }

  public getDevices(): TracksolidDevice[] {
    return [...this.devices];
  }

  public updateDevices(updatedDevices: TracksolidDevice[]) {
    this.devices = [...updatedDevices];
    this.saveToStorage(STORAGE_KEYS.DEVICES, this.devices);
    this.notify();
  }

  public resetDevices() {
    this.devices = [...INITIAL_TRACKSOLID_DEVICES];
    this.saveToStorage(STORAGE_KEYS.DEVICES, this.devices);
    this.notify();
  }

  public getCurrentUser(): UserProfile {
    return this.currentUser || { ...GUEST_USER_PROFILE };
  }

  public isAuthenticated(): boolean {
    if (!this.currentUser || this.currentUser.id === 'guest' || this.currentUser.status !== 'approved') {
      return false;
    }
    try {
      const sessionUserId =
        (typeof sessionStorage !== 'undefined' ? sessionStorage.getItem(STORAGE_KEYS.AUTH_SESSION) : null) ||
        (typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.AUTH_SESSION) : null);
      if (sessionUserId !== this.currentUser.id) {
        if (typeof sessionStorage !== 'undefined') sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, this.currentUser.id);
        if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, this.currentUser.id);
      }
    } catch {}
    return true;
  }

  /**
   * Returns the official name of the Koordinator Logistik / SPV Logistik.
   * Dynamically integrates with user management roles and names:
   * 1. If currently logged-in user is an active spv_logistik, returns their name.
   * 2. Finds approved users with role 'spv_logistik'.
   *    If Muhammad Syaiful Bahri is an approved spv_logistik, uses his name (including any edited name).
   *    Otherwise, uses the first approved user holding the 'spv_logistik' role.
   * 3. Fallback to any user matching Syaiful Bahri or official default.
   */
  public resolveLogisticsBranchId(
    branchIdOrContext?:
      | string
      | {
          branchId?: string;
          scheduleId?: string;
          areaName?: string;
          fleetId?: string;
          plateNumber?: string;
          initialCode?: string;
          driverId?: string;
          driverName?: string;
        }
      | null
  ): string {
    if (typeof branchIdOrContext === 'string' && branchIdOrContext.trim()) {
      const clean = branchIdOrContext.trim();
      if (clean === 'cab-sidoarjo' || clean.toLowerCase().includes('sidoarjo')) return 'cab-sidoarjo';
      if (clean === 'cab-banyuwangi' || clean.toLowerCase().includes('nusantara') || clean.toLowerCase().includes('banyuwangi')) {
        return 'cab-banyuwangi';
      }
      return branchStore.getScheduleBranchId(undefined, clean);
    }

    if (branchIdOrContext && typeof branchIdOrContext === 'object') {
      if (branchIdOrContext.branchId && branchIdOrContext.branchId !== 'ALL') {
        return branchIdOrContext.branchId;
      }
      if (branchIdOrContext.plateNumber || branchIdOrContext.initialCode || branchIdOrContext.fleetId) {
        const matchedFleet =
          this.findFleetByCodeOrPlate(branchIdOrContext.initialCode) ||
          this.findFleetByCodeOrPlate(branchIdOrContext.plateNumber) ||
          this.findFleetByCodeOrPlate(branchIdOrContext.fleetId);
        const fBranch = branchStore.getFleetBranchId(
          matchedFleet?.id || branchIdOrContext.fleetId || '',
          matchedFleet?.plateNumber || branchIdOrContext.plateNumber,
          matchedFleet?.initialCode || branchIdOrContext.initialCode,
          matchedFleet?.branchId
        );
        if (fBranch === 'cab-sidoarjo' || fBranch === 'cab-banyuwangi') {
          return fBranch;
        }
      }
      if (branchIdOrContext.areaName || branchIdOrContext.scheduleId) {
        const sBranch = branchStore.getScheduleBranchId(
          branchIdOrContext.scheduleId,
          branchIdOrContext.areaName,
          branchIdOrContext.fleetId
        );
        if (sBranch === 'cab-sidoarjo' || sBranch === 'cab-banyuwangi') {
          return sBranch;
        }
      }
      if (branchIdOrContext.driverId || branchIdOrContext.driverName) {
        const cBranch = branchStore.getCrewBranchId(branchIdOrContext.driverId || '', branchIdOrContext.driverName);
        if (cBranch === 'cab-sidoarjo' || cBranch === 'cab-banyuwangi') {
          return cBranch;
        }
      }
    }

    return branchStore.getSelectedOriginBranchId() || 'cab-banyuwangi';
  }

  public getLogisticsCoordinatorUser(
    branchIdOrContext?:
      | string
      | {
          branchId?: string;
          scheduleId?: string;
          areaName?: string;
          fleetId?: string;
          plateNumber?: string;
          initialCode?: string;
          driverId?: string;
          driverName?: string;
        }
      | null
  ): { fullName: string; role: string } {
    const targetBranchId = this.resolveLogisticsBranchId(branchIdOrContext);

    const doesUserMatchBranch = (u: UserProfile, bId: string): boolean => {
      const bMap = branchStore.getUserBranchPermissions(
        u.id,
        u.role,
        u.permissions?.modules,
        u.permissions?.branchPermissions
      );
      if (bMap && Object.keys(bMap).length > 0) {
        const sdaEnabled = Boolean(bMap['cab-sidoarjo']?.enabled);
        const bwiEnabled = Boolean(bMap['cab-banyuwangi']?.enabled);
        if (sdaEnabled && !bwiEnabled) return bId === 'cab-sidoarjo';
        if (bwiEnabled && !sdaEnabled) return bId === 'cab-banyuwangi';
      }
      const lowerName = (u.fullName || '').trim().toLowerCase();
      const lowerNotes = (u.notes || '').trim().toLowerCase();
      if (lowerName.includes('allan') || lowerNotes.includes('sidoarjo')) {
        return bId === 'cab-sidoarjo';
      }
      if (
        lowerName.includes('bahri') ||
        lowerName.includes('syaiful') ||
        lowerNotes.includes('nusantara') ||
        lowerNotes.includes('banyuwangi')
      ) {
        return bId === 'cab-banyuwangi';
      }
      const crewB = branchStore.getCrewBranchId(u.id, u.fullName);
      if (crewB === 'cab-sidoarjo' || crewB === 'cab-banyuwangi') {
        return crewB === bId;
      }
      return true;
    };

    if (
      this.currentUser &&
      this.currentUser.role === 'spv_logistik' &&
      this.currentUser.status === 'approved' &&
      doesUserMatchBranch(this.currentUser, targetBranchId)
    ) {
      return { fullName: this.currentUser.fullName, role: 'spv_logistik' };
    }

    const approvedSpvLogistiks = this.users.filter(u => u.role === 'spv_logistik' && u.status === 'approved');
    const branchMatchedSpv = approvedSpvLogistiks.find(u => doesUserMatchBranch(u, targetBranchId));
    if (branchMatchedSpv) {
      return { fullName: branchMatchedSpv.fullName, role: 'spv_logistik' };
    }

    if (targetBranchId === 'cab-banyuwangi') {
      const bahriUser = this.users.find(
        u =>
          (u.fullName || '').toLowerCase().includes('bahri') ||
          (u.fullName || '').toLowerCase().includes('syaiful')
      );
      if (bahriUser) {
        return { fullName: bahriUser.fullName, role: 'spv_logistik' };
      }
      return { fullName: 'Muhammad Syaiful Bahri', role: 'spv_logistik' };
    }

    if (targetBranchId === 'cab-sidoarjo') {
      const allanUser = this.users.find(u => (u.fullName || '').toLowerCase().includes('allan'));
      if (allanUser) {
        return { fullName: allanUser.fullName, role: 'spv_logistik' };
      }
    }

    if (approvedSpvLogistiks.length > 0) {
      return { fullName: approvedSpvLogistiks[0].fullName, role: 'spv_logistik' };
    }

    const approvedLogisticsUsers = this.users.filter(
      u =>
        u.status === 'approved' &&
        u.role !== 'super_admin' &&
        u.role !== 'driver' &&
        u.role !== 'crew_helper' &&
        u.permissions?.modules?.logistics?.enabled &&
        (u.permissions.modules.logistics.subMenus?.schedules === 'full_access' ||
          u.permissions.modules.logistics.subMenus?.portal_validation === 'full_access')
    );
    const branchMatchedLogisticsUser = approvedLogisticsUsers.find(u => doesUserMatchBranch(u, targetBranchId));
    if (branchMatchedLogisticsUser) {
      return { fullName: branchMatchedLogisticsUser.fullName, role: branchMatchedLogisticsUser.role };
    }
    if (approvedLogisticsUsers.length > 0) {
      return { fullName: approvedLogisticsUsers[0].fullName, role: approvedLogisticsUsers[0].role };
    }

    const anySpv = this.users.find(u => u.role === 'spv_logistik' && doesUserMatchBranch(u, targetBranchId)) ||
      this.users.find(u => u.role === 'spv_logistik');
    if (anySpv) {
      return { fullName: anySpv.fullName, role: 'spv_logistik' };
    }
    return {
      fullName: targetBranchId === 'cab-sidoarjo' ? 'Allan E.' : 'Muhammad Syaiful Bahri',
      role: 'spv_logistik'
    };
  }

  public getLogisticsCoordinator(
    branchIdOrContext?:
      | string
      | {
          branchId?: string;
          scheduleId?: string;
          areaName?: string;
          fleetId?: string;
          plateNumber?: string;
          initialCode?: string;
          driverId?: string;
          driverName?: string;
        }
      | null
  ): string {
    return this.getLogisticsCoordinatorUser(branchIdOrContext).fullName;
  }

  /**
   * Returns the official name and title for the Super Admin / Manager Operasional.
   * Dynamically integrates with user management roles and names:
   * 1. If currently logged-in user is an approved super_admin, returns their name.
   * 2. Finds approved users with role 'super_admin' and returns their name.
   * 3. Fallback to official default.
   */
  public getSuperAdminOrManager(): { name: string; title: string } {
    if (this.currentUser && this.currentUser.role === 'super_admin' && this.currentUser.status === 'approved') {
      return {
        name: this.currentUser.fullName,
        title: 'Super Admin / Manager'
      };
    }
    const admin = this.users.find(u => u.role === 'super_admin' && u.status === 'approved');
    if (admin) {
      return {
        name: admin.fullName,
        title: 'Super Admin / Manager'
      };
    }
    return {
      name: 'Super Admin',
      title: 'Super Admin / Manager'
    };
  }

  public getSupabaseConfig(): SupabaseConfig {
    return this.supabaseConfig;
  }

  public getCrewDeliveryHistory(crewId?: string): CrewDeliveryHistory[] {
    if (crewId) {
      return this.crewHistory.filter(h => h.crewId === crewId);
    }
    return [...this.crewHistory];
  }

  public getCrewAreaStats(crewId: string): AreaDeliveryStat[] {
    const history = this.getCrewDeliveryHistory(crewId);
    const areaMap = new Map<string, { count: number; island: string; lastDate: string }>();

    history.forEach(item => {
      const existing = areaMap.get(item.area);
      if (existing) {
        existing.count += 1;
        if (new Date(item.completionDate) > new Date(existing.lastDate)) {
          existing.lastDate = item.completionDate;
        }
      } else {
        areaMap.set(item.area, {
          count: 1,
          island: item.island,
          lastDate: item.completionDate
        });
      }
    });

    const stats: AreaDeliveryStat[] = [];
    areaMap.forEach((val, key) => {
      stats.push({
        area: key,
        island: val.island,
        totalTrips: val.count,
        lastTripDate: val.lastDate,
        requiresApproval: val.count >= this.areaThreshold
      });
    });

    return stats.sort((a, b) => b.totalTrips - a.totalTrips);
  }

  public checkCrewAreaThreshold(crewId: string, areaName: string): {
    tripCount: number;
    threshold: number;
    requiresApproval: boolean;
    isApproved: boolean;
    recentTrips: CrewDeliveryHistory[];
  } {
    const allCrewTrips = this.getCrewDeliveryHistory(crewId);
    // Match area name or city or island
    const matchedTrips = allCrewTrips.filter(t => 
      t.area.toLowerCase().includes(areaName.toLowerCase()) ||
      areaName.toLowerCase().includes(t.area.toLowerCase()) ||
      t.city.toLowerCase().includes(areaName.toLowerCase()) ||
      areaName.toLowerCase().includes(t.city.toLowerCase())
    );

    const tripCount = matchedTrips.length;
    const requiresApproval = tripCount >= this.areaThreshold;

    // Check if there is an approved request for this crew and area
    const hasApproval = this.areaApprovals.some(
      a => a.crewId === crewId && 
           (a.targetArea.toLowerCase().includes(areaName.toLowerCase()) || areaName.toLowerCase().includes(a.targetArea.toLowerCase())) &&
           a.status === 'approved'
    );

    return {
      tripCount,
      threshold: this.areaThreshold,
      requiresApproval,
      isApproved: hasApproval,
      recentTrips: matchedTrips
    };
  }

  public getAreaApprovalRequests(): AreaApprovalRequest[] {
    return [...this.areaApprovals];
  }

  private persistCrewRotationStateToMysql() {
    if (typeof window === 'undefined') return;
    const payload = {
      areaThreshold: this.areaThreshold,
      areaApprovals: this.areaApprovals,
      crewHistory: this.crewHistory.slice(0, 500)
    };
    fetch('/api/logistics/crew-rotation-state', {
      method: 'PUT',
      credentials: 'same-origin',
      headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload)
    }).catch(err => console.warn('[Hostinger Crew Rotation] Gagal simpan ke MySQL:', err));
  }

  public createAreaApprovalRequest(req: Omit<AreaApprovalRequest, 'id' | 'requestedAt'>): AreaApprovalRequest {
    const newReq: AreaApprovalRequest = {
      ...req,
      id: 'appr-' + Math.random().toString(36).substring(2, 9),
      requestedAt: new Date().toISOString()
    };
    this.areaApprovals = [newReq, ...this.areaApprovals];
    this.persistCrewRotationStateToMysql();
    this.notify();
    return newReq;
  }

  public decideAreaApproval(requestId: string, status: 'approved' | 'rejected', notes?: string, decidedBy?: string) {
    this.areaApprovals = this.areaApprovals.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          status,
          notes: notes !== undefined ? notes : req.notes,
          decidedAt: new Date().toISOString(),
          decidedBy: decidedBy || this.currentUser.fullName
        };
      }
      return req;
    });
    this.persistCrewRotationStateToMysql();
    this.notify();
  }

  public getAreaDeliveryThreshold(): number {
    return this.areaThreshold;
  }

  public setAreaDeliveryThreshold(val: number) {
    this.areaThreshold = val;
    this.persistCrewRotationStateToMysql();
    this.notify();
  }

  /**
   * Menyelaraskan seluruh data jadwal operasional aktif ke submenu 'Histori & Otorisasi Kru'
   */
  public syncSchedulesToCrewHistory(schedules?: Schedule[]): number {
    const targetSchedules = schedules || this.schedules || [];
    let addedCount = 0;

    // Purge history items for schedules that no longer exist (and purge legacy mock rows without scheduleId when real schedules exist)
    const activeScheduleIds = new Set(targetSchedules.map(s => s.id));
    this.crewHistory = this.crewHistory.filter(h => Boolean(h.scheduleId && activeScheduleIds.has(h.scheduleId)));

    targetSchedules.forEach((sch) => {
      // Flexible crew lookup by ID or name
      const driverName = (sch.crew?.name || (sch as any).driver || '').trim();
      const hasAssignedDriver = Boolean(
        (sch.crewId && sch.crewId.trim() && sch.crewId !== 'unassigned') ||
        (driverName && driverName !== '-' && driverName.toLowerCase() !== 'belum ditentukan')
      );
      const crew = hasAssignedDriver
        ? this.crews.find(
            c =>
              c.id === sch.crewId ||
              c.id === sch.crew?.id ||
              (driverName && c.name.trim().toLowerCase() === driverName.toLowerCase())
          ) || {
            id: sch.crewId || `c-custom-${driverName.toLowerCase().replace(/[^a-z0-9]+/g, '-') || Math.random().toString(36).substring(2, 6)}`,
            name: driverName || sch.crewId || 'Driver',
            phone: '081234567890',
            role: 'Driver' as const,
            licenseNumber: 'SIM B1',
            licenseType: 'SIM B1',
            status: 'available' as const,
            tripsCompleted: 10,
            rating: 4.8
          }
        : null;

      const helperName = (sch.crewHelper?.name || (sch as any).helper || '').trim();
      const matchedHelperInCrews = this.crews.find(
        c =>
          (sch.crewHelperId && c.id === sch.crewHelperId) ||
          (sch.crewHelper?.id && c.id === sch.crewHelper.id) ||
          (helperName && helperName !== '-' && c.name.trim().toLowerCase() === helperName.toLowerCase())
      );
      const helper = matchedHelperInCrews
        ? matchedHelperInCrews
        : sch.crewHelper && sch.crewHelper.name && sch.crewHelper.name !== '-'
        ? {
            id: sch.crewHelper.id || `hlp-${sch.crewHelper.name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-')}`,
            name: sch.crewHelper.name.trim()
          }
        : helperName && helperName !== '-'
        ? {
            id: `hlp-${helperName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`,
            name: helperName
          }
        : null;

      const fleet =
        this.fleets.find(f => f.id === sch.fleetId || f.plateNumber === sch.fleet?.plateNumber) ||
        this.findFleetByCodeOrPlate(sch.armada || sch.fleet?.initialCode || sch.fleet?.plateNumber || sch.fleetId);
      const store = this.stores.find(s => s.id === sch.storeId);

      const rawAreaName = (resolveScheduleAreaName(sch) || store?.storeName || sch.cargoDescription || 'Area Kirim').trim();
      const areaName = rawAreaName;
      const island =
        areaName.toUpperCase().includes('DENPASAR') ||
        areaName.toUpperCase().includes('SINGARAJA') ||
        areaName.toUpperCase().includes('NEGARA') ||
        areaName.toUpperCase().includes('BALI')
          ? 'Bali & Nusa Tenggara'
          : 'Jawa';
      const city = areaName.toUpperCase().includes('DENPASAR')
        ? 'Denpasar'
        : areaName.toUpperCase().includes('SINGARAJA')
        ? 'Singaraja'
        : areaName.toUpperCase().includes('BONDOWOSO')
        ? 'Bondowoso'
        : areaName.toUpperCase().includes('SITUBONDO')
        ? 'Situbondo'
        : areaName.toUpperCase().includes('JEMBER')
        ? 'Jember'
        : 'Banyuwangi';

      const calIso = this.getScheduleCalendarIso(sch);
      const resolvedDepClock =
        (sch.departureTime && /^\d{2}:\d{2}$/.test(sch.departureTime.trim()) ? sch.departureTime.trim() : '') ||
        (sch.departureDate?.match(/T(\d{2}:\d{2})/)?.[1] || '07:30');
      const resolvedRetClock =
        (sch.targetReturnTime && /^\d{2}:\d{2}$/.test(sch.targetReturnTime.trim()) ? sch.targetReturnTime.trim() : '') ||
        (sch.estimatedArrival?.match(/T(\d{2}:\d{2})/)?.[1] || '17:00');
      const resolvedReturnDate = sch.returnDate || (sch.estimatedArrival ? sch.estimatedArrival.slice(0, 10) : calIso);
      const departureDate = calIso
        ? `${calIso}T${resolvedDepClock}:00+07:00`
        : sch.departureDate || '2026-01-05T07:30:00+07:00';
      const trackingNumber = sch.trackingNumber || `PO-AKK-20260105-${fleet?.plateNumber || sch.fleetId || 'DS3'}`;

      // Extract Inisial Mobil (e.g. DS1, DS3, NS2, NL1, N20)
      const trkFullMatch = trackingNumber.match(/^PO-AKK-\d{8}-(.+)-[A-Z0-9]+$/i);
      const poCodeMatch = trackingNumber.match(/PO-AKK-\d+-([A-Za-z0-9]+)/i);
      const extractedCode = trkFullMatch ? trkFullMatch[1].trim() : poCodeMatch ? poCodeMatch[1] : null;
      const initialCode = fleet?.initialCode || sch.fleet?.initialCode || sch.armada || extractedCode || sch.fleetId || 'DS3';
      const totalAreaTrips = this.crewHistory.filter(h => h.area.trim().toUpperCase() === areaName.toUpperCase()).length + 1;

      if (crew) {
        const existingIndex = this.crewHistory.findIndex(
          h =>
            (h.scheduleId === sch.id || h.trackingNumber === trackingNumber) &&
            (h.crewId === crew.id || h.crewName.trim().toLowerCase() === crew.name.trim().toLowerCase())
        );

        const areaStats = this.checkCrewAreaThreshold(crew.id, areaName);
        const seqNum = (existingIndex !== -1 ? this.crewHistory[existingIndex].areaTripSequenceNumber : areaStats.tripCount + 1) || 1;
        const reqAppr = seqNum >= this.areaThreshold;

        const historyItem: CrewDeliveryHistory = {
          id:
            existingIndex !== -1
              ? this.crewHistory[existingIndex].id
              : `cdh-sync-drv-${crew.id}-${sch.id || Math.random().toString(36).substring(2, 9)}`,
          crewId: crew.id,
          crewName: crew.name,
          scheduleId: sch.id,
          trackingNumber,
          storeName: areaName,
          area: areaName,
          city,
          island,
          vehiclePlate: fleet?.plateNumber || sch.fleet?.plateNumber || sch.fleetId || 'DS3',
          plateNumber: fleet?.plateNumber || sch.fleet?.plateNumber || sch.fleetId || 'DS3',
          initialCode,
          vehicleType: fleet?.vehicleType || 'Engkel STD',
          crewRole: 'Driver',
          cargoWeightTon: sch.cargoWeightTon || 3.5,
          cargoDescription: sch.cargoDescription || `Pengiriman ritase ke ${areaName}`,
          completionDate: departureDate,
          deliveryDate: calIso || undefined,
          departureTime: resolvedDepClock,
          targetReturnTime: resolvedRetClock,
          returnDate: resolvedReturnDate,
          status: 'delivered',
          onTimeStatus: 'Tepat Waktu',
          ratingReceived: 5.0,
          areaTripSequenceNumber: seqNum,
          totalAreaTrips,
          requiresAreaApproval: reqAppr,
          areaApprovalStatus: reqAppr ? 'approved' : 'not_required',
          notes: helper ? `Kru Driver: ${crew.name} | Helper: ${helper.name}` : `Kru Driver: ${crew.name}`
        };

        if (existingIndex !== -1) {
          this.crewHistory[existingIndex] = historyItem;
        } else {
          this.crewHistory.unshift(historyItem);
          addedCount++;
        }
      }

      // Also track Helper history if assigned
      if (helper) {
        const helperExistingIndex = this.crewHistory.findIndex(
          h =>
            (h.scheduleId === sch.id || h.trackingNumber === trackingNumber) &&
            (h.crewId === helper.id || h.crewName.trim().toLowerCase() === helper.name.trim().toLowerCase())
        );
        const helperAreaStats = this.checkCrewAreaThreshold(helper.id, areaName);
        const helperSeqNum =
          (helperExistingIndex !== -1
            ? this.crewHistory[helperExistingIndex].areaTripSequenceNumber
            : helperAreaStats.tripCount + 1) || 1;
        const helperReqAppr = helperSeqNum >= this.areaThreshold;

        const helperHistoryItem: CrewDeliveryHistory = {
          id:
            helperExistingIndex !== -1
              ? this.crewHistory[helperExistingIndex].id
              : `cdh-sync-hlp-${helper.id}-${sch.id || Math.random().toString(36).substring(2, 9)}`,
          crewId: helper.id,
          crewName: helper.name,
          scheduleId: sch.id,
          trackingNumber,
          storeName: areaName,
          area: areaName,
          city,
          island,
          vehiclePlate: fleet?.plateNumber || sch.fleet?.plateNumber || sch.fleetId || 'DS3',
          plateNumber: fleet?.plateNumber || sch.fleet?.plateNumber || sch.fleetId || 'DS3',
          initialCode,
          vehicleType: fleet?.vehicleType || 'Engkel STD',
          crewRole: 'Helper',
          cargoWeightTon: sch.cargoWeightTon || 3.5,
          cargoDescription: sch.cargoDescription || `Pengiriman ritase ke ${areaName} (Sebagai Helper)`,
          completionDate: departureDate,
          deliveryDate: calIso || undefined,
          departureTime: resolvedDepClock,
          targetReturnTime: resolvedRetClock,
          returnDate: resolvedReturnDate,
          status: 'delivered',
          onTimeStatus: 'Tepat Waktu',
          ratingReceived: 5.0,
          areaTripSequenceNumber: helperSeqNum,
          totalAreaTrips,
          requiresAreaApproval: helperReqAppr,
          areaApprovalStatus: helperReqAppr ? 'approved' : 'not_required',
          notes: crew ? `Tugas Helper mendampingi Driver: ${crew.name}` : `Tugas Helper (${areaName})`
        };

        if (helperExistingIndex !== -1) {
          this.crewHistory[helperExistingIndex] = helperHistoryItem;
        } else {
          this.crewHistory.unshift(helperHistoryItem);
          addedCount++;
        }
      }
    });

    // Deduplicate crewHistory array to ensure 100% unique React keys
    const seenIds = new Set<string>();
    this.crewHistory = this.crewHistory.map((item, index) => {
      if (seenIds.has(item.id)) {
        const uniqueId = `${item.id}-uniq-${index}-${Math.floor(Math.random() * 1000)}`;
        return { ...item, id: uniqueId };
      }
      seenIds.add(item.id);
      return item;
    });

    this.persistCrewRotationStateToMysql();
    this.notify();
    return addedCount;
  }

  // User Management & Authentication
  public getUsers(): UserProfile[] {
    return [...this.users];
  }

  public buildSessionAuthHeaders(extraHeaders?: Record<string, string>): Record<string, string> {
    const savedToken =
      (typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.SESSION_TOKEN) : null) ||
      (typeof sessionStorage !== 'undefined' ? sessionStorage.getItem(STORAGE_KEYS.SESSION_TOKEN) : null) ||
      '';
    const headers: Record<string, string> = { ...(extraHeaders || {}) };
    if (savedToken) {
      headers['Authorization'] = `Bearer ${savedToken}`;
      headers['x-akk-session-token'] = savedToken;
    }
    return headers;
  }

  public async refreshUsersFromHostinger(): Promise<boolean> {
    try {
      const response = await fetch('/api/users', {
        credentials: 'same-origin',
        headers: this.buildSessionAuthHeaders({ Accept: 'application/json' })
      });
      if (!response.ok) return false;
      const payload = await response.json();
      if (!Array.isArray(payload?.data)) return false;
      const localById = new Map(this.users.map(u => [u.id, u]));
      const localByEmail = new Map(
        this.users
          .filter(u => u.email)
          .map(u => [u.email.trim().toLowerCase(), u])
      );
      const mappedUsers: UserProfile[] = payload.data.map((r: any) => {
        const cleanEmail = String(r.email || '').trim().toLowerCase();
        const local = localById.get(r.id) || (cleanEmail ? localByEmail.get(cleanEmail) : undefined);
        const role = (r.role || local?.role || 'unassigned') as UserRole;
        const remotePerms = r.permissions && (r.permissions.modules || r.permissions.branchPermissions) ? r.permissions : undefined;
        const rawRemoteName = String(r.fullName || r.name || '').trim();
        const resolvedFullName = (cleanEmail === 'hendri123@gmail.com' && (!rawRemoteName || rawRemoteName.toLowerCase() === 'super admin'))
          ? 'Hendri'
          : (rawRemoteName || local?.fullName || r.email || 'User');
        const normalizedStatus = String(r.status || local?.status || 'pending').trim().toLowerCase() as UserProfile['status'];
        return {
          ...(local || {} as UserProfile),
          id: r.id,
          email: r.email || local?.email || '',
          fullName: resolvedFullName,
          role,
          department: r.department || local?.department || 'Logistics Operations',
          phone: r.phone || local?.phone || '',
          status: normalizedStatus,
          createdAt: r.createdAt || local?.createdAt,
          approvedAt: r.approvedAt || local?.approvedAt,
          approvedBy: r.approvedBy || local?.approvedBy,
          notes: r.notes ?? local?.notes,
          password: undefined,
          permissions: normalizeUserPermissions(role, remotePerms || local?.permissions)
        } as UserProfile;
      });

      // Jika data berasal langsung dari Hostinger MySQL, jadikan server sebagai single source of truth
      // agar akun yang dinonaktifkan/dihapus atau template demo lama tidak muncul kembali di daftar.
      if (payload?.source !== 'hostinger_mysql') {
        for (const localU of this.users) {
          const localEmail = (localU.email || '').trim().toLowerCase();
          const alreadyInMapped = mappedUsers.some(
            mu =>
              mu.id === localU.id ||
              (localEmail && (mu.email || '').trim().toLowerCase() === localEmail) ||
              this.isSameCrewPersonName(mu.fullName, localU.fullName)
          );
          if (!alreadyInMapped) {
            mappedUsers.push(localU);
          }
        }
      }

      this.users = this.deduplicateSuperAdmins(mappedUsers).filter(u => {
        const cleanId = String(u.id || '').trim().toLowerCase();
        const cleanEmail = String(u.email || '').trim().toLowerCase();
        const cleanName = String(u.fullName || '').trim().toLowerCase().replace(/\s+/g, ' ');
        return (
          cleanId !== 'usr-sales' &&
          cleanEmail !== 'shoim.sales@gmail.com' &&
          cleanName !== 'muhammad shoim'
        );
      });
      this.saveToStorage(STORAGE_KEYS.USERS, this.users);
      branchStore.hydrateUserBranchPermissionsFromUsers(this.users);

      // Pastikan currentUser tetap mengacu pada ID & email akun yang sedang login (tidak tertukar dengan super_admin lain)
      if (this.currentUser && this.currentUser.id !== 'usr-guest') {
        const currentEmail = (this.currentUser.email || '').trim().toLowerCase();
        const matchedCurrent =
          this.users.find(u => u.id === this.currentUser.id) ||
          (currentEmail ? this.users.find(u => (u.email || '').trim().toLowerCase() === currentEmail) : undefined);
        if (matchedCurrent) {
          this.currentUser = { ...matchedCurrent, password: undefined };
          this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
        }
      }

      this.syncUsersWithCrews();
      this.notify();
      return true;
    } catch (err) {
      console.warn('[Hostinger Users] Gagal refresh:', err);
      return false;
    }
  }

  private async syncUserToHostinger(userId: string, data: Partial<UserProfile>, attempt = 0): Promise<void> {
    const payload: Record<string, any> = { ...data };
    delete payload.password;
    try {
      const res = await fetch(`/api/users/${encodeURIComponent(userId)}`, {
        method: 'PUT',
        headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
        credentials: 'same-origin',
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        if (attempt < 2 && (res.status === 429 || res.status >= 500)) {
          setTimeout(() => {
            void this.syncUserToHostinger(userId, data, attempt + 1);
          }, 1200 * (attempt + 1));
        } else {
          const errJson = await res.json().catch(() => ({}));
          console.warn('[Hostinger Users] Sync update ditolak server:', res.status, errJson?.error || '');
        }
      }
    } catch (err) {
      if (attempt < 2) {
        setTimeout(() => {
          void this.syncUserToHostinger(userId, data, attempt + 1);
        }, 1200 * (attempt + 1));
      } else {
        console.warn('[Hostinger Users] Sync update gagal:', err);
      }
    }
  }

  public getPendingUsersCount(): number {
    return this.users.filter(u => u.status === 'pending').length;
  }

  public approveUser(userId: string, notes?: string) {
    this.verifyDriverAccess('user_management');
    const approverName = this.currentUser.fullName || 'Manager Operasional AKK';
    this.users = this.users.map(u => {
      if (u.id === userId) {
        this.logActivity('Approval User', u.fullName, `Disetujui oleh ${approverName}`);
        return {
          ...u,
          status: 'approved' as const,
          approvedAt: new Date().toISOString(),
          approvedBy: approverName,
          notes: notes || 'Disetujui oleh ' + approverName
        };
      }
      return u;
    });

    // If current user is the one approved, update currentUser too
    if (this.currentUser.id === userId) {
      this.currentUser = {
        ...this.currentUser,
        status: 'approved',
        approvedAt: new Date().toISOString(),
        approvedBy: approverName
      };
      this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    }

    this.saveToStorage(STORAGE_KEYS.USERS, this.users);
    this.syncUsersWithCrews();
    const approved = this.users.find(u => u.id === userId);
    if (approved) this.syncUserToHostinger(userId, approved);
    this.notify();
  }

  public rejectUser(userId: string, reason?: string) {
    this.verifyDriverAccess('user_management');
    this.users = this.users.map(u => {
      if (u.id === userId) {
        return {
          ...u,
          status: 'rejected' as const,
          notes: reason || 'Ditolak oleh Administrator AKK'
        };
      }
      return u;
    });

    if (this.currentUser.id === userId) {
      this.currentUser = {
        ...this.currentUser,
        status: 'rejected',
        notes: reason || 'Ditolak oleh Administrator AKK'
      };
      this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    }

    this.saveToStorage(STORAGE_KEYS.USERS, this.users);
    this.syncUsersWithCrews();
    const rejected = this.users.find(u => u.id === userId);
    if (rejected) {
      this.logActivity(
        'Tolak / Kurangi Pengajuan Akun',
        rejected.fullName,
        `Pengajuan akun ${rejected.fullName} (${rejected.email}) ditolak. Alasan: ${reason || 'Ditolak Administrator'}`,
        'kurangi'
      );
      this.syncUserToHostinger(userId, rejected);
    }
    this.notify();
  }

  public deactivateUser(userId: string, reason?: string): boolean {
    this.verifyDriverAccess('user_management');
    const user = this.users.find(u => u.id === userId);
    if (!user) return false;

    const adminName = this.currentUser.fullName || 'Super Admin';
    const updatedUser: UserProfile = {
      ...user,
      status: 'inactive',
      notes: reason || `Akun dinonaktifkan oleh ${adminName} (Data histori tetap tersimpan)`
    };

    // Immutable replacement so React subscribers always re-render driver/helper options immediately
    this.users = this.users.map(u => (u.id === userId ? updatedUser : u));

    if (this.currentUser.id === userId) {
      this.currentUser = {
        ...this.currentUser,
        status: 'inactive'
      };
      this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    }

    // Bersihkan entri kru terkait agar user nonaktif langsung hilang dari semua daftar driver/helper & pool kru
    const crewsToRemove = (this.crews || []).filter(
      c => c && (c.id === `crw-${userId}` || this.isSameCrewPersonName(c.name, user.fullName))
    );
    if (crewsToRemove.length > 0) {
      const removeIds = new Set(crewsToRemove.map(c => c.id));
      this.crews = (this.crews || []).filter(c => !removeIds.has(c.id));
      crewsToRemove.forEach(c => {
        fetch(`/api/crews/${encodeURIComponent(c.id)}`, {
          method: 'DELETE',
          headers: this.buildSessionAuthHeaders(),
          credentials: 'same-origin'
        }).catch(() => {});
      });
    }

    this.saveToStorage(STORAGE_KEYS.USERS, this.users);
    this.syncUsersWithCrews();
    this.logActivity('Nonaktifkan User', user.fullName, `Akun ${user.fullName} dinonaktifkan. Hak akses ditutup, histori data tetap tersimpan.`);
    void this.syncUserToHostinger(userId, updatedUser);
    this.notify();
    return true;
  }

  public activateUser(userId: string, notes?: string): boolean {
    this.verifyDriverAccess('user_management');
    const user = this.users.find(u => u.id === userId);
    if (!user) return false;

    const approverName = this.currentUser.fullName || 'Super Admin';
    const updatedUser: UserProfile = {
      ...user,
      status: 'approved',
      approvedAt: new Date().toISOString(),
      approvedBy: approverName,
      notes: notes || `Akun diaktifkan kembali oleh ${approverName}`
    };

    this.users = this.users.map(u => (u.id === userId ? updatedUser : u));

    if (this.currentUser.id === userId) {
      this.currentUser = {
        ...this.currentUser,
        status: 'approved',
        approvedAt: new Date().toISOString(),
        approvedBy: approverName
      };
      this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    }

    this.saveToStorage(STORAGE_KEYS.USERS, this.users);
    this.syncUsersWithCrews();
    this.logActivity('Aktifkan User', user.fullName, `Akun ${user.fullName} diaktifkan kembali dan hak akses dipulihkan.`);
    void this.syncUserToHostinger(userId, updatedUser);
    this.notify();
    return true;
  }

  public getActiveUsers(): UserProfile[] {
    return this.users.filter(u => u.status === 'approved');
  }

  public updateUserRole(userId: string, role: UserRole) {
    this.updateUserProfile(userId, { role });
  }

  public updateUserProfile(userId: string, data: Partial<UserProfile>): boolean {
    this.verifyDriverAccess('user_management');
    const userIndex = this.users.findIndex(u => u.id === userId);
    if (userIndex === -1) return false;

    const existing = this.users[userIndex];
    const oldName = existing.fullName;
    const oldRole = existing.role;
    const targetRole = (data.role || existing.role) as UserRole;
    const roleChanged = Boolean(data.role && data.role !== oldRole);

    let rawPermissions: UserPermissions | undefined;
    if (data.permissions) {
      rawPermissions = data.permissions;
    } else if (roleChanged) {
      const wasCrewRole = oldRole === 'driver' || oldRole === 'crew_helper';
      const isNowCrewRole = targetRole === 'driver' || targetRole === 'crew_helper';
      const existingMods = existing.permissions?.modules || {};
      const hasCustomNonLogisticsAccess = Object.entries(existingMods).some(
        ([modKey, modVal]) =>
          modKey !== 'logistics' &&
          modVal?.enabled &&
          Object.values(modVal.subMenus || {}).some(v => v === 'full_access' || v === 'read_only')
      );

      if (wasCrewRole && !isNowCrewRole) {
        if (hasCustomNonLogisticsAccess) {
          // Pertahankan hak akses kustom non-logistik yang sudah diatur (misal Gudang -> Database Barang)
          // sambil memastikan akses kru logistik lama dinonaktifkan.
          const cleanedModules: UserPermissions['modules'] = JSON.parse(JSON.stringify(existingMods));
          if (cleanedModules.logistics) {
            cleanedModules.logistics.enabled = false;
            Object.keys(cleanedModules.logistics.subMenus || {}).forEach(k => {
              cleanedModules.logistics.subMenus[k] = 'none';
            });
          }
          const cleanedBranches = existing.permissions?.branchPermissions
            ? JSON.parse(JSON.stringify(existing.permissions.branchPermissions))
            : undefined;
          if (cleanedBranches) {
            Object.values(cleanedBranches).forEach((bEntry: any) => {
              if (bEntry?.modules?.logistics) {
                bEntry.modules.logistics.enabled = false;
                Object.keys(bEntry.modules.logistics.subMenus || {}).forEach(k => {
                  bEntry.modules.logistics.subMenus[k] = 'none';
                });
              }
            });
          }
          rawPermissions = {
            modules: cleanedModules,
            branchPermissions: cleanedBranches
          };
        } else {
          // Gunakan default permissions untuk role baru (misal Gudang / Sales / HR)
          rawPermissions = { modules: getDefaultPermissionsForRole(targetRole) };
        }
      } else {
        rawPermissions = { modules: getDefaultPermissionsForRole(targetRole) };
      }
    } else if (existing.permissions && (existing.permissions.modules || existing.permissions.branchPermissions)) {
      rawPermissions = existing.permissions;
    } else {
      rawPermissions = { modules: getDefaultPermissionsForRole(targetRole) };
    }

    const nextPermissions = normalizeUserPermissions(targetRole, rawPermissions);

    const updatedUser: UserProfile = {
      ...existing,
      ...data,
      permissions: nextPermissions,
      id: userId
    };

    this.users = this.users.map(u => (u.id === userId ? updatedUser : u));

    if (this.currentUser.id === userId) {
      this.currentUser = { ...updatedUser };
      this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    }

    // Jika akun user ini bukan lagi kru pengiriman aktif (misal diubah ke Gudang / warehouse_admin atau 0 AKSES Logistik),
    // bersihkan entri kru terkait dari this.crews dan database server agar langsung hilang dari jadwal & stand by!
    if (!this.isActiveDeliveryCrewUser(updatedUser)) {
      const crewsToRemove = (this.crews || []).filter(
        c =>
          c &&
          (c.id === `crw-${userId}` ||
            this.isSameCrewPersonName(c.name, oldName) ||
            this.isSameCrewPersonName(c.name, updatedUser.fullName))
      );
      if (crewsToRemove.length > 0) {
        const removeIds = new Set(crewsToRemove.map(c => c.id));
        this.crews = (this.crews || []).filter(c => !removeIds.has(c.id));
        this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);
        crewsToRemove.forEach(c => {
          fetch(`/api/crews/${encodeURIComponent(c.id)}`, {
            method: 'DELETE',
            headers: this.buildSessionAuthHeaders(),
            credentials: 'same-origin'
          }).catch(() => {});
        });
      }
    } else if ((data.fullName && data.fullName !== oldName) || data.phone !== undefined) {
      // Direct synchronization: If name or phone changed on an active crew, sync with crew pool & active schedules
      const newName = data.fullName || oldName;
      const newPhone = data.phone !== undefined ? data.phone : existing.phone;
      let crewsUpdated = false;
      this.crews = this.crews.map(c => {
        if (
          c.id === `crw-${userId}` ||
          this.isSameCrewPersonName(c.name, oldName) ||
          (c.phone && existing.phone && c.phone === existing.phone)
        ) {
          crewsUpdated = true;
          return { ...c, name: newName, phone: newPhone || c.phone };
        }
        return c;
      });
      if (crewsUpdated) {
        this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);
      }

      let schUpdated = false;
      this.schedules = this.schedules.map(s => {
        let changed = false;
        let newCrew = s.crew;
        let newHelper = s.crewHelper;
        let newHelper2 = s.crewHelper2;

        if (s.crew && this.isSameCrewPersonName(s.crew.name, oldName)) {
          newCrew = { ...s.crew, name: newName };
          changed = true;
        }
        if (s.crewHelper && this.isSameCrewPersonName(s.crewHelper.name, oldName)) {
          newHelper = { ...s.crewHelper, name: newName };
          changed = true;
        }
        if (s.crewHelper2 && this.isSameCrewPersonName(s.crewHelper2.name, oldName)) {
          newHelper2 = { ...s.crewHelper2, name: newName };
          changed = true;
        }
        if (changed) {
          schUpdated = true;
          return { ...s, crew: newCrew, crewHelper: newHelper, crewHelper2: newHelper2 };
        }
        return s;
      });
      if (schUpdated) {
        this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
      }
    }

    this.saveToStorage(STORAGE_KEYS.USERS, this.users);
    this.syncUsersWithCrews();
    this.syncUserToHostinger(userId, updatedUser);
    const changedParts: string[] = [];
    if (data.fullName && data.fullName !== oldName) changedParts.push(`Nama: ${oldName} → ${data.fullName}`);
    if (data.role && data.role !== oldRole) changedParts.push(`Role: ${oldRole} → ${data.role}`);
    if (data.department && data.department !== existing.department) changedParts.push(`Departemen: ${data.department}`);
    if (data.phone && data.phone !== existing.phone) changedParts.push(`No. HP: ${data.phone}`);
    if (data.permissions) changedParts.push('Hak Akses Modul');
    this.logActivity(
      'Ubah Data Akun User',
      updatedUser.fullName,
      changedParts.length > 0
        ? `Merubah data akun ${updatedUser.fullName} (${changedParts.join(', ')})`
        : `Merubah profil / hak akses akun ${updatedUser.fullName}`,
      'ubah'
    );
    this.notify();
    return true;
  }

  public deleteUser(userId: string) {
    const target = this.users.find(u => u.id === userId);
    this.users = this.users.filter(u => u.id !== userId);
    if (target) {
      this.crews = (this.crews || []).filter(
        c => c.id !== `crw-${userId}` && !this.isSameCrewPersonName(c.name, target.fullName)
      );
      this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);
      this.logActivity(
        'Hapus Data Akun User',
        target.fullName,
        `Menghapus akun user ${target.fullName} (${target.email || target.role}) dari daftar pengguna`,
        'kurangi'
      );
    }
    this.saveToStorage(STORAGE_KEYS.USERS, this.users);
    this.syncUsersWithCrews();
    fetch(`/api/users/${encodeURIComponent(userId)}`, {
      method: 'DELETE',
      headers: this.buildSessionAuthHeaders(),
      credentials: 'same-origin'
    }).catch(err => console.warn('[Hostinger Users] Hapus user gagal:', err));
    this.notify();
  }

  public registerUser(data: {
    id?: string;
    fullName: string;
    email: string;
    role?: UserRole;
    department: string;
    phone?: string;
    notes?: string;
    password?: string;
    status?: UserApprovalStatus;
    permissions?: UserPermissions;
  }): UserProfile {
    const resolvedRole: UserRole = data.role || 'unassigned';
    const cleanPhone = String(data.phone || '').trim();
    const newUser: UserProfile = {
      id: data.id || ('usr-' + Math.random().toString(36).substring(2, 8)),
      fullName: data.fullName,
      email: data.email,
      role: resolvedRole,
      department: data.department || 'Logistik & Pengiriman',
      phone: cleanPhone,
      password: undefined,
      status: data.status || 'pending',
      createdAt: new Date().toISOString(),
      notes: data.notes || 'Pendaftaran mandiri melalui portal AKK - Menunggu persetujuan (acc) Super Admin',
      permissions: normalizeUserPermissions(
        resolvedRole,
        data.permissions || {
          modules: getDefaultPermissionsForRole(resolvedRole)
        }
      )
    };

    this.users = [newUser, ...this.users];
    this.saveToStorage(STORAGE_KEYS.USERS, this.users);
    this.syncUsersWithCrews();
    const endpoint = this.currentUser?.role === 'super_admin' ? '/api/users' : '/api/auth/register';
    fetch(endpoint, {
      method: 'POST',
      headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'same-origin',
      body: JSON.stringify({
        id: newUser.id,
        fullName: newUser.fullName,
        email: newUser.email,
        phone: newUser.phone,
        role: newUser.role,
        department: newUser.department,
        status: newUser.status,
        notes: newUser.notes,
        permissions: newUser.permissions,
        password: data.password || ''
      })
    }).catch(err => console.warn('[Hostinger Users] Registrasi user gagal disinkronkan:', err));
    this.notify();

    return newUser;
  }

  /**
   * Mendeteksi akun pengguna secara cerdas melalui berbagai input:
   * 1. Email lengkap (e.g. budiono@gmail.com)
   * 2. Username saja (e.g. budiono)
   * 3. ID pengguna (e.g. usr-budiono atau budiono)
   * 4. Nama lengkap pengguna (e.g. Budiono, MUHAMMAD SYAIFUL BAHRI)
   * 5. Nama kru supir / helper (e.g. Budiono, Zainul Agustiar)
   * 6. Alias admin resmi (admin, superadmin, bayun791)
   */
  public findUserByIdentifier(identifier: string): UserProfile | undefined {
    const cleanId = (identifier || '').trim().toLowerCase();
    if (!cleanId) return undefined;

    // SKEMA VALIDASI KETAT:
    // Jika input mengandung '@', perlakukan sebagai format EMAIL murni
    if (cleanId.includes('@')) {
      let match = this.users.find(u => u.email && u.email.trim().toLowerCase() === cleanId);
      if (match) return match;

      // Preview-only fallback. Production users always come from Hostinger MySQL.
      if (this.isPreviewEnvironment()) {
        const initMatch = INITIAL_PROFILES.find(p => p.email && p.email.trim().toLowerCase() === cleanId);
        if (initMatch) {
          match = this.users.find(u => u.id === initMatch.id);
          return match || initMatch;
        }
      }

      const emailPrefix = cleanId.split('@')[0].trim().toLowerCase();
      if (['admin', 'superadmin', 'super.admin', 'akkoperasional60'].includes(emailPrefix)) {
        return (
          this.users.find(u => u.role === 'super_admin' || u.id === 'usr-001') ||
          (this.isPreviewEnvironment() ? INITIAL_PROFILES.find(p => p.role === 'super_admin') : undefined)
        );
      }
      if (['bayun791', 'bayun', 'bayu', 'operasional', 'ops'].includes(emailPrefix)) {
        return (
          this.users.find(u => u.id === 'usr-operasional' || u.role === 'operasional') ||
          (this.isPreviewEnvironment() ? INITIAL_PROFILES.find(p => p.role === 'operasional') : undefined)
        );
      }
      return undefined;
    }

    // Jika input TIDAK mengandung '@', perlakukan secara ketat sebagai USERNAME / NAMA / ID
    // 1. Cek ID pengguna persis (contoh: 'usr-budiono' atau 'usr-001')
    let user = this.users.find(u => u.id && u.id.trim().toLowerCase() === cleanId);
    if (user) return user;

    // 2. Cek username sebelum '@' pada email (contoh: 'budiono' dari 'budiono@gmail.com')
    user = this.users.find(u => {
      if (!u.email) return false;
      const emailUser = u.email.split('@')[0].trim().toLowerCase();
      return emailUser === cleanId;
    });
    if (user) return user;

    // 3. Cek ID tanpa prefix 'usr-' (contoh: 'budiono' dari 'usr-budiono')
    user = this.users.find(u => {
      if (!u.id) return false;
      const strippedId = u.id.replace(/^usr-/, '').trim().toLowerCase();
      return strippedId === cleanId;
    });
    if (user) return user;

    // 4. Cek nama lengkap secara persis (contoh: 'Budiono', 'BUDIONO')
    user = this.users.find(u => (u.fullName || '').trim().toLowerCase() === cleanId);
    if (user) return user;

    // 5. Cek kata depan nama lengkap atau kemiripan kata
    user = this.users.find(u => {
      const fNameLower = (u.fullName || '').trim().toLowerCase();
      const words = fNameLower.split(/\s+/);
      return words.includes(cleanId) || (cleanId.length >= 3 && fNameLower.includes(cleanId));
    });
    if (user) return user;

    // 6. Cek daftar kru (supir / helper di lapangan)
    const matchedCrew = this.crews.find(c => {
      const cNameLower = (c.name || '').trim().toLowerCase();
      return (
        c.id.toLowerCase() === cleanId ||
        cNameLower === cleanId ||
        cNameLower.split(/\s+/).includes(cleanId) ||
        (cleanId.length >= 3 && cNameLower.includes(cleanId))
      );
    });
    if (matchedCrew) {
      const crewUser = this.users.find(u => 
        (u.fullName || '').trim().toLowerCase() === matchedCrew.name.trim().toLowerCase() ||
        (u.id === `usr-${matchedCrew.id}`) ||
        (u.email && u.email.toLowerCase().includes(matchedCrew.name.toLowerCase().split(' ')[0]))
      );
      if (crewUser) return crewUser;

      const targetRole: UserRole = matchedCrew.role.toLowerCase().includes('helper') ? 'crew_helper' : 'driver';
      if (this.isPreviewEnvironment()) {
        const dynamicCrewUser: UserProfile = {
          id: `usr-${matchedCrew.id}`,
          email: `${matchedCrew.name.toLowerCase().replace(/[^a-z0-9]/g, '')}@gmail.com`,
          fullName: matchedCrew.name,
          role: targetRole,
          department: 'Pengiriman',
          phone: matchedCrew.phone || '',
          status: 'approved',
          permissions: { modules: getDefaultPermissionsForRole(targetRole) }
        };
        return dynamicCrewUser;
      }
      const roleUser = this.users.find(u => u.role === targetRole);
      if (roleUser) return roleUser;
    }

    // 7. Alias Super Admin khusus (hanya jika kata kunci admin/bayun/akkoperasional60)
    if (['admin', 'superadmin', 'super admin', 'bayun791', 'bayun', 'akkoperasional60'].includes(cleanId)) {
      return (
        this.users.find(u => u.role === 'super_admin' || u.id === 'usr-001') ||
        (this.isPreviewEnvironment() ? INITIAL_PROFILES.find(p => p.role === 'super_admin') : undefined)
      );
    }

    return undefined;
  }

  public loginUser(identifier: string, password?: string): UserProfile | null {
    // Legacy local login is intentionally strict and kept only for offline/dev compatibility.
    // Production UI authenticates against Hostinger MySQL through loginUserRemote().
    const existing = this.findUserByIdentifier(identifier);
    if (!existing || existing.status !== 'approved') return null;
    const expected = String(existing.password || '');
    const supplied = String(password || '');
    if (!expected || !supplied || supplied !== expected) return null;
    this.setCurrentUser(existing);
    return existing;
  }

  private lastAuthError: { status: number; message: string } | null = null;

  public getLastAuthError(): { status: number; message: string } | null {
    return this.lastAuthError;
  }

  private tryPreviewLoginFallback(identifier: string, password: string): UserProfile | null {
    if (!this.isPreviewEnvironment()) return null;
    const cleanPass = String(password || '').trim();
    if (cleanPass.length < 6) {
      this.lastAuthError = {
        status: 401,
        message: 'Email/username atau password salah'
      };
      return null;
    }

    const matched = this.findUserByIdentifier(identifier.trim());
    if (!matched) {
      this.lastAuthError = {
        status: 401,
        message: 'Email/username atau password salah'
      };
      return null;
    }

    if (matched.status !== 'approved') {
      this.lastAuthError = {
        status: 403,
        message: `Akun berstatus ${matched.status || 'pending'} dan belum dapat login`
      };
      return null;
    }

    const resolvedUser: UserProfile = {
      ...matched,
      password: undefined,
      permissions: normalizeUserPermissions(matched.role, matched.permissions)
    };

    const idx = this.users.findIndex(u =>
      u.id === resolvedUser.id ||
      (resolvedUser.email && u.email?.toLowerCase() === resolvedUser.email.toLowerCase())
    );
    if (idx >= 0) this.users[idx] = resolvedUser;
    else this.users = [resolvedUser, ...this.users];
    this.users = this.deduplicateSuperAdmins(this.users);
    this.saveToStorage(STORAGE_KEYS.USERS, this.users);
    this.setCurrentUser(resolvedUser);
    void this.ensurePreviewServerSession(true);
    this.lastAuthError = null;
    return resolvedUser;
  }

  public async loginUserRemote(identifier: string, password: string): Promise<UserProfile | null> {
    this.lastAuthError = null;
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ identifier: identifier.trim(), password })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        const previewFallback = this.tryPreviewLoginFallback(identifier, password);
        if (previewFallback) return previewFallback;

        this.lastAuthError = {
          status: response.status,
          message: String(payload?.error || 'Gagal memproses login ke server.')
        };
        return null;
      }
      const remote = payload?.user;
      if (!remote?.id) {
        const previewFallback = this.tryPreviewLoginFallback(identifier, password);
        if (previewFallback) return previewFallback;
        return null;
      }

      if (payload?.sessionToken) {
        try {
          if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEYS.SESSION_TOKEN, String(payload.sessionToken));
          if (typeof sessionStorage !== 'undefined') sessionStorage.setItem(STORAGE_KEYS.SESSION_TOKEN, String(payload.sessionToken));
        } catch {}
      }

      const remoteEmail = String(remote.email || '').trim().toLowerCase();
      const existing = this.users.find(u =>
        u.id === remote.id ||
        (remoteEmail && u.email?.toLowerCase() === remoteEmail)
      );
      const role = (remote.role || existing?.role || 'unassigned') as UserRole;
      const rawRemoteName = String(remote.fullName || remote.name || '').trim();
      const resolvedFullName = (remoteEmail === 'hendri123@gmail.com' && (!rawRemoteName || rawRemoteName.toLowerCase() === 'super admin'))
        ? 'Hendri'
        : (rawRemoteName || existing?.fullName || (role === 'super_admin' ? 'Super Admin' : (remote.email || 'User')));
      const user: UserProfile = {
        ...(existing || {} as UserProfile),
        id: remote.id,
        email: remote.email || existing?.email || '',
        fullName: resolvedFullName,
        role,
        department: remote.department || existing?.department || 'Logistics Operations',
        phone: remote.phone || existing?.phone || '',
        status: remote.status || existing?.status || 'approved',
        permissions: normalizeUserPermissions(
          role,
          (remote.permissions && remote.permissions.modules) ? remote.permissions : existing?.permissions
        )
      } as UserProfile;

      const idx = this.users.findIndex(u =>
        u.id === user.id ||
        (user.email && u.email?.toLowerCase() === user.email.toLowerCase())
      );
      if (idx >= 0) {
        this.users = this.users.map((u, i) => (i === idx ? ({ ...u, ...user, password: undefined } as UserProfile) : u));
      } else {
        this.users = [{ ...user, password: undefined } as UserProfile, ...this.users];
      }
      this.users = this.deduplicateSuperAdmins(this.users);
      this.saveToStorage(STORAGE_KEYS.USERS, this.users);
      this.setCurrentUser({ ...user, password: undefined } as UserProfile);
      void this.hydrateOperationalDataFromHostinger();
      await this.refreshUsersFromHostinger();
      return user;
    } catch (err: any) {
      const previewFallback = this.tryPreviewLoginFallback(identifier, password);
      if (previewFallback) return previewFallback;

      this.lastAuthError = {
        status: 503,
        message: 'Tidak dapat terhubung ke server autentikasi. Periksa koneksi jaringan atau status server.'
      };
      console.warn('[Hostinger Auth] Login gagal:', err);
      return null;
    }
  }

  public async hydrateOperationalDataFromHostinger(force: boolean = false): Promise<boolean> {
    if (this.hydratePromise) {
      return this.hydratePromise;
    }
    const nowMs = Date.now();
    if (nowMs < this.hydrateRateLimitedUntil) {
      return false;
    }
    if (!force && nowMs - this.lastHydrateAt < 15000) {
      return true;
    }
    this.lastHydrateAt = nowMs;
    this.hydratePromise = (async () => {
      try {
        if (this.isPreviewEnvironment()) {
          await this.ensurePreviewServerSession(false);
        }
        let authHeaders = this.buildSessionAuthHeaders();

        // Priority 1: muat 4 data inti operasional terlebih dahulu agar UI tampil cepat tanpa membanjiri koneksi server
        let [fleetRes, crewRes, storeRes, scheduleRes] = await Promise.all([
          fetch('/api/fleets', { credentials: 'same-origin', headers: authHeaders }),
          fetch('/api/crews', { credentials: 'same-origin', headers: authHeaders }),
          fetch('/api/stores', { credentials: 'same-origin', headers: authHeaders }),
          fetch('/api/schedules/persisted', { credentials: 'same-origin', headers: authHeaders })
        ]);

        if (
          this.isPreviewEnvironment() &&
          (fleetRes.status === 401 || crewRes.status === 401 || storeRes.status === 401 || scheduleRes.status === 401)
        ) {
          const recovered = await this.ensurePreviewServerSession(true);
          if (recovered) {
            authHeaders = this.buildSessionAuthHeaders();
            [fleetRes, crewRes, storeRes, scheduleRes] = await Promise.all([
              fetch('/api/fleets', { credentials: 'same-origin', headers: authHeaders }),
              fetch('/api/crews', { credentials: 'same-origin', headers: authHeaders }),
              fetch('/api/stores', { credentials: 'same-origin', headers: authHeaders }),
              fetch('/api/schedules/persisted', { credentials: 'same-origin', headers: authHeaders })
            ]);
          }
        }

        if (
          fleetRes.status === 429 ||
          crewRes.status === 429 ||
          storeRes.status === 429 ||
          scheduleRes.status === 429
        ) {
          this.hydrateRateLimitedUntil = Date.now() + 60000;
          return false;
        }

        const [fleetPayload, crewPayload, storePayload, schedulePayload] = await Promise.all([
          fleetRes.ok ? fleetRes.json().catch(() => ({})) : Promise.resolve({}),
          crewRes.ok ? crewRes.json().catch(() => ({})) : Promise.resolve({}),
          storeRes.ok ? storeRes.json().catch(() => ({})) : Promise.resolve({}),
          scheduleRes.ok ? scheduleRes.json().catch(() => ({})) : Promise.resolve({})
        ]);

        // Priority 2: muat data sekunder secara tertunda setelah tampilan utama siap agar tidak memperlambat reload awal
        if (fleetRes.ok || crewRes.ok || storeRes.ok || scheduleRes.ok) {
          setTimeout(() => {
            void (async () => {
              try {
                const [fuelRes, scanRes, rotationRes, adminSchedRes] = await Promise.all([
                  fetch('/api/fuel-logs', { credentials: 'same-origin', headers: authHeaders }),
                  fetch('/api/scanned-documents', { credentials: 'same-origin', headers: authHeaders }),
                  fetch('/api/logistics/crew-rotation-state', { credentials: 'same-origin', headers: authHeaders }),
                  fetch('/api/admin-schedules', { credentials: 'same-origin', headers: authHeaders })
                ]);
                const [fuelPayload, scanPayload, rotationPayload, adminSchedPayload] = await Promise.all([
                  fuelRes.ok ? fuelRes.json().catch(() => ({})) : Promise.resolve({}),
                  scanRes.ok ? scanRes.json().catch(() => ({})) : Promise.resolve({}),
                  rotationRes.ok ? rotationRes.json().catch(() => ({})) : Promise.resolve({}),
                  adminSchedRes.ok ? adminSchedRes.json().catch(() => ({})) : Promise.resolve({})
                ]);
                let secondaryUpdated = false;
                if (fuelRes.ok && Array.isArray(fuelPayload?.data)) {
                  const serverLogs: FuelLog[] = (fuelPayload.data as FuelLog[]).filter(
                    l => !this.pendingFuelLogDeletes.has(l.id)
                  );
                  const mergedMap = new Map<string, FuelLog>();
                  serverLogs.forEach(l => mergedMap.set(l.id, l));

                  // Preserve any locally created/edited fuel logs that haven't finished syncing yet
                  this.pendingFuelLogUpserts.forEach((pendingLog, pendingId) => {
                    if (!this.pendingFuelLogDeletes.has(pendingId)) {
                      mergedMap.set(pendingId, pendingLog);
                      if (!serverLogs.some(sl => sl.id === pendingId)) {
                        void this.syncFuelLogToServer('POST', '/api/fuel-logs', pendingLog);
                      }
                    }
                  });

                  // Safety guard: if server fallback came back empty after container restart while memory has active logs, push them back
                  if (
                    fuelPayload.source !== 'hostinger_mysql' &&
                    serverLogs.length === 0 &&
                    this.fuelLogs.length > 0
                  ) {
                    this.fuelLogs.forEach(localLog => {
                      if (!this.pendingFuelLogDeletes.has(localLog.id)) {
                        mergedMap.set(localLog.id, localLog);
                        this.pendingFuelLogUpserts.set(localLog.id, localLog);
                        void this.syncFuelLogToServer('POST', '/api/fuel-logs', localLog);
                      }
                    });
                  }

                  this.fuelLogs = Array.from(mergedMap.values());
                  secondaryUpdated = true;
                }
                if (scanRes.ok && Array.isArray(scanPayload?.data)) {
                  this.scannedDocuments = scanPayload.data;
                  secondaryUpdated = true;
                }
                if (rotationRes.ok && rotationPayload?.data && typeof rotationPayload.data === 'object') {
                  if (typeof rotationPayload.data.areaThreshold === 'number') {
                    this.areaThreshold = rotationPayload.data.areaThreshold;
                  }
                  if (Array.isArray(rotationPayload.data.areaApprovals)) {
                    this.areaApprovals = rotationPayload.data.areaApprovals;
                  }
                  if (Array.isArray(rotationPayload.data.crewHistory)) {
                    this.crewHistory = rotationPayload.data.crewHistory;
                  }
                  secondaryUpdated = true;
                }
                if (adminSchedRes.ok && Array.isArray(adminSchedPayload?.schedules)) {
                  this.lastAdminScheduleWeeksList = adminSchedPayload.schedules;
                  secondaryUpdated = true;
                }
                if (secondaryUpdated) {
                  this.notify();
                }
              } catch {
                // ignore secondary background sync error
              }
            })();
          }, 650);
        }

        if (fleetRes.ok && Array.isArray(fleetPayload?.data)) {
          const deletedIdSet = new Set(
            Array.isArray(fleetPayload?.deletedIds) ? fleetPayload.deletedIds.map((x: any) => String(x).trim()) : []
          );
          const deletedPlateSet = new Set(
            Array.isArray(fleetPayload?.deletedPlates)
              ? fleetPayload.deletedPlates.map((x: any) => String(x).replace(/\s+/g, '').toUpperCase())
              : []
          );
          const isPhantomPlate = (plate?: string): boolean =>
            /^FLT-\d+$/i.test(String(plate || '').trim()) || String(plate || '').trim().toUpperCase().endsWith('AKK');
          const isMysqlSource = fleetPayload?.source === 'hostinger_mysql';
          const fallbackPool = isMysqlSource ? this.fleets : (this.fleets && this.fleets.length > 0 ? this.fleets : INITIAL_FLEETS);
          const baseFleets = (fallbackPool || []).filter(bf => {
            const cleanP = String(bf.plateNumber || '').replace(/\s+/g, '').toUpperCase();
            return cleanP && !isPhantomPlate(bf.plateNumber) && !deletedIdSet.has(bf.id) && !deletedPlateSet.has(cleanP);
          });

          if (fleetPayload.data.length > 0) {
            const getCanonDedupKey = (flt: Partial<Fleet>) => {
              const canon = resolveCanonicalFleetMeta(flt);
              if (canon?.id) return canon.id.toLowerCase();
              return String(flt.plateNumber || '').replace(/\s+/g, '').toUpperCase();
            };
            const localByPlate = new Map<string, Fleet>();
            baseFleets.forEach(bf => {
              const cleanP = getCanonDedupKey(bf);
              if (cleanP && !localByPlate.has(cleanP)) localByPlate.set(cleanP, bf);
            });
            const mergedMap = new Map<string, Fleet>();
            if (!isMysqlSource) {
              baseFleets.forEach(bf => {
                const cleanP = getCanonDedupKey(bf);
                if (cleanP && !mergedMap.has(cleanP)) mergedMap.set(cleanP, bf);
              });
            }
            fleetPayload.data.forEach((remoteF: Fleet) => {
              const cleanRemotePlate = String(remoteF.plateNumber || '').replace(/\s+/g, '').toUpperCase();
              if (!cleanRemotePlate || isPhantomPlate(remoteF.plateNumber)) return;
              if (deletedIdSet.has(remoteF.id) || deletedPlateSet.has(cleanRemotePlate)) return;
              const dedupKey = getCanonDedupKey(remoteF);
              const matchExisting = localByPlate.get(dedupKey);
              const existingMerged = mergedMap.get(dedupKey);
              const canonicalMatch = resolveCanonicalFleetMeta(remoteF);
              const canonicalId =
                canonicalMatch?.id ||
                (remoteF.id && String(remoteF.id).trim()) ||
                matchExisting?.id ||
                remoteF.id;
              const candidate = this.enrichFleetItem({ ...remoteF, id: canonicalId }, existingMerged || matchExisting);
              if (!existingMerged || /^flt-\d+$/i.test(candidate.id)) {
                mergedMap.set(dedupKey, candidate);
              }
            });
            this.fleets = sortFleetsByCanonicalOrder(Array.from(mergedMap.values()));
            this.cachedFleets = null;
            this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets, true);
          } else if (!isMysqlSource) {
            this.fleets = sortFleetsByCanonicalOrder(baseFleets);
            this.cachedFleets = null;
            this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets, true);
          }
        }
        if (crewRes.ok && Array.isArray(crewPayload?.data) && (crewPayload.source === 'hostinger_mysql' || crewPayload.data.length > 0)) {
          this.crews = crewPayload.data;
          this.saveToStorage(STORAGE_KEYS.CREWS, this.crews, true);
        }
        if (storeRes.ok && Array.isArray(storePayload?.data)) {
          const validRemoteStores = storePayload.data.filter((item: RetailStore) => !isAreaRouteItem(item));
          if (validRemoteStores.length > 0) {
            const storeMap = new Map<string, RetailStore>();
            INITIAL_STORES.forEach(s => {
              if (!isAreaRouteItem(s)) storeMap.set(s.id, s);
            });
            validRemoteStores.forEach((remS: RetailStore) => {
              storeMap.set(remS.id, remS);
            });
            this.stores = Array.from(storeMap.values());
          } else if (!this.stores || this.stores.length === 0) {
            this.stores = [...INITIAL_STORES];
          }
          this.saveToStorage(STORAGE_KEYS.STORES, this.stores, true);
        }
        if (scheduleRes.ok && (schedulePayload?.source === 'hostinger_mysql' || schedulePayload?.source === 'disk_database' || schedulePayload?.exists)) {
          const remoteSchedules: Schedule[] = (Array.isArray(schedulePayload?.schedules) ? schedulePayload.schedules : []).filter(
            (s: any) => s && typeof s === 'object' && s.id && !String(s.id).startsWith('batch-') && (s.departureDate || s.areaName || s.trackingNumber)
          );
          const deletedIdsSet = new Set<string>(
            Array.isArray(schedulePayload?.deletedIds) ? schedulePayload.deletedIds.map((x: any) => String(x)) : []
          );
          const localById = new Map<string, Schedule>();
          for (const loc of this.schedules || []) {
            if (loc?.id && !String(loc.id).startsWith('batch-')) localById.set(loc.id, loc);
          }
          const mergedIds = new Set<string>();
          const mergedSchedules: Schedule[] = [];

          for (const rem of remoteSchedules) {
            if (!rem?.id || deletedIdsSet.has(String(rem.id))) continue;
            mergedIds.add(rem.id);
            const loc = localById.get(rem.id);
            const locTime = loc?.updatedAt ? new Date(loc.updatedAt).getTime() : 0;
            const remTime = rem?.updatedAt ? new Date(rem.updatedAt).getTime() : 0;

            // Server database is authoritative. Only prefer local if local has a strictly newer updatedAt timestamp.
            const combined: Schedule = (loc && locTime > 0 && remTime > 0 && locTime > remTime)
              ? { ...rem, ...loc }
              : (loc ? { ...loc, ...rem } : { ...rem });

            if (!combined.armada && (rem.armada || loc?.armada || rem.fleet?.initialCode || loc?.fleet?.initialCode)) {
              combined.armada = rem.armada || loc?.armada || rem.fleet?.initialCode || loc?.fleet?.initialCode;
            }
            if (!combined.fleet && (rem.fleet || loc?.fleet)) {
              combined.fleet = rem.fleet || loc?.fleet;
            }
            if ((rem.isChecklistBypassed || loc?.isChecklistBypassed) && (rem.status === 'delivered' || loc?.status === 'delivered')) {
              combined.status = 'delivered';
              combined.isChecklistBypassed = true;
              combined.checklistBypassedBy = rem.checklistBypassedBy || loc?.checklistBypassedBy || 'Super Admin';
              combined.checklistBypassedAt = rem.checklistBypassedAt || loc?.checklistBypassedAt;
            }
            if (loc?.status === 'delivered' && (loc.actualArrival || loc.podPhotoTimestamp || loc.podReceiverName)) {
              combined.status = 'delivered';
              combined.actualArrival = combined.actualArrival || loc.actualArrival;
              combined.podPhotoTimestamp = combined.podPhotoTimestamp || loc.podPhotoTimestamp;
              combined.podReceiverName = combined.podReceiverName || loc.podReceiverName;
              combined.podConditionNote = combined.podConditionNote || loc.podConditionNote;
            }

            mergedSchedules.push(combined);
          }

          // Keep un-synced local schedules created recently, manual schedules, or portal self-checkin schedules
          const nowMs = Date.now();
          let recoveredLocalSchedule = false;
          for (const loc of this.schedules || []) {
            if (loc?.id && !mergedIds.has(loc.id) && !deletedIdsSet.has(String(loc.id)) && !String(loc.id).startsWith('batch-')) {
              const createdMs = loc.createdAt ? new Date(loc.createdAt).getTime() : 0;
              if (String(loc.id).startsWith('PORTAL-') || loc.isManuallyEdited || (createdMs > 0 && nowMs - createdMs < 60000)) {
                mergedSchedules.push(loc);
                recoveredLocalSchedule = true;
              }
            }
          }

          this.schedules = mergedSchedules;
          this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules, true);
          if (recoveredLocalSchedule && schedulePayload?.source !== 'hostinger_mysql') {
            this.persistSchedulesSnapshotToBackend('hydrate_recover');
          }
        }

        this.reconcileFleetAndScheduleStatuses(true);
        this.syncUsersWithCrews();
        this.notify();
        return fleetRes.ok || crewRes.ok || storeRes.ok || scheduleRes.ok;
      } catch (err) {
        console.warn('[Hostinger MySQL] Gagal hydrate data operasional:', err);
        return false;
      } finally {
        this.hydratePromise = null;
      }
    })();
    return this.hydratePromise;
  }

  private resolveLocalCandidateUser(): UserProfile | null {
    const savedSessionUserId =
      (typeof sessionStorage !== 'undefined' ? sessionStorage.getItem(STORAGE_KEYS.AUTH_SESSION) : null) ||
      (typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.AUTH_SESSION) : null);
    const savedCurrentUser = this.loadFromStorage<UserProfile | null>(STORAGE_KEYS.CURRENT_USER, null);
    return (
      (this.currentUser && this.currentUser.id !== 'guest' && this.currentUser.status === 'approved' ? this.currentUser : null) ||
      (savedSessionUserId ? this.users.find(u => u.id === savedSessionUserId && u.status === 'approved') || null : null) ||
      (savedCurrentUser && savedCurrentUser.id !== 'guest' && savedCurrentUser.status === 'approved' ? savedCurrentUser : null)
    );
  }

  public async restoreServerSession(): Promise<boolean> {
    try {
      const savedToken =
        (typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.SESSION_TOKEN) : null) ||
        (typeof sessionStorage !== 'undefined' ? sessionStorage.getItem(STORAGE_KEYS.SESSION_TOKEN) : null) ||
        '';
      // Mulai hydrate paralel hanya bila sudah ada sesi/token lokal agar halaman login tidak mengirim 401 massal
      if (savedToken || this.isAuthenticated()) {
        void this.hydrateOperationalDataFromHostinger();
      }
      const reqHeaders: Record<string, string> = { 'Accept': 'application/json' };
      if (savedToken) {
        reqHeaders['Authorization'] = `Bearer ${savedToken}`;
        reqHeaders['x-akk-session-token'] = savedToken;
      }

      const response = await fetch('/api/auth/me', {
        method: 'GET',
        credentials: 'same-origin',
        headers: reqHeaders
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload?.user?.id) {
        // Jaga agar sesi perangkat lapangan (Android WebView / Mobile Browser) TIDAK keluar sendiri
        // apabila terjadi pergantian jaringan (Wi-Fi ke Data Seluler), drop cookie WebView saat buka kamera, atau server sibuk.
        const candidateUser = this.resolveLocalCandidateUser();
        if (candidateUser) {
          this.setCurrentUser({ ...candidateUser, password: undefined });
          if (this.isPreviewEnvironment()) {
            void this.ensurePreviewServerSession(true).then(() => {
              void this.hydrateOperationalDataFromHostinger(true);
            });
          } else {
            void this.hydrateOperationalDataFromHostinger();
          }
          return true;
        }

        this.currentUser = { ...GUEST_USER_PROFILE };
        try {
          sessionStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
          localStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
          localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
        } catch {}
        this.notify();
        return false;
      }

      if (payload?.sessionToken) {
        try {
          if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEYS.SESSION_TOKEN, String(payload.sessionToken));
          if (typeof sessionStorage !== 'undefined') sessionStorage.setItem(STORAGE_KEYS.SESSION_TOKEN, String(payload.sessionToken));
        } catch {}
      }

      const remote = payload.user;
      const role = (remote.role || 'unassigned') as UserRole;
      const remoteEmail = String(remote.email || '').trim().toLowerCase();
      const existing = this.users.find(u =>
        u.id === remote.id ||
        (remoteEmail && u.email?.toLowerCase() === remoteEmail)
      );
      const rawRemoteName = String(remote.fullName || remote.name || '').trim();
      const resolvedFullName = (remoteEmail === 'hendri123@gmail.com' && (!rawRemoteName || rawRemoteName.toLowerCase() === 'super admin'))
        ? 'Hendri'
        : (rawRemoteName || existing?.fullName || (role === 'super_admin' ? 'Super Admin' : 'Pengguna'));
      const user: UserProfile = {
        ...(existing || {} as UserProfile),
        id: remote.id,
        email: remote.email || existing?.email || '',
        fullName: resolvedFullName,
        role,
        department: remote.department || existing?.department || 'Logistik',
        phone: remote.phone || existing?.phone || '',
        status: remote.status || existing?.status || 'approved',
        createdAt: remote.createdAt || existing?.createdAt || new Date().toISOString(),
        approvedAt: remote.approvedAt || existing?.approvedAt,
        approvedBy: remote.approvedBy || existing?.approvedBy,
        notes: remote.notes ?? existing?.notes,
        permissions: normalizeUserPermissions(
          role,
          (remote.permissions && (remote.permissions.modules || remote.permissions.branchPermissions))
            ? remote.permissions
            : existing?.permissions
        ),
        password: undefined
      } as UserProfile;

      const idx = this.users.findIndex(u =>
        u.id === user.id ||
        (user.email && u.email?.toLowerCase() === user.email.toLowerCase())
      );
      if (idx >= 0) {
        this.users = this.users.map((u, i) => (i === idx ? ({ ...u, ...user, password: undefined } as UserProfile) : u));
      } else {
        this.users = [user, ...this.users];
      }
      this.users = this.deduplicateSuperAdmins(this.users);
      this.saveToStorage(STORAGE_KEYS.USERS, this.users);
      branchStore.hydrateUserBranchPermissionsFromUsers(this.users);
      this.setCurrentUser(user);
      void this.hydrateOperationalDataFromHostinger();
      void this.refreshUsersFromHostinger();
      return true;
    } catch (err) {
      const candidateUser = this.resolveLocalCandidateUser();
      if (candidateUser) {
        this.setCurrentUser({ ...candidateUser, password: undefined });
        return true;
      }
      console.warn('[Hostinger Auth] Restore session gagal:', err);
      this.currentUser = { ...GUEST_USER_PROFILE };
      try {
        sessionStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
        localStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
      } catch {}
      this.notify();
      return false;
    }
  }

  public async registerUserRemote(data: {
    fullName: string;
    email: string;
    phone?: string;
    department?: string;
    password: string;
  }): Promise<UserProfile | null> {
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(data)
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload?.user?.id) return null;
      const remote = payload.user;
      const user: UserProfile = {
        id: remote.id,
        email: remote.email,
        fullName: remote.name || data.fullName,
        role: remote.role || 'unassigned',
        department: remote.department || data.department || 'Logistik',
        phone: remote.phone || data.phone || '',
        status: remote.status || 'pending',
        createdAt: remote.createdAt || new Date().toISOString(),
        permissions: { modules: getDefaultPermissionsForRole((remote.role || 'unassigned') as UserRole) }
      } as UserProfile;
      this.users = [user, ...this.users.filter(u => u.id !== user.id && u.email?.toLowerCase() !== user.email.toLowerCase())];
      this.saveToStorage(STORAGE_KEYS.USERS, this.users);
      this.notify();
      return user;
    } catch (err) {
      console.warn('[Hostinger Auth] Registrasi gagal:', err);
      return null;
    }
  }

  public switchCurrentUser(userId: string) {
    const target = this.users.find(u => u.id === userId);
    if (target) {
      this.currentUser = target;
      try {
        if (typeof sessionStorage !== 'undefined') {
          sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, target.id);
        }
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, target.id);
        }
      } catch {}
      this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
      this.syncCurrentUserToCrew();
      this.notify();
    }
  }

  public setCurrentUser(user: UserProfile) {
    this.currentUser = user;
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem(STORAGE_KEYS.AUTH_SESSION, user.id);
      }
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, user.id);
      }
    } catch {}
    this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    this.syncCurrentUserToCrew();
    this.notify();
  }

  public logoutUser() {
    fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
    this.currentUser = { ...GUEST_USER_PROFILE };
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
        sessionStorage.removeItem(STORAGE_KEYS.SESSION_TOKEN);
      }
      localStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
      localStorage.removeItem(STORAGE_KEYS.SESSION_TOKEN);
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
      localStorage.removeItem('akk_driver_auth_session');
    } catch {}
    this.notify();
  }

  public updateUserFullName(newFullName: string): void {
    if (this.currentUser) {
      this.currentUser.fullName = newFullName;
      const userInList = this.users.find(u => u.id === this.currentUser.id);
      if (userInList) {
        userInList.fullName = newFullName;
      }
      this.saveToStorage(STORAGE_KEYS.USERS, this.users);
      this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
      this.syncCurrentUserToCrew();
      this.notify();
    }
  }

  public async resetUserPassword(userId: string, newPassword: string): Promise<boolean> {
    const userIndex = this.users.findIndex(u => u.id === userId);
    if (userIndex === -1 || newPassword.length < 8) return false;

    try {
      const response = await fetch(`/api/users/${encodeURIComponent(userId)}/password`, {
        method: 'POST',
        headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
        credentials: 'same-origin',
        body: JSON.stringify({ password: newPassword })
      });
      if (!response.ok) return false;

      // Never persist plaintext passwords in browser storage. Password hashing happens on the server.
      this.users[userIndex] = { ...this.users[userIndex], password: undefined } as UserProfile;
      this.saveToStorage(STORAGE_KEYS.USERS, this.users);
      this.logActivity('Reset Password', this.users[userIndex].fullName, 'Password direset oleh Super Admin melalui backend Hostinger');
      this.notify();
      return true;
    } catch (err) {
      console.warn('[Hostinger Users] Reset password gagal:', err);
      return false;
    }
  }

  public getPortalDisplayName(): string {
    if (!this.currentUser) return 'Driver Operasional';
    if (this.currentUser.role === 'super_admin') {
      return this.currentUser.fullName || 'Super Admin';
    }
    return this.currentUser.fullName || this.currentUser.email || 'Pengguna AKK';
  }

  /**
   * Memastikan sinkronisasi dua arah real-time antara profil pengguna aktif dan identitas supir/portal:
   * 1. Menjaga 'displayName' portal selalu sama persis dengan 'fullName' pengguna.
   * 2. Menyelaraskan daftar kru (`this.crews`) agar supir aktif memiliki nama yang identik dengan profil pengguna.
   * 3. Menyimpan sesi supir lokal (`akk_driver_auth_session`) secara konsisten.
   */
  public syncPortalDisplayName(fullName?: string): string {
    const targetName = (fullName || this.currentUser?.fullName || '').trim();
    if (!targetName) return this.getPortalDisplayName();

    if (this.currentUser && this.currentUser.fullName !== targetName) {
      this.currentUser.fullName = targetName;
      const userInList = this.users.find(u => u.id === this.currentUser.id);
      if (userInList) {
        userInList.fullName = targetName;
      }
      this.saveToStorage(STORAGE_KEYS.USERS, this.users);
      this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    }

    this.syncCurrentUserToCrew();
    this.notify();
    return this.getPortalDisplayName();
  }

  /**
   * Helper utama untuk menyelaraskan currentUser dengan Crew dan session storage supir
   */
  public syncCurrentUserToCrew(): Crew {
    if (!this.crews || this.crews.length === 0) {
      this.crews = this.computeSyncedCrews();
    }
    const user = this.getCurrentUser();
    const cleanUserName = (user?.fullName || '').trim();
    const lowerName = cleanUserName.toLowerCase();
    const isCrewRole = user?.role === 'driver' || user?.role === 'crew_helper';

    // Jika user yang login BUKAN driver atau helper (misal: Super Admin, SPV Logistik, dll.),
    // JANGAN membuat entri Crew baru atas nama Super Admin agar tidak mengotori daftar Kru Supir/Helper!
    if (!isCrewRole) {
      return this.crews[0];
    }

    const expectedCrewId = `crw-${user?.id || 'usr'}`;

    // 1. Cari kru yang cocok berdasarkan ID atau kata nama lengkap (mencegah 'Budi' menimpa 'Budiono')
    // Account ID is the primary identity. Only use an exact full-name match if the
    // account-linked crew record does not exist.
    const normalizeIdentityName = (value: string) => value
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '');
    let matchedCrew = this.crews.find(c => c.id === expectedCrewId) ||
      this.crews.find(c => normalizeIdentityName(c.name || '') === normalizeIdentityName(cleanUserName));

    if (matchedCrew) {
      let changed = false;
      if (cleanUserName && matchedCrew.name !== cleanUserName) {
        matchedCrew.name = cleanUserName;
        changed = true;
      }
      if (changed) {
        try {
          safeSetItem(STORAGE_KEYS.CREWS, JSON.stringify(this.crews));
        } catch {}
      }
    } else {
      matchedCrew = {
        id: expectedCrewId,
        name: cleanUserName || 'Driver Operasional',
        phone: user?.phone && user.phone !== '-' ? user.phone : '',
        role: user?.role === 'crew_helper' ? 'Kernet / Helper' : 'Driver Utama',
        licenseNumber: '',
        licenseType: user?.role === 'crew_helper' ? 'SIM A' : 'SIM B1 Umum',
        status: 'available',
        currentFleetId: undefined,
        tripsCompleted: 0,
        rating: 0,
        certifications: [],
        routeExperience: []
      };
      const existingIdx = this.crews.findIndex(c => c.id === expectedCrewId);
      if (existingIdx !== -1) {
        this.crews[existingIdx] = matchedCrew;
      } else {
        this.crews.push(matchedCrew);
      }
      try {
        if (typeof localStorage !== 'undefined') localStorage.removeItem(STORAGE_KEYS.CREWS);
      } catch {}
    }

    try {
      if (typeof localStorage !== 'undefined') localStorage.removeItem('akk_driver_auth_session');
    } catch {}

    return matchedCrew;
  }

  public getActiveDriverCrew(): Crew | null {
    return this.syncCurrentUserToCrew();
  }

  // Actions
  public setCurrentRole(role: UserRole) {
    const profile = this.users.find(p => p.role === role && p.status === 'approved') || {
      ...this.currentUser,
      role
    };
    this.currentUser = profile;
    this.saveToStorage(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    this.notify();
  }

  public setSchedules(schedules: Schedule[]): void {
    this.schedules = [...schedules];
    this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
    this.syncSchedulesToCrewHistory(this.schedules);
    this.notify();
  }

  private canCurrentUserEditModule(moduleId: string, subMenuId?: string): boolean {
    const u = this.getCurrentUser();
    if (!u || u.id === 'guest' || u.id === 'usr-guest') return true;
    return canEdit(u, moduleId, subMenuId);
  }

  public addSchedule(schedule: Omit<Schedule, 'id' | 'createdAt'>): Schedule {
    if (!this.canCurrentUserEditModule('schedules')) {
      console.warn('[RBAC Guard] Aksi addSchedule ditolak: Akun memiliki akses Hanya Lihat (Read Only) pada Jadwal & Penugasan Armada.');
      return {
        ...schedule,
        id: 'sch-readonly-blocked',
        createdAt: new Date().toISOString()
      } as Schedule;
    }
    const areaName = resolveScheduleAreaName(schedule);
    const isBali = schedule.isInterIsland || areaName.toUpperCase().includes('BALI') || areaName.toUpperCase().includes('DENPASAR') || areaName.toUpperCase().includes('SINGARAJA') || areaName.toUpperCase().includes('NEGARA');

    const depMatch = (schedule.departureDate || '').match(/T(\d{2}:\d{2})/);
    const arrMatch = (schedule.estimatedArrival || '').match(/T(\d{2}:\d{2})/);
    const resolvedDeliveryWindow =
      schedule.store?.deliveryWindow && schedule.store.deliveryWindow !== '08:00 - 17:00'
        ? schedule.store.deliveryWindow
        : depMatch && arrMatch
        ? `${depMatch[1]} - ${arrMatch[1]}`
        : schedule.store?.deliveryWindow || '07:30 - 17:00';

    const areaStore: RetailStore = {
      id: schedule.storeId && !schedule.storeId.startsWith('str-fix-') ? schedule.storeId : `area-${areaName.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
      storeCode: `AREA-${areaName.substring(0, 4).toUpperCase().replace(/[^A-Z0-9]/g, '')}`,
      storeName: areaName,
      island: isBali ? 'Bali & Nusa Tenggara' : 'Jawa',
      province: isBali ? 'Bali' : 'Jawa Timur',
      city: isBali ? 'Denpasar' : (areaName.toUpperCase().includes('JEMBER') ? 'Jember' : (areaName.toUpperCase().includes('SITUBONDO') ? 'Situbondo' : (areaName.toUpperCase().includes('BONDOWOSO') ? 'Bondowoso' : 'Banyuwangi'))),
      address: `Area Pengiriman Distribusi ${areaName}`,
      latitude: isBali ? -8.6705 : -8.219,
      longitude: isBali ? 115.2126 : 114.369,
      contactPerson: 'PIC Distribusi Area',
      phone: '-',
      deliveryWindow: resolvedDeliveryWindow,
      storeCategory: 'Distribution Hub'
    };

    const customId = (schedule as any).id;
    const nowIso = new Date().toISOString();
    const resolvedFleet =
      this.findFleetByCodeOrPlate(
        schedule.armada || schedule.fleet?.initialCode || schedule.fleet?.plateNumber || schedule.fleetId
      ) ||
      schedule.fleet ||
      this.fleets.find(f => f.id === schedule.fleetId);

    const resolvedCrew = this.crews.find(c => c.id === schedule.crewId) || schedule.crew;
    const resolvedHelper = schedule.crewHelperId
      ? (this.crews.find(c => c.id === schedule.crewHelperId) || schedule.crewHelper)
      : schedule.crewHelper;
    const resolvedHelper2 = schedule.crewHelper2Id
      ? (this.crews.find(c => c.id === schedule.crewHelper2Id) || schedule.crewHelper2)
      : schedule.crewHelper2;

    const hydratedNewSchedule: Schedule = {
      ...schedule,
      id: customId && typeof customId === 'string' && customId.trim() ? customId.trim() : 'sch-' + Math.random().toString(36).substring(2, 9),
      areaName,
      store: areaStore,
      fleetId: resolvedFleet?.id || schedule.fleetId || 'flt-01',
      fleet: resolvedFleet,
      armada: schedule.armada || resolvedFleet?.initialCode || resolvedFleet?.plateNumber,
      crew: resolvedCrew,
      crewHelper: resolvedHelper,
      crewHelper2: resolvedHelper2,
      createdAt: nowIso,
      updatedAt: nowIso
    };

    // Status armada berubah menjadi 'on-duty' (Kirim) hanya saat sudah Gate-Out ('in_transit' / 'picked_up')
    if (hydratedNewSchedule.status === 'in_transit' || hydratedNewSchedule.status === 'picked_up') {
      this.updateFleetStatus(hydratedNewSchedule.fleetId, 'on-duty', hydratedNewSchedule.cargoWeightTon);
      this.updateCrewStatus(hydratedNewSchedule.crewId, 'on-duty');
    }

    this.schedules = [hydratedNewSchedule, ...this.schedules.filter(s => s.id !== hydratedNewSchedule.id)];
    this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
    this.syncSchedulesToCrewHistory(this.schedules);

    const isAutoGenerated = String(hydratedNewSchedule.notes || '').includes('Jadwal: Berangkat') && String(hydratedNewSchedule.trackingNumber || '').startsWith('PO-AKK-');
    if (!isAutoGenerated) {
      const fleetLabel = hydratedNewSchedule.fleet?.plateNumber || hydratedNewSchedule.armada || '-';
      const driverLabel = hydratedNewSchedule.crew?.name || '-';
      this.logActivity(
        'Tambah Jadwal Pengiriman',
        `Area ${areaName} (${fleetLabel})`,
        `Menambahkan jadwal pengiriman area ${areaName} • Armada: ${fleetLabel} • Driver: ${driverLabel}`,
        'tambah'
      );
    }

    // Trigger auto-write middleware
    this.dispatchMiddleware({
      entityType: 'schedule',
      action: 'create',
      id: hydratedNewSchedule.id,
      data: hydratedNewSchedule,
      timestamp: nowIso
    });

    // Publish real-time assignment notification via Supabase Realtime (filtered to assigned driver)
    try {
      supabaseRealtimeSync.publishScheduleChange('INSERT', hydratedNewSchedule, null).catch(() => {});
    } catch {}

    this.persistSchedulesSnapshotToBackend('add_schedule');

    return hydratedNewSchedule;
  }

  private persistSchedulesTimer: any = null;
  private pendingDeletedScheduleIds: Set<string> = new Set();

  private persistSchedulesSnapshotToBackend(source: string = 'store_sync', deletedIds: string[] = [], replaceAll: boolean = false) {
    if (typeof fetch === 'undefined') return;
    deletedIds.forEach(id => {
      if (id) this.pendingDeletedScheduleIds.add(String(id));
    });
    if (this.persistSchedulesTimer) {
      clearTimeout(this.persistSchedulesTimer);
    }
    this.persistSchedulesTimer = setTimeout(async () => {
      this.persistSchedulesTimer = null;
      const batchDeletedIds = Array.from(this.pendingDeletedScheduleIds);
      this.pendingDeletedScheduleIds.clear();
      const bodyStr = JSON.stringify({
        schedules: this.schedules,
        deletedIds: batchDeletedIds,
        replaceAll,
        source
      });
      try {
        if (this.isPreviewEnvironment()) {
          await this.ensurePreviewServerSession(false);
        }
        let res = await fetch('/api/schedules/persist', {
          method: 'POST',
          headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
          credentials: 'same-origin',
          body: bodyStr
        });
        if (res.status === 401 && this.isPreviewEnvironment()) {
          const recovered = await this.ensurePreviewServerSession(true);
          if (recovered) {
            res = await fetch('/api/schedules/persist', {
              method: 'POST',
              headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
              credentials: 'same-origin',
              body: bodyStr
            });
          }
        }
        if (res.ok && typeof window !== 'undefined') {
          window.dispatchEvent(new Event('akk-portal-schedule-updated'));
        }
      } catch {}
    }, 180);
  }

  public updateSchedule(id: string, updatedSchedule: Partial<Omit<Schedule, 'id' | 'createdAt'>>) {
    const u = this.getCurrentUser();
    const isCrewOrPortalUpdate =
      Boolean(
        u &&
          [
            'driver',
            'crew_helper',
            'warehouse_admin',
            'koordinator_gudang',
            'spv_logistik',
            'koordinator_driver',
            'super_admin',
            'operasional',
            'dispatcher'
          ].includes(u.role)
      ) ||
      updatedSchedule.backupCrewName !== undefined ||
      updatedSchedule.backupPosition !== undefined ||
      updatedSchedule.backupTargetName !== undefined ||
      updatedSchedule.isManuallyEdited === true;

    if (!isCrewOrPortalUpdate && !this.canCurrentUserEditModule('schedules')) {
      console.warn('[RBAC Guard] Aksi updateSchedule ditolak: Akun memiliki akses Hanya Lihat (Read Only) pada Jadwal & Penugasan Armada.');
      return;
    }
    let oldSch: Schedule | null = null;
    let newSch: Schedule | null = null;
    const nowIso = new Date().toISOString();

    this.schedules = this.schedules.map(sch => {
      if (sch.id === id) {
        oldSch = sch;
        const merged = { ...sch, ...updatedSchedule, updatedAt: nowIso };
        const resolvedFleet =
          (updatedSchedule.armada || updatedSchedule.fleet || updatedSchedule.fleetId
            ? this.findFleetByCodeOrPlate(
                updatedSchedule.armada ||
                  updatedSchedule.fleet?.initialCode ||
                  updatedSchedule.fleet?.plateNumber ||
                  updatedSchedule.fleetId
              )
            : undefined) ||
          merged.fleet ||
          this.fleets.find(f => f.id === merged.fleetId);

        // Prefer an explicitly supplied crew snapshot when it belongs to the selected ID.
        // This prevents a stale cached crew object from silently replacing a newly selected
        // account (for example, Nur Hadi) with a similarly named legacy crew.
        const explicitCrew = updatedSchedule.crew &&
          (!updatedSchedule.crewId || updatedSchedule.crew.id === updatedSchedule.crewId)
          ? updatedSchedule.crew
          : undefined;
        const explicitHelper = updatedSchedule.crewHelper &&
          (!updatedSchedule.crewHelperId || updatedSchedule.crewHelper.id === updatedSchedule.crewHelperId)
          ? updatedSchedule.crewHelper
          : undefined;
        const explicitHelper2 = updatedSchedule.crewHelper2 &&
          (!updatedSchedule.crewHelper2Id || updatedSchedule.crewHelper2.id === updatedSchedule.crewHelper2Id)
          ? updatedSchedule.crewHelper2
          : undefined;
        const hydrated: Schedule = {
          ...merged,
          fleetId: resolvedFleet?.id || merged.fleetId,
          fleet: resolvedFleet,
          armada: updatedSchedule.armada || resolvedFleet?.initialCode || merged.armada || resolvedFleet?.plateNumber,
          crew: explicitCrew || this.crews.find(c => c.id === merged.crewId) || merged.crew,
          crewHelper: merged.crewHelperId ? (explicitHelper || this.crews.find(c => c.id === merged.crewHelperId) || merged.crewHelper) : undefined,
          crewHelper2: merged.crewHelper2Id ? (explicitHelper2 || this.crews.find(c => c.id === merged.crewHelper2Id) || merged.crewHelper2) : undefined
        };
        newSch = hydrated;
        const isAutoRebalance = String(updatedSchedule.notes || '').includes('[Auto-Rebalanced:');
        if (!isAutoRebalance) {
          const areaLabel = hydrated.areaName || hydrated.store?.storeName || sch.trackingNumber || 'Rute Pengiriman';
          const plateLabel = hydrated.fleet?.plateNumber || hydrated.armada || '-';
          const driverLabel = hydrated.crew?.name || '-';
          const helperLabel = hydrated.crewHelper?.name ? `, Helper: ${hydrated.crewHelper.name}` : '';
          this.logActivity(
            'Ubah Data Jadwal Pengiriman',
            `Area ${areaLabel} (${plateLabel})`,
            `Merubah data jadwal area ${areaLabel} • Armada: ${plateLabel} • Driver: ${driverLabel}${helperLabel}`,
            'ubah'
          );
        }
        return hydrated;
      }
      return sch;
    });
    this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
    this.syncSchedulesToCrewHistory(this.schedules);

    if (newSch) {
      this.dispatchMiddleware({
        entityType: 'schedule',
        action: 'update',
        id,
        data: newSch,
        previousData: oldSch || undefined,
        timestamp: nowIso
      });

      try {
        supabaseRealtimeSync.publishScheduleChange('UPDATE', newSch, oldSch).catch(() => {});
      } catch {}
    }

    this.persistSchedulesSnapshotToBackend('update_schedule');
    this.notify();
  }

  public updateScheduleOdometer(id: string, kmStart?: number, kmEnd?: number): boolean {
    const target = this.schedules.find(s => s.id === id);
    if (!target) return false;
    const patch: Partial<Omit<Schedule, 'id' | 'createdAt'>> = {
      isManuallyEdited: true
    };
    if (kmStart !== undefined && Number.isFinite(kmStart) && kmStart > 0) {
      patch.crewOdometerStart = String(Math.round(kmStart));
    }
    if (kmEnd !== undefined && Number.isFinite(kmEnd) && kmEnd > 0) {
      patch.crewOdometerEnd = String(Math.round(kmEnd));
      patch.crewOdometerEndAt = new Date().toISOString();
    } else if (kmEnd === undefined) {
      patch.crewOdometerEnd = undefined;
      patch.crewOdometerEndAt = undefined;
    }
    this.updateSchedule(id, patch);
    return true;
  }

  public deleteSchedule(id: string) {
    const u = this.getCurrentUser();
    const isSuperOrAdmin = !u || u.role === 'super_admin' || (u.role as string) === 'admin_penjualan' || (u.role as string) === 'admin_nusantara' || (u.role as string) === 'admin_sidoarjo';
    if (!isSuperOrAdmin && !this.canCurrentUserEditModule('schedules')) {
      console.warn('[RBAC Guard] Aksi deleteSchedule ditolak: Akun memiliki akses Hanya Lihat (Read Only) pada Jadwal & Penugasan Armada.');
      return;
    }
    const target = this.schedules.find(sch => sch.id === id || sch.id === String(id));
    this.schedules = this.schedules.filter(sch => sch.id !== id && sch.id !== String(id));
    this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
    this.syncSchedulesToCrewHistory(this.schedules);
    this.reconcileFleetAndScheduleStatuses(true);

    if (target) {
      const areaLabel = target.areaName || target.store?.storeName || target.trackingNumber || id;
      const plateLabel = target.fleet?.plateNumber || target.armada || '-';
      this.logActivity(
        'Hapus Data Jadwal Pengiriman',
        `Area ${areaLabel} (${plateLabel})`,
        `Menghapus jadwal pengiriman area ${areaLabel} • Armada: ${plateLabel} • Driver: ${target.crew?.name || '-'}`,
        'kurangi'
      );
    }

    this.dispatchMiddleware({
      entityType: 'schedule',
      action: 'delete',
      id,
      data: target || { id },
      timestamp: new Date().toISOString()
    });

    this.persistSchedulesSnapshotToBackend('delete_schedule', [String(id)]);
    this.notify();
  }

  public clearAllSchedules() {
    const allIds = this.schedules.map(s => String(s.id)).filter(Boolean);
    if (allIds.length > 0) {
      this.logActivity(
        'Hapus Semua Jadwal Pengiriman',
        'Jadwal & Penugasan Armada',
        `Menghapus / mengurangi ${allIds.length} data jadwal pengiriman`,
        'kurangi'
      );
    }
    this.schedules = [];
    this.saveToStorage(STORAGE_KEYS.SCHEDULES, []);
    this.reconcileFleetAndScheduleStatuses(true);
    try {
      localStorage.removeItem('akk_driver_cached_deliveries_v2');
    } catch {}
    this.persistSchedulesSnapshotToBackend('clear_all', allIds, true);
    this.notify();
  }

  /**
   * Batch add or update multiple schedules efficiently without thread locking or UI freeze.
   * On Google Sheets import, replaces old unedited schedules for the target month with fresh validated data.
   */
  public batchSyncSchedules(
    itemsToAdd: Schedule[],
    itemsToUpdate: { id: string; data: Partial<Schedule> }[] = [],
    options: { isImport?: boolean; replaceMonth?: boolean; skipBackendPersist?: boolean } = {}
  ): { addedCount: number; updatedCount: number } {
    // On import or explicit replace request, purge old unedited schedules for the affected month(s)
    if (options.isImport || options.replaceMonth) {
      const datesToReplace = new Set<string>();
      [...itemsToAdd, ...itemsToUpdate.map(u => u.data as Schedule)].forEach(item => {
        if (item && item.departureDate) {
          const d = new Date(item.departureDate);
          if (!isNaN(d.getTime())) {
            const monthKey = `${d.getFullYear()}-${d.getMonth()}`;
            datesToReplace.add(monthKey);
          }
        }
      });

      if (datesToReplace.size > 0) {
        this.schedules = this.schedules.filter(sch => {
          if (sch.isManuallyEdited) return true; // Preserve user's manual edits
          if (!sch.departureDate) return false;
          const d = new Date(sch.departureDate);
          if (isNaN(d.getTime())) return false;
          const monthKey = `${d.getFullYear()}-${d.getMonth()}`;
          return !datesToReplace.has(monthKey);
        });
      }
    }

    const sanitizeScheduleItem = (sch: Schedule): Schedule => {
      const depIso = String(sch?.departureDate || '').slice(0, 10);
      const resolvedFleet =
        this.findFleetByCodeOrPlate(
          sch.armada || sch.fleet?.initialCode || sch.fleet?.plateNumber || sch.fleetId
        ) || sch.fleet;
      const base: Schedule = {
        ...sch,
        fleetId: resolvedFleet?.id || sch.fleetId || 'flt-01',
        fleet: resolvedFleet,
        armada: sch.armada || resolvedFleet?.initialCode || resolvedFleet?.plateNumber
      };
      if (depIso >= '2026-11-12' && base.status === 'delivered' && !base.podPhotoUrl && !base.isChecklistBypassed) {
        return {
          ...base,
          status: 'scheduled',
          isChecklistBypassed: false,
          actualArrival: undefined
        };
      }
      return base;
    };

    const updateMap = new Map<string, Partial<Schedule>>();
    itemsToUpdate.forEach(u => updateMap.set(u.id, u.data));
    const addByIdMap = new Map<string, Schedule>();
    const importFleetDateKeys = new Set<string>();

    if (options.isImport) {
      this.schedules.forEach(sch => {
        if (sch.status === 'delivered' || String(sch.status) === 'cancelled') return;
        const calIso = this.getScheduleCalendarIso(sch);
        const fKey = (sch.fleetId || sch.armada || '').trim().toUpperCase();
        if (fKey && calIso) importFleetDateKeys.add(`${fKey}__${calIso}`);
      });
    }

    itemsToAdd.forEach(item => {
      if (item?.id && !String(item.id).startsWith('batch-')) {
        const sanitized = sanitizeScheduleItem(item);
        if (options.isImport && sanitized.status !== 'delivered' && String(sanitized.status) !== 'cancelled') {
          const calIso = this.getScheduleCalendarIso(sanitized);
          const fKey = (sanitized.fleetId || sanitized.armada || '').trim().toUpperCase();
          if (fKey && calIso) {
            const composite = `${fKey}__${calIso}`;
            if (importFleetDateKeys.has(composite)) {
              return;
            }
            importFleetDateKeys.add(composite);
          }
        }
        addByIdMap.set(item.id, sanitized);
      }
    });

    // 1. In-memory update existing items (from itemsToUpdate or matching IDs in itemsToAdd)
    let updatedExistingCount = 0;
    this.schedules = this.schedules.map(sch => {
      if (updateMap.has(sch.id)) {
        updatedExistingCount++;
        return sanitizeScheduleItem({ ...sch, ...updateMap.get(sch.id)! });
      }
      if (addByIdMap.has(sch.id)) {
        updatedExistingCount++;
        return sanitizeScheduleItem({ ...sch, ...addByIdMap.get(sch.id)! });
      }
      return sanitizeScheduleItem(sch);
    });

    // 2. In-memory prepend new items (deduplicated by ID)
    const existingIdSet = new Set(this.schedules.map(s => s.id));
    const cleanNewItems = Array.from(addByIdMap.values()).filter(item => !existingIdSet.has(item.id));
    this.schedules = [...cleanNewItems, ...this.schedules];

    // 3. Single disk save
    this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);

    // 4. Single crew history recalculation
    this.syncSchedulesToCrewHistory(this.schedules);

    // 5. Persist via debounced snapshot endpoint unless caller handles persistence directly
    if (!options.skipBackendPersist) {
      this.persistSchedulesSnapshotToBackend(options.isImport ? 'google_sheets_sync' : 'batch_sync');
    }

    this.notify();
    return { addedCount: cleanNewItems.length, updatedCount: updatedExistingCount };
  }

  /**
   * Mengambil data minggu jadwal admin Sheet ALL dari memori/server Hostinger MySQL (tanpa localStorage)
   */
  public getAdminScheduleWeeks(year: number, month: number): any[] | null {
    const effectiveMonth = month === -1 ? 0 : month;
    const cacheKey = `${year}_${effectiveMonth}`;
    const saved = this.adminScheduleWeeksCache[cacheKey];
    if (Array.isArray(saved) && saved.length > 0 && saved[0]?.days?.length > 0) {
      return saved;
    }
    return null;
  }

  public getAllCachedAdminScheduleWeeks(): any[] {
    if (this.lastAdminScheduleWeeksList.length > 0) {
      return this.lastAdminScheduleWeeksList;
    }
    const all: any[] = [];
    Object.values(this.adminScheduleWeeksCache).forEach((arr) => {
      if (Array.isArray(arr)) all.push(...arr);
    });
    return all;
  }

  /**
   * Menyimpan data minggu jadwal admin ke memori & Hostinger MySQL (tanpa localStorage)
   */
  public saveAdminScheduleWeeks(year: number, month: number, weeks: any[]) {
    const effectiveMonth = month === -1 ? 0 : month;
    const cacheKey = `${year}_${effectiveMonth}`;
    this.adminScheduleWeeksCache[cacheKey] = weeks;
    this.lastAdminScheduleWeeksList = weeks;
    this.notify();
  }

  /**
   * Upload or attach image (Proof of delivery, manifest, photo) with automatic middleware dispatch
   */
  public attachImageToSchedule(scheduleId: string, imageUrl: string, imageType: string = 'proof_of_delivery', notes?: string) {
    this.dispatchMiddleware({
      entityType: 'image',
      action: 'upload',
      id: scheduleId,
      data: {
        scheduleId,
        url: imageUrl,
        type: imageType,
        notes,
        timestamp: new Date().toISOString()
      },
      timestamp: new Date().toISOString()
    });
    this.logActivity('Unggah Gambar / Dokumen', scheduleId, `Unggah ${imageType} pada jadwal ${scheduleId}`);
    this.notify();
  }

  public updateScheduleStatus(
    id: string,
    status: Schedule['status'],
    extraNotes?: string,
    podData?: {
      podPhotoUrl?: string;
      podReceiverName?: string;
      podConditionNote?: string;
      podPhotoTimestamp?: string;
    },
    postTripFleetStatus?: Fleet['status']
  ) {
    let deliveredSchedule: Schedule | null = null;
    let targetSch: Schedule | null = null;
    const nowIso = new Date().toISOString();

    this.schedules = this.schedules.map(sch => {
      if (sch.id === id) {
        targetSch = sch;
        const updatedNotes = extraNotes 
          ? (sch.notes ? `${sch.notes} [${new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}: ${extraNotes}]` : extraNotes)
          : sch.notes;
        const updated: Schedule = {
          ...sch,
          status,
          notes: updatedNotes,
          updatedAt: nowIso,
          ...(status === 'in_transit' && !sch.actualDeparture ? { actualDeparture: nowIso } : {}),
          ...(podData?.podPhotoUrl ? { podPhotoUrl: podData.podPhotoUrl } : {}),
          ...(podData?.podPhotoTimestamp ? { podPhotoTimestamp: podData.podPhotoTimestamp } : {}),
          ...(podData?.podReceiverName ? { podReceiverName: podData.podReceiverName } : {}),
          ...(podData?.podConditionNote ? { podConditionNote: podData.podConditionNote } : {}),
        };
        const targetFleetKey = sch.fleetId || sch.armada || sch.fleet?.plateNumber || '';
        if (status === 'delivered') {
          updated.actualArrival = nowIso;
          deliveredSchedule = updated;
          this.logActivity('Update Status', 'Pengiriman', `Status ${sch.trackingNumber} menjadi delivered`);
          if (podData?.podPhotoUrl) {
            this.attachImageToSchedule(sch.id, podData.podPhotoUrl, 'proof_of_delivery', `POD Penerima: ${podData.podReceiverName || 'PIC'}`);
          }
          // Ketika driver/helper klik sudah berada di gudang, status armada otomatis berubah menjadi Ready ('available') atau Servis ('maintenance')
          const resolvedPostStatus: Fleet['status'] = postTripFleetStatus || 'available';
          if (targetFleetKey) {
            this.updateFleetStatus(targetFleetKey, resolvedPostStatus, 0);
          }
          this.updateCrewStatus(sch.crewId, 'available');
          const fltDelivered = this.fleets.find(f => f.id === sch.fleetId || f.plateNumber === sch.fleet?.plateNumber);
          const crwDelivered = this.crews.find(c => c.id === sch.crewId);
          const alreadyGateIn = this.securityLogs.some(l => l.scheduleId === sch.id && l.status === 'Tiba di Gudang');
          if (!alreadyGateIn) {
            this.recordGateIn(
              sch.id,
              fltDelivered?.plateNumber || sch.trackingNumber,
              crwDelivered?.name || 'Driver AKK',
              'Armada Selesai Pengantaran & Tiba Kembali di Gudang DC',
              fltDelivered?.initialCode
            );
          }
        } else if (status === 'picked_up' || status === 'in_transit') {
          // Ketika driver/helper klik Gate-Out, status armada otomatis berubah menjadi Kirim ('on-duty')
          if (targetFleetKey) {
            this.updateFleetStatus(targetFleetKey, 'on-duty');
          }
          this.updateCrewStatus(sch.crewId, 'on-duty');
          this.logActivity('Update Status Driver', 'Pengiriman', `Status ${sch.trackingNumber} menjadi ${status}`);
          if (status === 'in_transit') {
            const flt = this.fleets.find(f => f.id === sch.fleetId || f.plateNumber === sch.fleet?.plateNumber);
            const crw = this.crews.find(c => c.id === sch.crewId);
            const store = this.stores.find(s => s.id === sch.storeId);
            const alreadyLogged = this.securityLogs.some(l => l.scheduleId === sch.id && l.status === 'Gate-Out');
            if (!alreadyLogged) {
              this.recordGateOut(
                sch.id,
                flt?.plateNumber || sch.trackingNumber,
                crw?.name || 'Driver AKK',
                sch.areaName || store?.storeName || 'Area Distribusi',
                flt?.initialCode
              );
            }
          }
        } else if (status === 'delayed') {
          this.logActivity('Kendala Pengiriman Driver', 'Pengiriman', `Status ${sch.trackingNumber} delayed: ${extraNotes || 'Tertunda'}`);
        }
        return updated;
      }
      return sch;
    });
    this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
    this.persistSchedulesSnapshotToBackend('update_schedule_status');

    if (targetSch) {
      const sch = targetSch as Schedule;
      const hydratedStatusSch: Schedule = {
        ...sch,
        status,
        fleet: this.fleets.find(f => f.id === sch.fleetId) || sch.fleet,
        crew: this.crews.find(c => c.id === sch.crewId) || sch.crew,
        crewHelper: sch.crewHelperId ? (this.crews.find(c => c.id === sch.crewHelperId) || sch.crewHelper) : undefined,
        crewHelper2: sch.crewHelper2Id ? (this.crews.find(c => c.id === sch.crewHelper2Id) || sch.crewHelper2) : undefined
      };

      try {
        supabaseRealtimeSync.publishScheduleChange('UPDATE', hydratedStatusSch, sch).catch(() => {});
        supabaseRealtimeSync.publishScheduleStatusChange(hydratedStatusSch, sch.status, extraNotes).catch(() => {});
      } catch {}

      const updateItem: OfflineScheduleStatusUpdate = {
        id: 'off-upd-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
        scheduleId: sch.id,
        trackingNumber: sch.trackingNumber,
        status,
        extraNotes,
        podData,
        timestamp: new Date().toISOString()
      };

      if (typeof navigator !== 'undefined' && navigator.onLine) {
        this.syncSingleUpdateToSupabase(updateItem).then(success => {
          if (!success) {
            this.pushToOfflineQueue(updateItem);
          }
        }).catch(() => {
          this.pushToOfflineQueue(updateItem);
        });
      } else {
        this.pushToOfflineQueue(updateItem);
      }
    }

    // Record delivery in crew history
    if (deliveredSchedule) {
      const sch = deliveredSchedule as Schedule;
      const store = this.stores.find(s => s.id === sch.storeId);
      const crew = this.crews.find(c => c.id === sch.crewId);
      const fleet = this.fleets.find(f => f.id === sch.fleetId);

      if (crew && store) {
        const areaName = `${store.island} (${store.city})`;
        const areaStats = this.checkCrewAreaThreshold(crew.id, areaName);

        const newHistoryItem: CrewDeliveryHistory = {
          id: 'cdh-' + Math.random().toString(36).substring(2, 9),
          crewId: crew.id,
          crewName: crew.name,
          scheduleId: sch.id,
          trackingNumber: sch.trackingNumber,
          storeName: store.storeName,
          area: areaName,
          city: store.city,
          island: store.island,
          vehiclePlate: fleet?.plateNumber || '-',
          vehicleType: fleet?.vehicleType || 'Pick Up Box',
          cargoWeightTon: sch.cargoWeightTon,
          cargoDescription: sch.cargoDescription,
          completionDate: new Date().toISOString(),
          status: 'delivered',
          onTimeStatus: 'Tepat Waktu',
          ratingReceived: 5.0,
          podPhotoUrl: sch.podPhotoUrl,
          podReceiverName: sch.podReceiverName,
          areaTripSequenceNumber: areaStats.tripCount + 1,
          requiresAreaApproval: (areaStats.tripCount + 1) >= this.areaThreshold,
          areaApprovalStatus: (areaStats.tripCount + 1) >= this.areaThreshold ? 'approved' : 'not_required'
        };

        this.crewHistory = [newHistoryItem, ...this.crewHistory];
        this.saveToStorage(STORAGE_KEYS.CREW_HISTORY, this.crewHistory);

        // Increment trips completed on crew
        this.crews = this.crews.map(c => c.id === crew.id ? { ...c, tripsCompleted: c.tripsCompleted + 1 } : c);
        this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);
      }
    }

    this.dispatchMiddleware({
      entityType: 'schedule',
      action: 'status_change',
      id,
      data: { id, status, actualArrival: status === 'delivered' ? new Date().toISOString() : undefined },
      timestamp: new Date().toISOString()
    });

    this.notify();
  }

  private pushToOfflineQueue(item: OfflineScheduleStatusUpdate) {
    const existingIdx = this.offlineScheduleQueue.findIndex(q => q.scheduleId === item.scheduleId);
    if (existingIdx >= 0) {
      this.offlineScheduleQueue[existingIdx] = item;
    } else {
      this.offlineScheduleQueue.push(item);
    }
    this.saveToStorage('akk_offline_sync_queue', this.offlineScheduleQueue);
  }

  private async syncSingleUpdateToSupabase(item: OfflineScheduleStatusUpdate): Promise<boolean> {
    // Legacy method name retained for compatibility; persistence now targets Hostinger MySQL.
    try {
      const notes = item.extraNotes && item.extraNotes.trim()
        ? item.extraNotes.trim()
        : item.podData?.podReceiverName
          ? `Diterima: ${item.podData.podReceiverName} (${item.podData.podConditionNote || 'Kondisi Baik'})${item.podData.podPhotoUrl ? ' [Bukti Foto POD OK]' : ''}`
          : undefined;
      const response = await fetch(`/api/schedules/${encodeURIComponent(item.scheduleId)}/status`, {
        method: 'PATCH',
        headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
        credentials: 'same-origin',
        body: JSON.stringify({
          status: item.status,
          notes,
          trackingNumber: item.trackingNumber,
          actualArrival: item.status === 'delivered' ? new Date().toISOString() : undefined
        })
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  public async syncOfflineQueueToSupabase(): Promise<{ synced: number; remaining: number }> {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      return { synced: 0, remaining: this.offlineScheduleQueue.length };
    }
    if (this.offlineScheduleQueue.length === 0) {
      return { synced: 0, remaining: 0 };
    }

    let syncedCount = 0;
    const remaining: OfflineScheduleStatusUpdate[] = [];

    for (const item of [...this.offlineScheduleQueue]) {
      const success = await this.syncSingleUpdateToSupabase(item);
      if (success) {
        syncedCount++;
      } else {
        remaining.push(item);
      }
    }

    this.offlineScheduleQueue = remaining;
    this.saveToStorage('akk_offline_sync_queue', this.offlineScheduleQueue);

    if (syncedCount > 0) {
      console.info(`[LogisticsStore] Successfully synced ${syncedCount} offline delivery updates to Supabase database.`);
      this.emitNotification(
        'delivery',
        'Sinkronisasi Offline Berhasil',
        `${syncedCount} pembaruan status pengiriman yang tertunda saat offline kini telah disinkronkan ke Supabase.`
      );
    }

    return { synced: syncedCount, remaining: this.offlineScheduleQueue.length };
  }

  public getOfflineScheduleQueue(): OfflineScheduleStatusUpdate[] {
    return [...this.offlineScheduleQueue];
  }

  public addFleet(fleet: Omit<Fleet, 'id'>): Fleet {
    // Prevent adding any fleet with plate ending in AKK
    if ((fleet.plateNumber || '').trim().toUpperCase().endsWith('AKK')) {
      console.warn(`[Store] Dilarang menambahkan armada berakhiran AKK (${fleet.plateNumber}). Menggunakan armada resmi.`);
      const fallback = this.fleets.find(f => !(f.plateNumber || '').toUpperCase().endsWith('AKK')) || INITIAL_FLEETS[0];
      return fallback;
    }

    const newFleet: Fleet = {
      ...fleet,
      id: 'flt-' + Math.random().toString(36).substring(2, 8)
    };
    this.fleets = [...this.fleets, newFleet];
    this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);
    this.logActivity(
      'Tambah Data Armada',
      `${newFleet.plateNumber} (${newFleet.initialCode || newFleet.vehicleType})`,
      `Menambahkan data armada baru ${newFleet.plateNumber} • Jenis: ${newFleet.vehicleType}`,
      'tambah'
    );

    // Asynchronous backend integration with Supabase
    createFleetInSupabase(newFleet).then(res => {
      if (res.data?.id && res.data.id !== newFleet.id) {
        newFleet.id = res.data.id;
        this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);
        this.notify();
      }
    }).catch(err => console.warn('[Supabase Store Auto-Create Fleet Note]', err));

    this.dispatchMiddleware({
      entityType: 'fleet',
      action: 'create',
      id: newFleet.id,
      data: newFleet,
      timestamp: new Date().toISOString()
    });

    this.notify();
    return newFleet;
  }

  public purgeAkkFleets(): { removedCount: number; remainingCount: number } {
    const originalCount = this.fleets.length;
    this.fleets = this.fleets.filter(f => !(f.plateNumber || '').trim().toUpperCase().endsWith('AKK'));
    
    // Ensure all 12 initial fleets are present
    INITIAL_FLEETS.forEach(initF => {
      const exists = this.fleets.some(f => f.id === initF.id || f.plateNumber === initF.plateNumber);
      if (!exists && !(initF.plateNumber || '').toUpperCase().endsWith('AKK')) {
        this.fleets.push({ ...initF });
      }
    });
    
    this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);

    // Re-map any schedules pointing to deleted AKK fleets
    this.schedules = this.schedules.map(sch => {
      const currentF = this.fleets.find(f => f.id === sch.fleetId);
      if (!currentF || (currentF.plateNumber || '').trim().toUpperCase().endsWith('AKK')) {
        const fallback = this.fleets.find(f => !(f.plateNumber || '').toUpperCase().endsWith('AKK')) || this.fleets[0];
        return { ...sch, fleetId: fallback.id, fleet: fallback };
      }
      return sch;
    });
    this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
    this.notify();

    return {
      removedCount: Math.max(0, originalCount - this.fleets.length),
      remainingCount: this.fleets.length
    };
  }

  public getWibTodayIso(): string {
    const now = new Date();
    const wibMs = now.getTime() + 7 * 60 * 60 * 1000;
    return new Date(wibMs).toISOString().slice(0, 10);
  }

  public getScheduleCalendarIso(sch: Schedule): string {
    const toLocalWibIso = (raw?: string): string => {
      if (!raw) return '';
      const s = String(raw).trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
      // Extract YYYY-MM-DD directly when +07:00 or plain ISO date prefix exists
      if (/^\d{4}-\d{2}-\d{2}T/.test(s) && s.includes('+07:00')) return s.slice(0, 10);
      const d = new Date(s);
      if (!isNaN(d.getTime())) {
        return new Date(d.getTime() + 7 * 60 * 60 * 1000).toISOString().slice(0, 10);
      }
      return s.slice(0, 10);
    };

    const depIso = toLocalWibIso(sch.deliveryDate || sch.departureDate);
    const retIso = toLocalWibIso(sch.returnDate || sch.estimatedArrival);
    if (retIso && depIso && retIso > depIso) {
      return retIso;
    }
    return depIso || retIso || toLocalWibIso(sch.createdAt);
  }

  public doesScheduleCoverDate(sch: Schedule, targetIso: string): boolean {
    if (!targetIso) return false;
    const toIso = (raw?: string): string => {
      if (!raw) return '';
      const s = String(raw).trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
      if (/^\d{4}-\d{2}-\d{2}T/.test(s) && s.includes('+07:00')) return s.slice(0, 10);
      const d = new Date(s);
      if (!isNaN(d.getTime())) {
        return new Date(d.getTime() + 7 * 60 * 60 * 1000).toISOString().slice(0, 10);
      }
      return s.slice(0, 10);
    };

    const depIso = toIso(sch.deliveryDate || sch.departureDate);
    const retIso = toIso(sch.returnDate || sch.estimatedArrival) || depIso;
    const calIso = this.getScheduleCalendarIso(sch);

    if (calIso === targetIso || depIso === targetIso || retIso === targetIso) return true;
    if (depIso && retIso && depIso <= targetIso && retIso >= targetIso) return true;
    return false;
  }

  public matchesFleetSchedule(fleet: Fleet, sch: Schedule): boolean {
    if (!fleet || !sch) return false;
    if (sch.fleetId && sch.fleetId === fleet.id) return true;
    const cleanPlate = (fleet.plateNumber || '').replace(/\s+/g, '').toUpperCase();
    const schPlate = (sch.fleet?.plateNumber || '').replace(/\s+/g, '').toUpperCase();
    if (cleanPlate && schPlate && schPlate === cleanPlate) return true;

    const resolvedFromSch = this.findFleetByCodeOrPlate(
      sch.armada || sch.fleet?.initialCode || sch.fleet?.plateNumber || sch.fleetId
    );
    if (resolvedFromSch && resolvedFromSch.id === fleet.id) return true;

    const fInit = (fleet.initialCode || '').trim().toUpperCase();
    const sArm = (sch.armada || sch.fleet?.initialCode || '').trim().toUpperCase();
    if (fInit && sArm) {
      if (fInit === sArm) return true;
      const fParts = fInit.split('/').map(x => x.trim()).filter(Boolean);
      const sParts = sArm.split('/').map(x => x.trim()).filter(Boolean);
      if (fParts.some(p => sParts.includes(p))) return true;
    }
    return false;
  }

  public findFleetAssignmentConflict(
    armadaOrFleetId: string,
    targetDateIso: string,
    excludeScheduleId?: string
  ): { fleet: Fleet | null; conflictSchedule: Schedule } | null {
    const cleanTargetIso = (targetDateIso || '').slice(0, 10);
    const rawKey = (armadaOrFleetId || '').trim().toUpperCase();
    if (!rawKey || !cleanTargetIso) return null;

    const resolvedFleet =
      this.fleets.find(
        f =>
          f.id === armadaOrFleetId ||
          f.plateNumber.trim().toUpperCase() === rawKey ||
          (f.initialCode && f.initialCode.trim().toUpperCase() === rawKey)
      ) ||
      this.findFleetByCodeOrPlate(armadaOrFleetId) ||
      null;

    const conflictSchedule = (this.schedules || []).find(sch => {
      if (excludeScheduleId && sch.id === excludeScheduleId) return false;
      if (sch.status === 'delivered' || String(sch.status) === 'cancelled') return false;
      if (!this.doesScheduleCoverDate(sch, cleanTargetIso)) return false;

      if (resolvedFleet) {
        return this.matchesFleetSchedule(resolvedFleet, sch);
      }

      const schArmada = (sch.armada || sch.fleet?.initialCode || sch.fleet?.plateNumber || '').trim().toUpperCase();
      return schArmada === rawKey;
    });

    if (!conflictSchedule) return null;
    return { fleet: resolvedFleet, conflictSchedule };
  }

  public reconcileFleetAndScheduleStatuses(persistChanges: boolean = false) {
    const todayWib = this.getWibTodayIso();
    let schedulesChanged = false;

    // 1. Tutup otomatis jadwal lampau (< hari ini WIB) yang masih nyangkut status 'in_transit' / 'picked_up' / 'delayed'
    // agar armada seperti NMR/DS5 tidak terus-terusan stuck status Kirim area hari sebelumnya.
    this.schedules = (this.schedules || []).map(sch => {
      if (['in_transit', 'picked_up', 'delayed'].includes(sch.status)) {
        const calIso = this.getScheduleCalendarIso(sch);
        const endIso = (sch.returnDate || sch.estimatedArrival || calIso || '').slice(0, 10);
        const depActIso = (sch.actualDeparture || '').slice(0, 10);
        const isStillTodayOrFuture =
          this.doesScheduleCoverDate(sch, todayWib) ||
          (calIso && calIso >= todayWib) ||
          (endIso && endIso >= todayWib) ||
          depActIso === todayWib;

        if (!isStillTodayOrFuture && endIso && endIso < todayWib) {
          schedulesChanged = true;
          return {
            ...sch,
            status: 'delivered' as const,
            actualArrival: sch.actualArrival || sch.estimatedArrival || `${endIso}T17:00:00+07:00`,
            updatedAt: new Date().toISOString()
          };
        }
      }
      return sch;
    });

    if (schedulesChanged) {
      this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
      if (persistChanges) {
        this.persistSchedulesSnapshotToBackend('reconcile_past_active_trips');
      }
    }

    // 2. Sinkronkan status armada dengan jadwal aktif hari ini:
    // - 'maintenance' tetap dipertahankan
    // - 'on-duty' hanya aktif jika benar-benar ada jadwal aktif hari ini ('in_transit' / 'picked_up' / 'delayed')
    // - Jika tidak ada jadwal aktif yang sedang jalan hari ini, otomatis pulihkan ke 'available' (Ready)
    const fleetsNeedingSync: Fleet[] = [];
    let fleetsChanged = false;
    this.fleets = (this.fleets || []).map(f => {
      if (f.status === 'maintenance') return f;
      const hasTodayActiveTrip = (this.schedules || []).some(
        sch =>
          ['in_transit', 'picked_up', 'delayed'].includes(sch.status) &&
          this.matchesFleetSchedule(f, sch) &&
          (this.doesScheduleCoverDate(sch, todayWib) || (sch.actualDeparture || '').slice(0, 10) === todayWib)
      );
      const targetStatus: Fleet['status'] = hasTodayActiveTrip ? 'on-duty' : 'available';
      if (f.status !== targetStatus) {
        fleetsChanged = true;
        const updatedF = { ...f, status: targetStatus };
        fleetsNeedingSync.push(updatedF);
        return updatedF;
      }
      return f;
    });

    if (fleetsChanged) {
      this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);
      if (persistChanges) {
        fleetsNeedingSync.forEach(uf => {
          updateFleetInSupabase(uf.id, { status: uf.status, plateNumber: uf.plateNumber }).catch(() => {});
        });
      }
    }
  }

  public updateFleetStatus(
    idOrPlate: string,
    status: Fleet['status'],
    tonnage?: number,
    options?: { syncTodaySchedule?: boolean }
  ) {
    const cleanTarget = (idOrPlate || '').trim().toUpperCase();
    let matchedFleet = null as Fleet | null;
    let matchedId = idOrPlate;
    let matchedPlateNumber: string | undefined;
    this.fleets = this.fleets.map(f => {
      if (
        f.id === idOrPlate ||
        f.plateNumber.trim().toUpperCase() === cleanTarget ||
        (f.initialCode && f.initialCode.trim().toUpperCase() === cleanTarget)
      ) {
        matchedId = f.id;
        matchedPlateNumber = f.plateNumber;
        matchedFleet = {
          ...f,
          status,
          currentTonnage: tonnage !== undefined ? tonnage : f.currentTonnage
        };
        return matchedFleet;
      }
      return f;
    });
    this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);

    // Sinkronkan status jadwal hari ini apabila admin mengubah status armada secara langsung dari Manajemen Armada
    if (options?.syncTodaySchedule && matchedFleet) {
      const todayWib = this.getWibTodayIso();
      const nowIso = new Date().toISOString();
      let schUpdated = false;
      this.schedules = (this.schedules || []).map(sch => {
        if (!this.matchesFleetSchedule(matchedFleet!, sch)) return sch;
        const coversToday = this.doesScheduleCoverDate(sch, todayWib);
        if (status === 'on-duty' && coversToday && sch.status === 'scheduled') {
          schUpdated = true;
          return {
            ...sch,
            status: 'in_transit' as const,
            actualDeparture: sch.actualDeparture || nowIso,
            updatedAt: nowIso
          };
        }
        if ((status === 'available' || status === 'maintenance') && ['in_transit', 'picked_up', 'delayed'].includes(sch.status)) {
          schUpdated = true;
          return {
            ...sch,
            status: 'delivered' as const,
            actualArrival: sch.actualArrival || nowIso,
            updatedAt: nowIso
          };
        }
        return sch;
      });
      if (schUpdated) {
        this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
        this.persistSchedulesSnapshotToBackend('fleet_status_sync');
      }
    }

    // Asynchronous backend integration with Supabase / Hostinger MySQL
    updateFleetInSupabase(matchedId, { status, currentTonnage: tonnage, plateNumber: matchedPlateNumber }).catch(err => console.warn('[Supabase Fleet Status Sync Note]', err));

    this.dispatchMiddleware({
      entityType: 'fleet',
      action: 'status_change',
      id: matchedId,
      data: { id: matchedId, status, currentTonnage: tonnage },
      timestamp: new Date().toISOString()
    });

    this.notify();
  }

  /**
   * Mengambil informasi status kondisi armada secara real-time terintegrasi dengan:
   * - Check-In / Gate-Out / Tiba di Gudang (Check-Out) Tim Pengiriman
   * - Jadwal Pengiriman Hari Ini
   * - Data Armada & Portal Driver
   *
   * 3 Status Kondisi Armada:
   * 1. Ready ('available'): Siap digunakan jadwal (atau sedang terjadwal menunggu berangkat). Penanda: Titik Besar Hijau.
   * 2. Kirim ('on-duty'): Sedang dipakai kirim tim pengiriman (sudah Gate-Out / status jadwal in_transit / picked_up / delayed hari ini). Penanda: Titik Besar Biru + Area Kirim hari tersebut.
   * 3. Servis ('maintenance'): Dalam keadaan perbaikan dan TIDAK BISA diaturkan kirim. Penanda: Titik Besar Merah.
   */
  public getFleetLiveOperationalInfo(
    fleetOrId: Fleet | string,
    targetDateStr?: string,
    excludeScheduleId?: string
  ): {
    effectiveStatus: 'available' | 'on-duty' | 'maintenance';
    statusLabel: 'Ready' | 'Terjadwal' | 'Kirim' | 'Servis';
    dotColorClass: string;
    badgeColorClass: string;
    areaName: string | null;
    todayScheduledArea: string | null;
    tomorrowScheduledArea: string | null;
    upcomingScheduledArea: string | null;
    scheduledDepartureTime: string | null;
    scheduledReturnTime: string | null;
    scheduledDateLabel: string | null;
    driverName: string | null;
    helperName: string | null;
    canBeScheduled: boolean;
    statusDescription: string;
    scheduleStatus: Schedule['status'] | null;
  } {
    const fleet =
      typeof fleetOrId === 'string'
        ? this.fleets.find(
            f =>
              f.id === fleetOrId ||
              f.plateNumber.trim().toUpperCase() === fleetOrId.trim().toUpperCase() ||
              (f.initialCode && f.initialCode.trim().toUpperCase() === fleetOrId.trim().toUpperCase())
          ) || this.findFleetByCodeOrPlate(fleetOrId)
        : fleetOrId;

    if (!fleet) {
      return {
        effectiveStatus: 'available',
        statusLabel: 'Ready',
        dotColorClass: 'bg-emerald-500 ring-2 ring-emerald-500/20',
        badgeColorClass:
          'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300 dark:border-emerald-500/40',
        areaName: null,
        todayScheduledArea: null,
        tomorrowScheduledArea: null,
        upcomingScheduledArea: null,
        scheduledDepartureTime: null,
        scheduledReturnTime: null,
        scheduledDateLabel: null,
        driverName: null,
        helperName: null,
        canBeScheduled: true,
        statusDescription: 'Siap digunakan untuk jadwal pengiriman',
        scheduleStatus: null
      };
    }

    const todayWib = this.getWibTodayIso();
    const tomorrowWib = (() => {
      const parts = todayWib.split('-').map(Number);
      if (parts.length !== 3 || parts.some(isNaN)) return '';
      const d = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2] + 1));
      return d.toISOString().slice(0, 10);
    })();
    const targetIso = (targetDateStr || todayWib).slice(0, 10);
    const isDateSpecificQuery = Boolean(targetDateStr && targetDateStr.trim() !== '');

    const matchesFleet = (sch: Schedule) => this.matchesFleetSchedule(fleet, sch);
    const isActiveAssignableStatus = (st?: Schedule['status']) =>
      st !== 'delivered' && String(st) !== 'cancelled';

    const sortNewestFirst = (a: Schedule, b: Schedule) =>
      String(b.updatedAt || b.createdAt || '').localeCompare(String(a.updatedAt || a.createdAt || ''));

    // 1. Jadwal yang sedang aktif di jalan pada hari ini (Gate-Out aktif)
    const activeTripSch = (this.schedules || [])
      .filter(
        sch =>
          (!excludeScheduleId || sch.id !== excludeScheduleId) &&
          ['in_transit', 'picked_up', 'delayed'].includes(sch.status) &&
          matchesFleet(sch) &&
          (this.doesScheduleCoverDate(sch, todayWib) || (sch.actualDeparture || '').slice(0, 10) === todayWib)
      )
      .sort(sortNewestFirst)[0];

    // 2. Jadwal aktif pada tanggal target
    const targetDateSch = (this.schedules || [])
      .filter(
        sch =>
          (!excludeScheduleId || sch.id !== excludeScheduleId) &&
          isActiveAssignableStatus(sch.status) &&
          matchesFleet(sch) &&
          this.doesScheduleCoverDate(sch, targetIso)
      )
      .sort(sortNewestFirst)[0];

    // 3. Jadwal aktif untuk esok hari (WIB)
    const tomorrowDateSch = tomorrowWib
      ? (this.schedules || [])
          .filter(
            sch =>
              (!excludeScheduleId || sch.id !== excludeScheduleId) &&
              isActiveAssignableStatus(sch.status) &&
              matchesFleet(sch) &&
              this.doesScheduleCoverDate(sch, tomorrowWib)
          )
          .sort(sortNewestFirst)[0]
      : undefined;

    // 4. Jadwal aktif terdekat (>= hari ini WIB) termasuk tanggal lusa / mendatang dari modal "Buat Kiriman"
    const upcomingScheduledSch = (this.schedules || [])
      .filter(sch => {
        if (excludeScheduleId && sch.id === excludeScheduleId) return false;
        if (!isActiveAssignableStatus(sch.status) || !matchesFleet(sch)) return false;
        const calIso = this.getScheduleCalendarIso(sch) || (sch.deliveryDate || sch.departureDate || '').slice(0, 10);
        return Boolean(calIso && calIso >= todayWib);
      })
      .sort((a, b) => {
        const aIso = this.getScheduleCalendarIso(a) || (a.deliveryDate || a.departureDate || '').slice(0, 10);
        const bIso = this.getScheduleCalendarIso(b) || (b.deliveryDate || b.departureDate || '').slice(0, 10);
        if (aIso !== bIso) return aIso.localeCompare(bIso);
        return sortNewestFirst(a, b);
      })[0];

    // Jadwal efektif untuk tampilan Live Armada vs query tanggal spesifik
    const effectiveSch = isDateSpecificQuery
      ? targetDateSch
      : (activeTripSch || targetDateSch);

    // Jadwal referensi untuk menampilkan informasi area/kru/jam target di Data Armada Terpadu
    const referenceSch = effectiveSch || tomorrowDateSch || upcomingScheduledSch;

    const extractClockWib = (explicitClock?: string, isoTimestamp?: string): string | null => {
      const cleanExplicit = (explicitClock || '').trim();
      const clockMatch = cleanExplicit.match(/^(\d{1,2})[:.](\d{2})$/);
      if (clockMatch) {
        return `${clockMatch[1].padStart(2, '0')}:${clockMatch[2]}`;
      }
      if (!isoTimestamp) return null;
      const d = new Date(isoTimestamp);
      if (Number.isNaN(d.getTime())) return null;
      try {
        return new Intl.DateTimeFormat('en-GB', {
          timeZone: 'Asia/Jakarta',
          hour: '2-digit',
          minute: '2-digit',
          hour12: false
        }).format(d);
      } catch {
        return null;
      }
    };

    const formatShortDateIndo = (iso?: string): string | null => {
      if (!iso || !/^\d{4}-\d{2}-\d{2}/.test(iso)) return null;
      const d = new Date(`${iso.slice(0, 10)}T00:00:00+07:00`);
      if (Number.isNaN(d.getTime())) return iso.slice(0, 10);
      return d.toLocaleDateString('id-ID', {
        timeZone: 'Asia/Jakarta',
        day: '2-digit',
        month: 'short'
      });
    };

    const fleetPairedDriver = this.crews.find(
      c => c.currentFleetId === fleet.id || (fleet.driverId && c.id === fleet.driverId)
    );

    const resolveDriverFromSch = (sch?: Schedule): string | null => {
      if (!sch) return null;
      return (
        sch.crew?.name ||
        (sch.crewId ? this.crews.find(c => c.id === sch.crewId)?.name : undefined) ||
        null
      );
    };

    const resolveHelperFromSch = (sch?: Schedule): string | null => {
      if (!sch) return null;
      return (
        sch.crewHelper?.name ||
        (sch.crewHelperId ? this.crews.find(c => c.id === sch.crewHelperId)?.name : undefined) ||
        null
      );
    };

    const resolvedArea: string | null = effectiveSch
      ? effectiveSch.areaName || effectiveSch.store?.storeName || null
      : null;

    const resolvedDriver: string | null =
      resolveDriverFromSch(referenceSch) || fleetPairedDriver?.name || null;
    const resolvedHelper: string | null = resolveHelperFromSch(referenceSch) || null;

    const scheduledDepartureTime = referenceSch
      ? extractClockWib(referenceSch.departureTime, referenceSch.departureDate)
      : null;
    const scheduledReturnTime = referenceSch
      ? extractClockWib(referenceSch.targetReturnTime, referenceSch.estimatedArrival)
      : null;
    const referenceDateIso = referenceSch
      ? (referenceSch.deliveryDate || this.getScheduleCalendarIso(referenceSch) || '').slice(0, 10)
      : '';
    const scheduledDateLabel = referenceDateIso ? formatShortDateIndo(referenceDateIso) : null;

    const todayScheduledArea =
      !activeTripSch && targetDateSch && targetDateSch.status === 'scheduled'
        ? (targetDateSch.areaName || targetDateSch.store?.storeName || null)
        : null;

    const tomorrowScheduledArea =
      tomorrowDateSch
        ? (tomorrowDateSch.areaName || tomorrowDateSch.store?.storeName || null)
        : null;

    const upcomingScheduledArea =
      !todayScheduledArea && !tomorrowScheduledArea && upcomingScheduledSch
        ? (upcomingScheduledSch.areaName || upcomingScheduledSch.store?.storeName || null)
        : null;

    // Bersihkan cache shift lama dari localStorage bila masih tersisa
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.removeItem('akk_driver_shifts_v2');
      } catch {}
    }

    let effectiveStatus: 'available' | 'on-duty' | 'maintenance' = 'available';
    if (fleet.status === 'maintenance') {
      effectiveStatus = 'maintenance';
    } else if (isDateSpecificQuery) {
      effectiveStatus = targetDateSch ? 'on-duty' : 'available';
    } else if (activeTripSch) {
      effectiveStatus = 'on-duty';
    } else {
      effectiveStatus = 'available';
    }

    if (effectiveStatus === 'maintenance') {
      return {
        effectiveStatus: 'maintenance',
        statusLabel: 'Servis',
        dotColorClass: 'bg-rose-500 ring-2 ring-rose-500/20',
        badgeColorClass:
          'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-500/15 dark:text-rose-300 dark:border-rose-500/40',
        areaName: resolvedArea,
        todayScheduledArea: null,
        tomorrowScheduledArea: null,
        upcomingScheduledArea: null,
        scheduledDepartureTime: null,
        scheduledReturnTime: null,
        scheduledDateLabel: null,
        driverName: resolvedDriver,
        helperName: resolvedHelper,
        canBeScheduled: false,
        statusDescription: 'Dalam perbaikan (Tidak bisa diaturkan kirim)',
        scheduleStatus: effectiveSch?.status || null
      };
    }

    if (effectiveStatus === 'on-duty') {
      const isPendingScheduleOnly = isDateSpecificQuery && targetDateSch?.status === 'scheduled';
      const canScheduleFlag = !targetDateSch;
      const hoursNote =
        scheduledDepartureTime && scheduledReturnTime
          ? ` • ${scheduledDepartureTime}–${scheduledReturnTime} WIB`
          : '';
      return {
        effectiveStatus: 'on-duty',
        statusLabel: isPendingScheduleOnly ? 'Terjadwal' : 'Kirim',
        dotColorClass: isPendingScheduleOnly
          ? 'bg-amber-500 ring-2 ring-amber-500/20'
          : 'bg-blue-600 ring-2 ring-blue-500/20',
        badgeColorClass: isPendingScheduleOnly
          ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/40'
          : 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-500/15 dark:text-blue-300 dark:border-blue-500/40',
        areaName: resolvedArea,
        todayScheduledArea: isPendingScheduleOnly ? resolvedArea : null,
        tomorrowScheduledArea,
        upcomingScheduledArea,
        scheduledDepartureTime,
        scheduledReturnTime,
        scheduledDateLabel,
        driverName: resolvedDriver,
        helperName: resolvedHelper,
        canBeScheduled: canScheduleFlag,
        statusDescription: isPendingScheduleOnly
          ? `Terjadwal (${scheduledDateLabel || targetIso}): ${resolvedArea || 'Kirim'}${hoursNote}`
          : resolvedArea
          ? `Sedang Kirim • Area: ${resolvedArea}${hoursNote}`
          : 'Sedang dipakai kirim tim pengiriman (Gate-Out)',
        scheduleStatus: effectiveSch?.status || 'in_transit'
      };
    }

    const timeWindowSuffix =
      scheduledDepartureTime && scheduledReturnTime
        ? ` (${scheduledDepartureTime}–${scheduledReturnTime} WIB)`
        : '';

    return {
      effectiveStatus: 'available',
      statusLabel: 'Ready',
      dotColorClass: 'bg-emerald-500 ring-2 ring-emerald-500/20',
      badgeColorClass:
        'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300 dark:border-emerald-500/40',
      areaName: null,
      todayScheduledArea,
      tomorrowScheduledArea,
      upcomingScheduledArea,
      scheduledDepartureTime,
      scheduledReturnTime,
      scheduledDateLabel,
      driverName: resolvedDriver,
      helperName: resolvedHelper,
      canBeScheduled: true,
      statusDescription: todayScheduledArea
        ? `Terjadwal Hari Ini: ${todayScheduledArea}${timeWindowSuffix}`
        : tomorrowScheduledArea
        ? `Terjadwal Esok: ${tomorrowScheduledArea}${timeWindowSuffix}`
        : upcomingScheduledArea
        ? `Terjadwal (${scheduledDateLabel || 'Mendatang'}): ${upcomingScheduledArea}${timeWindowSuffix}`
        : 'Siap jadwal pengiriman',
      scheduleStatus: referenceSch?.status || null
    };
  }

  public updateFleet(id: string, updatedFields: Partial<Fleet>) {
    this.verifyDriverAccess('updateFleet');

    let updatedFleet: Fleet | null = null;
    this.fleets = sortFleetsByCanonicalOrder(
      this.fleets.map(f => {
        if (f.id === id) {
          updatedFleet = this.enrichFleetItem({ ...f, ...updatedFields }, f);
          return updatedFleet;
        }
        return f;
      })
    );
    this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);

    if (updatedFleet) {
      const fObj = updatedFleet as Fleet;
      this.logActivity(
        'Ubah Data Armada',
        `${fObj.plateNumber} (${fObj.initialCode || fObj.vehicleType})`,
        `Merubah data armada ${fObj.plateNumber} (${fObj.vehicleType})`,
        'ubah'
      );
      // Asynchronous backend integration with Supabase
      updateFleetInSupabase(id, { ...updatedFields, plateNumber: fObj.plateNumber }).catch(err => console.warn('[Supabase Fleet Update Sync Note]', err));

      this.dispatchMiddleware({
        entityType: 'fleet',
        action: 'update',
        id,
        data: updatedFleet,
        timestamp: new Date().toISOString()
      });
    }

    this.notify();
  }

  public deleteFleet(id: string) {
    const deletedFleet = this.fleets.find(f => f.id === id);
    const remainingFleets = this.fleets.filter(f => f.id !== id);
    const cleanDeletedPlate = String(deletedFleet?.plateNumber || '').replace(/\s+/g, '').toUpperCase();
    const hasSiblingPlate = Boolean(
      cleanDeletedPlate &&
      remainingFleets.some(f => String(f.plateNumber || '').replace(/\s+/g, '').toUpperCase() === cleanDeletedPlate)
    );

    this.fleets = remainingFleets;
    this.cachedFleets = null;
    this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);
    if (deletedFleet) {
      this.logActivity('Hapus Armada', deletedFleet.plateNumber, `Menghapus armada ${deletedFleet.plateNumber} (${deletedFleet.initialCode || deletedFleet.vehicleType})`);

      // Asynchronous backend integration: only blacklist plate if no sibling canonical row uses it
      deleteFleetInSupabase(id, deletedFleet.plateNumber, hasSiblingPlate).catch(err =>
        console.warn('[Supabase Fleet Delete Sync Note]', err)
      );

      this.dispatchMiddleware({
        entityType: 'fleet',
        action: 'delete',
        id,
        data: deletedFleet,
        timestamp: new Date().toISOString()
      });
    }
    this.notify();
  }

  public findDuplicateFleetGroups(): Array<{
    key: string;
    primary: Fleet;
    duplicates: Fleet[];
    reason: string;
  }> {
    const currentFleets = this.getFleets();
    const normPlate = (p?: string) => String(p || '').replace(/\s+/g, '').toUpperCase();
    const isValidPlate = (plate: string) => Boolean(plate && plate !== '-' && !/^FLT-\d+$/i.test(plate));
    const GENERIC_FLEET_TOKENS = new Set([
      'TRUK', 'BOX', 'UNIT', 'MOBIL', 'ARMADA',
      'NMR', 'NLR', 'ELF', 'CANTER', 'HINO', 'ISUZU', 'TRAGA', 'L300', 'COLT', 'FUSO', 'DUTRO',
      'PICKUP', 'ENGKEL', 'DOUBLE', 'STD', 'LONG'
    ]);
    const extractInitTokens = (init?: string) =>
      String(init || '')
        .toUpperCase()
        .split(/[\s\/\-_,()]+/)
        .map(t => t.trim())
        .filter(t => t.length >= 2 && !GENERIC_FLEET_TOKENS.has(t));

    // Union-Find clustering across identical normalized plates (or missing-plate duplicates matching canonical/unit code)
    const parent = currentFleets.map((_, idx) => idx);
    const reasons = new Map<string, string>();
    const find = (i: number): number => (parent[i] === i ? i : (parent[i] = find(parent[i])));
    const union = (i: number, j: number, reason: string) => {
      const ri = find(i);
      const rj = find(j);
      if (ri !== rj) {
        parent[rj] = ri;
        reasons.set(`${Math.min(ri, rj)}_${Math.max(ri, rj)}`, reason);
      }
    };

    for (let i = 0; i < currentFleets.length; i++) {
      for (let j = i + 1; j < currentFleets.length; j++) {
        const a = currentFleets[i];
        const b = currentFleets[j];
        const pa = normPlate(a.plateNumber);
        const pb = normPlate(b.plateNumber);
        const validA = isValidPlate(pa);
        const validB = isValidPlate(pb);

        // 1. Exact same valid license plate -> true duplicate
        if (validA && validB && pa === pb) {
          const sameInit = String(a.initialCode || '').trim().toUpperCase() === String(b.initialCode || '').trim().toUpperCase();
          union(i, j, sameInit ? 'Plat nomor sama persis' : 'Plat sama dengan inisial berbeda');
          continue;
        }

        // 2. Two distinct valid license plates represent two distinct physical vehicles (e.g., NMR / DS4 vs NMR / DS5)
        if (validA && validB && pa !== pb) {
          continue;
        }

        // 3. Only when at least one record has a missing/placeholder plate, match by canonical identity or unique unit token
        const ca = resolveCanonicalFleetMeta(a);
        const cb = resolveCanonicalFleetMeta(b);
        if (ca && cb && ca.id === cb.id) {
          union(i, j, `Mengacu pada unit standar ${ca.plateNumber} (${ca.initialCode})`);
          continue;
        }
        const tokA = extractInitTokens(a.initialCode);
        const tokB = extractInitTokens(b.initialCode);
        if (tokA.length > 0 && tokB.length > 0 && tokA.some(t => tokB.includes(t))) {
          union(i, j, 'Inisial unit saling bertumpuk');
        }
      }
    }

    const clusters = new Map<number, number[]>();
    for (let i = 0; i < currentFleets.length; i++) {
      const root = find(i);
      if (!clusters.has(root)) clusters.set(root, []);
      clusters.get(root)!.push(i);
    }

    const groups: Array<{ key: string; primary: Fleet; duplicates: Fleet[]; reason: string }> = [];
    clusters.forEach((idxs, root) => {
      if (idxs.length <= 1) return;
      const members = idxs.map(idx => currentFleets[idx]);
      const scoreFleet = (f: Fleet) => {
        let score = 0;
        if (/^flt-\d+$/i.test(f.id)) score += 100;
        const canon = resolveCanonicalFleetMeta(f);
        if (canon && canon.id === f.id) score += 80;
        if (f.initialCode && f.initialCode.includes('/')) score += 40;
        if (canon && canon.initialCode === f.initialCode) score += 30;
        if (this.schedules.some(s => s.fleetId === f.id)) score += 20;
        if (this.crews.some(c => c.currentFleetId === f.id)) score += 15;
        return score;
      };
      const sorted = [...members].sort((a, b) => scoreFleet(b) - scoreFleet(a));
      const [primary, ...duplicates] = sorted;
      let reason = 'Data ganda armada terdeteksi';
      for (const [k, r] of reasons.entries()) {
        if (k.startsWith(`${root}_`) || k.endsWith(`_${root}`) || idxs.some(x => k.includes(String(x)))) {
          reason = r;
          break;
        }
      }
      groups.push({
        key: primary.id,
        primary,
        duplicates,
        reason
      });
    });

    return groups;
  }

  public deduplicateAndCleanupFleets(): { removedCount: number; cleanedPlates: string[] } {
    const groups = this.findDuplicateFleetGroups();
    if (groups.length === 0) return { removedCount: 0, cleanedPlates: [] };

    const idsToRemove = new Set<string>();
    const cleanedPlates: string[] = [];

    groups.forEach(group => {
      const canonicalMeta = resolveCanonicalFleetMeta(group.primary);
      const mergedPrimary = this.enrichFleetItem(
        {
          ...group.primary,
          plateNumber: canonicalMeta?.plateNumber || group.primary.plateNumber,
          initialCode: canonicalMeta?.initialCode || group.primary.initialCode
        },
        group.primary
      );

      const dupIds = new Set(group.duplicates.map(d => d.id));
      dupIds.forEach(dId => idsToRemove.add(dId));
      cleanedPlates.push(`${mergedPrimary.plateNumber} (${mergedPrimary.initialCode || '-'})`);

      // Reassign crews referencing any duplicate ID to primary fleet
      let crewsModified = false;
      this.crews = this.crews.map(c => {
        if (c.currentFleetId && dupIds.has(c.currentFleetId)) {
          crewsModified = true;
          return { ...c, currentFleetId: mergedPrimary.id };
        }
        return c;
      });
      if (crewsModified) {
        this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);
      }

      // Reassign schedules referencing any duplicate ID to primary fleet
      let schedulesModified = false;
      this.schedules = this.schedules.map(s => {
        if (dupIds.has(s.fleetId) || (s.fleet?.id && dupIds.has(s.fleet.id))) {
          schedulesModified = true;
          return {
            ...s,
            fleetId: mergedPrimary.id,
            fleet: mergedPrimary,
            armada: mergedPrimary.initialCode || mergedPrimary.plateNumber
          };
        }
        return s;
      });
      if (schedulesModified) {
        this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
      }

      // Update surviving primary record
      this.fleets = this.fleets.map(f => (f.id === group.primary.id ? mergedPrimary : f));

      // Remove duplicate IDs from backend while explicitly preserving the sibling canonical plate
      group.duplicates.forEach(dup => {
        deleteFleetInSupabase(dup.id, dup.plateNumber, true).catch(err =>
          console.warn('[Store Deduplicate Fleet Delete Warning]', err)
        );
      });
    });

    this.fleets = sortFleetsByCanonicalOrder(this.fleets.filter(f => !idsToRemove.has(f.id)));
    this.cachedFleets = null;
    this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);
    this.logActivity(
      'Bersihkan Data Double Armada',
      `${idsToRemove.size} data ganda`,
      `Membersihkan ${idsToRemove.size} data armada ganda dengan aman (${cleanedPlates.join(', ')})`
    );
    this.notify();

    return { removedCount: idsToRemove.size, cleanedPlates };
  }

  public addCrew(crew: Omit<Crew, 'id' | 'tripsCompleted' | 'rating'>): Crew {
    const cleanName = (crew.name || '').trim();
    const isHelper = (crew.role || '').toLowerCase().includes('helper') || (crew.role || '').toLowerCase().includes('kernet');
    const targetUserRole: UserRole = isHelper ? 'crew_helper' : 'driver';

    // Ensure a corresponding user exists in Manajemen User
    const existingUser = this.users.find(u => u.fullName.trim().toLowerCase() === cleanName.toLowerCase());
    if (!existingUser && cleanName) {
      const emailSlug = cleanName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'kru';
      const createdUser: UserProfile = {
        id: 'usr-' + Math.random().toString(36).substring(2, 8),
        fullName: cleanName,
        email: `${emailSlug}@gmail.com`,
        password: undefined,
        role: targetUserRole,
        department: 'Logistik & Pengiriman',
        phone: crew.phone || '0812-3456-7890',
        status: 'pending',
        createdAt: new Date().toISOString(),
        notes: `Terintegrasi dari Data Kru & Jadwal Pengiriman (${crew.role}) — akun login menunggu verifikasi Super Admin`,
        permissions: {
          modules: getDefaultPermissionsForRole(targetUserRole)
        }
      };
      this.users = [createdUser, ...this.users];
      this.saveToStorage(STORAGE_KEYS.USERS, this.users);
      // Bootstrap a pending server account with a one-time random password. Super Admin must reset it before activation.
      const bootstrapPassword = (typeof crypto !== 'undefined' && 'randomUUID' in crypto)
        ? `${crypto.randomUUID()}!A9`
        : `${Math.random().toString(36).slice(2)}${Date.now()}!A9`;
      fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          fullName: createdUser.fullName,
          email: createdUser.email,
          phone: createdUser.phone,
          department: createdUser.department,
          password: bootstrapPassword
        })
      }).catch(err => console.warn('[Hostinger Users] Bootstrap akun kru gagal:', err));
    } else if (existingUser && existingUser.role !== 'driver' && existingUser.role !== 'crew_helper') {
      existingUser.role = targetUserRole;
      this.saveToStorage(STORAGE_KEYS.USERS, this.users);
    }

    const newCrew: Crew = {
      ...crew,
      id: 'crw-' + Math.random().toString(36).substring(2, 8),
      tripsCompleted: 0,
      rating: 5.0
    };
    this.crews = [...this.crews, newCrew];
    this.syncUsersWithCrews();
    this.logActivity('Tambah Kru', newCrew.name, `Menambahkan kru baru ${newCrew.name} sebagai ${newCrew.role}`);
    
    // Asynchronous backend integration with Supabase
    createCrewInSupabase(newCrew).then(res => {
      if (res.data?.id && res.data.id !== newCrew.id) {
        newCrew.id = res.data.id;
        this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);
        this.notify();
      }
    }).catch(err => console.warn('[Supabase Crew Create Sync Note]', err));

    this.dispatchMiddleware({
      entityType: 'crew',
      action: 'create',
      id: newCrew.id,
      data: newCrew,
      timestamp: new Date().toISOString()
    });

    this.notify();
    return newCrew;
  }

  public updateCrewStatus(id: string, status: Crew['status']) {
    this.crews = this.crews.map(c => (c.id === id ? { ...c, status } : c));
    this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);
    
    // Asynchronous backend integration with Supabase
    updateCrewInSupabase(id, { status }).catch(err => console.warn('[Supabase Crew Status Sync Note]', err));

    this.dispatchMiddleware({
      entityType: 'crew',
      action: 'status_change',
      id,
      data: { id, status },
      timestamp: new Date().toISOString()
    });

    this.notify();
  }

  public updateCrew(id: string, updatedFields: Partial<Crew>) {
    let updatedCrew: Crew | null = null;
    this.crews = this.crews.map(c => {
      if (c.id === id) {
        updatedCrew = { ...c, ...updatedFields };
        return updatedCrew;
      }
      return c;
    });
    this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);

    if (updatedCrew) {
      const cObj = updatedCrew as Crew;
      this.logActivity(
        'Ubah Data Kru',
        cObj.name,
        `Merubah data kru pengiriman ${cObj.name} (${cObj.role})`,
        'ubah'
      );
      // Asynchronous backend integration with Supabase
      updateCrewInSupabase(id, updatedFields).catch(err => console.warn('[Supabase Crew Update Sync Note]', err));

      this.dispatchMiddleware({
        entityType: 'crew',
        action: 'update',
        id,
        data: updatedCrew,
        timestamp: new Date().toISOString()
      });
    }

    this.notify();
  }

  public deleteCrew(id: string) {
    const deletedCrew = this.crews.find(c => c.id === id);
    this.crews = this.crews.filter(c => c.id !== id);
    this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);
    if (deletedCrew) {
      this.logActivity('Hapus Data Kru', deletedCrew.name, `Menghapus kru ${deletedCrew.name} (${deletedCrew.role}) dari sistem armada`, 'kurangi');
      
      // Asynchronous backend integration with Supabase
      deleteCrewInSupabase(id, deletedCrew.name).catch(err => console.warn('[Supabase Crew Delete Sync Note]', err));

      this.dispatchMiddleware({
        entityType: 'crew',
        action: 'delete',
        id,
        data: deletedCrew,
        timestamp: new Date().toISOString()
      });
    }
    this.notify();
  }

  public async syncFleetsAndCrewsWithSupabase(): Promise<{ success: boolean; fleetsCount: number; crewsCount: number; message: string }> {
    return syncSupabaseFleetsAndCrews();
  }

  public addStore(store: Omit<RetailStore, 'id'>): RetailStore {
    if (isAreaRouteItem(store)) {
      console.warn(`[Store Protection] Blocked adding non-retail area item "${store.storeName}" to Retail Stores table.`);
      return {
        ...store,
        id: 'area-dest-' + Math.random().toString(36).substring(2, 8)
      } as RetailStore;
    }
    const newStore: RetailStore = {
      ...store,
      id: 'str-' + Math.random().toString(36).substring(2, 8)
    };
    this.stores = [...this.stores.filter(s => !isAreaRouteItem(s)), newStore];
    this.saveToStorage(STORAGE_KEYS.STORES, this.stores);
    this.logActivity(
      'Tambah Data Pelanggan / Toko',
      newStore.storeName,
      `Menambahkan data pelanggan/toko ${newStore.storeName} (${newStore.city || newStore.kabupaten || '-'})`,
      'tambah'
    );
    fetch('/api/stores', {
      method: 'POST', headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }), credentials: 'same-origin', body: JSON.stringify(newStore)
    }).catch(err => console.warn('[Hostinger Stores] Tambah toko gagal disinkronkan:', err));
    
    this.dispatchMiddleware({
      entityType: 'store',
      action: 'create',
      id: newStore.id,
      data: newStore,
      timestamp: new Date().toISOString()
    });

    this.notify();
    return newStore;
  }

  public setStores(newStores: RetailStore[]): void {
    this.stores = newStores.filter(s => !isAreaRouteItem(s));
    this.saveToStorage(STORAGE_KEYS.STORES, this.stores);
    fetch('/api/stores/batch', {
      method: 'POST', headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }), credentials: 'same-origin', body: JSON.stringify({ stores: this.stores })
    }).catch(err => console.warn('[Hostinger Stores] Batch toko gagal disinkronkan:', err));
    
    this.dispatchMiddleware({
      entityType: 'store',
      action: 'update',
      id: 'all_stores',
      data: { count: this.stores.length },
      metadata: { isBatch: true },
      timestamp: new Date().toISOString()
    });

    this.notify();
  }

  public updateStore(id: string, updatedFields: Partial<RetailStore>): void {
    let updatedStore: RetailStore | null = null;
    this.stores = this.stores.map(s => {
      if (s.id === id) {
        updatedStore = { ...s, ...updatedFields };
        return updatedStore;
      }
      return s;
    });
    this.saveToStorage(STORAGE_KEYS.STORES, this.stores);

    if (updatedStore) {
      const sObj = updatedStore as RetailStore;
      this.logActivity(
        'Ubah Data Pelanggan / Toko',
        sObj.storeName,
        `Merubah data pelanggan/toko ${sObj.storeName} (${sObj.city || sObj.kabupaten || '-'})`,
        'ubah'
      );
      fetch(`/api/stores/${encodeURIComponent(id)}`, {
        method: 'PUT', headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }), credentials: 'same-origin', body: JSON.stringify(updatedStore)
      }).catch(err => console.warn('[Hostinger Stores] Update toko gagal disinkronkan:', err));
      this.dispatchMiddleware({
        entityType: 'store',
        action: 'update',
        id,
        data: updatedStore,
        timestamp: new Date().toISOString()
      });
    }

    this.notify();
  }

  public deleteStore(id: string): void {
    const target = this.stores.find(s => s.id === id);
    this.stores = this.stores.filter(s => s.id !== id);
    this.saveToStorage(STORAGE_KEYS.STORES, this.stores);

    if (target) {
      this.logActivity(
        'Hapus Data Pelanggan / Toko',
        target.storeName,
        `Menghapus data pelanggan/toko ${target.storeName} (${target.city || target.kabupaten || '-'})`,
        'kurangi'
      );
      fetch(`/api/stores/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: this.buildSessionAuthHeaders(),
        credentials: 'same-origin'
      }).catch(err => console.warn('[Hostinger Stores] Hapus toko gagal disinkronkan:', err));
      this.dispatchMiddleware({
        entityType: 'store',
        action: 'delete',
        id,
        data: target,
        timestamp: new Date().toISOString()
      });
    }
    this.notify();
  }

  public setSupabaseConfig(config: SupabaseConfig) {
    this.supabaseConfig = config;
    this.saveToStorage(STORAGE_KEYS.SUPABASE_CONFIG, config);
  }

  // ==========================================
  // SALES ADMIN (ADMIN PENJUALAN) METHODS
  // ==========================================

  public getSalesOrders(): SalesOrder[] {
    return this.salesOrders;
  }

  public addSalesOrder(order: Omit<SalesOrder, 'id'>): SalesOrder {
    this.verifyDriverAccess('addSalesOrder');

    const newOrder: SalesOrder = {
      ...order,
      id: 'so-' + Math.random().toString(36).substring(2, 8)
    };
    this.salesOrders = [newOrder, ...this.salesOrders];
    this.saveToStorage(STORAGE_KEYS.SALES_ORDERS, this.salesOrders);
    return newOrder;
  }

  public updateSalesOrderStatus(id: string, status: SalesOrder['orderStatus']) {
    this.salesOrders = this.salesOrders.map(o => (o.id === id ? { ...o, orderStatus: status } : o));
    this.saveToStorage(STORAGE_KEYS.SALES_ORDERS, this.salesOrders);
  }

  public getAdminActivities(): AdminActivity[] {
    return this.adminActivities;
  }

  public addAdminActivity(activity: Omit<AdminActivity, 'id'>): AdminActivity {
    const newActivity: AdminActivity = {
      ...activity,
      id: 'act-' + Math.random().toString(36).substring(2, 8)
    };
    this.adminActivities = [newActivity, ...this.adminActivities];
    this.saveToStorage(STORAGE_KEYS.ADMIN_ACTIVITIES, this.adminActivities);
    return newActivity;
  }

  public updateAdminActivityStatus(id: string, status: AdminActivity['status']) {
    this.adminActivities = this.adminActivities.map(a => (a.id === id ? { ...a, status } : a));
    this.saveToStorage(STORAGE_KEYS.ADMIN_ACTIVITIES, this.adminActivities);
  }

  public getAdminSchedules(): AdminSchedule[] {
    return this.adminSchedules;
  }

  public addAdminSchedule(schedule: Omit<AdminSchedule, 'id'>): AdminSchedule {
    const newSchedule: AdminSchedule = {
      ...schedule,
      id: 'sch-' + Math.random().toString(36).substring(2, 8)
    };
    this.adminSchedules = [newSchedule, ...this.adminSchedules];
    this.saveToStorage(STORAGE_KEYS.ADMIN_SCHEDULES, this.adminSchedules);
    return newSchedule;
  }

  public updateAdminScheduleStatus(id: string, status: AdminSchedule['status']) {
    this.adminSchedules = this.adminSchedules.map(s => (s.id === id ? { ...s, status } : s));
    this.saveToStorage(STORAGE_KEYS.ADMIN_SCHEDULES, this.adminSchedules);
  }

  public getLoadingRecords(): LoadingDurationRecord[] {
    return this.loadingRecords;
  }

  public addLoadingRecord(record: Omit<LoadingDurationRecord, 'id'>): LoadingDurationRecord {
    const newRecord: LoadingDurationRecord = {
      ...record,
      id: 'load-' + Math.random().toString(36).substring(2, 8)
    };
    this.loadingRecords = [newRecord, ...this.loadingRecords];
    this.saveToStorage(STORAGE_KEYS.LOADING_RECORDS, this.loadingRecords);
    return newRecord;
  }

  public getSkillProfiles(): AdminSkillProfile[] {
    return this.skillProfiles;
  }

  public updateSkillProfile(id: string, updatedSkills: AdminSkillProfile['skills']) {
    this.skillProfiles = this.skillProfiles.map(p => {
      if (p.id === id) {
        const avgScore = Math.round(
          (updatedSkills.reduce((acc, s) => acc + s.level, 0) / (updatedSkills.length * 5)) * 100
        );
        return {
          ...p,
          skills: updatedSkills,
          overallScore: avgScore
        };
      }
      return p;
    });
    this.saveToStorage(STORAGE_KEYS.SKILL_PROFILES, this.skillProfiles);
  }

  public getJobdeskConfigs(): JobdeskConfig[] {
    return this.jobdeskConfigs;
  }

  private isSystemWebNoiseActivity(item: any): boolean {
    if (!item || typeof item !== 'object') return true;
    const action = String(item.action || '').trim().toLowerCase();
    const dept = String(item.department || '').trim().toLowerCase();
    const details = String(item.details || '').trim().toLowerCase();
    const target = String(item.target || '').trim().toLowerCase();
    const user = String(item.userFullName || '').trim().toLowerCase();

    if (
      action.includes('auto-sync') ||
      action.includes('smart fill') ||
      action.includes('penyeimbangan jeda') ||
      action.includes('broadcast alert sla') ||
      action.includes('middleware') ||
      dept.includes('sistem integrasi data') ||
      user.includes('middleware') ||
      user === 'guest' ||
      user.includes('belum login') ||
      details.includes('middleware otomatis') ||
      details.includes('smart fill mengeksekusi') ||
      /^perubahan pada jadwal sch-[a-z0-9]+$/i.test(details) ||
      /^schedule:\s*sch-/i.test(target)
    ) {
      return true;
    }
    return false;
  }

  private inferDataChangeType(action: string, details: string): 'tambah' | 'ubah' | 'kurangi' {
    const combined = `${action} ${details}`.toLowerCase();
    if (
      /\b(hapus|kurang|potong|nonaktif|tolak|reset|keluar|pemakaian|ganti komponen)\b/.test(combined)
    ) {
      return 'kurangi';
    }
    if (
      /\b(tambah|buat|input|upload|unggah|restock|registrasi|approval|disetujui|aktifkan)\b/.test(combined)
    ) {
      return 'tambah';
    }
    return 'ubah';
  }

  private sanitizeLoadedActivities(list: any[]): SystemActivity[] {
    if (!Array.isArray(list)) return [];
    const seen = new Set<string>();
    const result: SystemActivity[] = [];
    for (const raw of list) {
      if (this.isSystemWebNoiseActivity(raw)) continue;
      const id = String(raw.id || '').trim();
      if (!id || seen.has(id)) continue;
      seen.add(id);
      result.push({
        ...raw,
        changeType: raw.changeType || this.inferDataChangeType(raw.action || '', raw.details || '')
      });
      if (result.length >= 150) break;
    }
    return result;
  }

  public async hydrateSystemActivitiesFromServer(): Promise<void> {
    if (typeof fetch === 'undefined') return;
    try {
      const res = await fetch('/api/system-activities', {
        method: 'GET',
        headers: { Accept: 'application/json' },
        cache: 'no-store'
      });
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data?.activities)) {
        const merged = this.sanitizeLoadedActivities([...data.activities, ...this.systemActivities]);
        this.systemActivities = merged;
        this.saveToStorage('akk_system_activities_v1', this.systemActivities);
        this.notify();
      }
    } catch {
      // Ignore transient network errors
    }
  }

  public getSystemActivities(): SystemActivity[] {
    return this.sanitizeLoadedActivities(this.systemActivities);
  }

  public logActivity(
    action: string,
    target: string,
    details: string,
    changeType?: 'tambah' | 'ubah' | 'kurangi'
  ) {
    const activeUser = this.currentUser;
    const candidate = {
      action,
      target,
      details,
      userFullName: activeUser?.fullName || 'Super Admin',
      department: activeUser?.department || 'Manajemen & Direksi'
    };
    if (this.isSystemWebNoiseActivity(candidate)) {
      return;
    }

    const resolvedChangeType = changeType || this.inferDataChangeType(action, details);
    const newActivity: SystemActivity = {
      id: 'log-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 7),
      timestamp: new Date().toISOString(),
      userFullName: activeUser?.fullName && activeUser.id !== 'guest' ? activeUser.fullName : 'Super Admin',
      userEmail: activeUser?.email && activeUser.id !== 'guest' ? activeUser.email : 'akkoperasional60@gmail.com',
      userRole: activeUser?.role && activeUser.id !== 'guest' ? activeUser.role : 'super_admin',
      department: activeUser?.department && activeUser.id !== 'guest' ? activeUser.department : 'Manajemen & Direksi',
      action,
      target,
      details,
      changeType: resolvedChangeType
    };
    this.systemActivities = this.sanitizeLoadedActivities([newActivity, ...this.systemActivities]).slice(0, 150);
    this.saveToStorage('akk_system_activities_v1', this.systemActivities);

    if (typeof fetch !== 'undefined') {
      fetch('/api/system-activities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ activity: newActivity })
      }).catch(() => {});
    }

    this.notify();
  }

  public updateJobdeskConfig(id: string, updated: Partial<JobdeskConfig>) {
    this.jobdeskConfigs = this.jobdeskConfigs.map(j => (j.id === id ? { ...j, ...updated } : j));
    this.saveToStorage(STORAGE_KEYS.JOBDESK_CONFIGS, this.jobdeskConfigs);
  }

  // ==========================================
  // SPARE PARTS & ROUTINE MAINTENANCE METHODS
  // ==========================================
  public getSpareParts(): SparePart[] {
    return [...this.spareParts];
  }

  public addSparePart(part: Omit<SparePart, 'id'>): SparePart {
    const newPart: SparePart = {
      ...part,
      id: 'sp-' + Math.random().toString(36).substring(2, 9)
    };
    this.spareParts = [newPart, ...this.spareParts];
    this.saveToStorage(STORAGE_KEYS.SPARE_PARTS, this.spareParts);
    this.logActivity(
      'Tambah Sparepart Baru',
      newPart.name,
      `Stok Awal: ${newPart.stock} ${newPart.unit} (Lokasi: ${newPart.storageLocation})`,
      'tambah'
    );
    this.notify();
    return newPart;
  }

  public updateSparePart(id: string, updated: Partial<SparePart>): void {
    const existing = this.spareParts.find(p => p.id === id);
    this.spareParts = this.spareParts.map(p => p.id === id ? { ...p, ...updated } : p);
    this.saveToStorage(STORAGE_KEYS.SPARE_PARTS, this.spareParts);
    if (existing) {
      this.logActivity(
        'Ubah Data Sparepart',
        updated.name || existing.name,
        `Merubah data inventaris sparepart ${updated.name || existing.name}`,
        'ubah'
      );
    }
    this.notify();
  }

  public deleteSparePart(id: string): void {
    const part = this.spareParts.find(p => p.id === id);
    this.spareParts = this.spareParts.filter(p => p.id !== id);
    this.saveToStorage(STORAGE_KEYS.SPARE_PARTS, this.spareParts);
    if (part) {
      this.logActivity(
        'Hapus Master Sparepart',
        part.name,
        `Part ID: ${id} dihapus dari master inventaris`
      );
    }
    this.notify();
  }

  public restockSparePart(id: string, amount: number, notes?: string): void {
    const part = this.spareParts.find(p => p.id === id);
    if (!part) return;
    const newStock = part.stock + amount;
    const today = new Date().toISOString().substring(0, 10);
    this.spareParts = this.spareParts.map(p => 
      p.id === id ? { ...p, stock: newStock, lastRestockDate: today, notes: notes || p.notes } : p
    );
    this.saveToStorage(STORAGE_KEYS.SPARE_PARTS, this.spareParts);
    this.logActivity(
      'Restock Sparepart Masuk',
      part.name,
      `Penambahan +${amount} ${part.unit} (Total kini: ${newStock} ${part.unit}). Catatan: ${notes || '-'}`
    );
    this.notify();
  }

  public getSparePartUsages(fleetId?: string): SparePartUsage[] {
    if (fleetId) {
      return this.sparePartUsages.filter(u => u.fleetId === fleetId);
    }
    return [...this.sparePartUsages];
  }

  public recordSparePartUsage(usage: Omit<SparePartUsage, 'id'>): SparePartUsage {
    const newUsage: SparePartUsage = {
      ...usage,
      id: 'usg-' + Math.random().toString(36).substring(2, 9)
    };

    // 1. Simpan ke daftar riwayat pemakaian
    this.sparePartUsages = [newUsage, ...this.sparePartUsages];
    this.saveToStorage(STORAGE_KEYS.SPARE_PART_USAGES, this.sparePartUsages);

    // 2. Potong stok otomatis di master inventaris gudang jika partId cocok
    if (usage.partId) {
      this.spareParts = this.spareParts.map(p => {
        if (p.id === usage.partId) {
          const reducedStock = Math.max(0, p.stock - usage.quantity);
          return { ...p, stock: reducedStock };
        }
        return p;
      });
      this.saveToStorage(STORAGE_KEYS.SPARE_PARTS, this.spareParts);
    }

    // 3. Sinkronisasi tanggal servis terakhir pada armada
    if (usage.fleetId) {
      this.fleets = this.fleets.map(f => {
        if (f.id === usage.fleetId) {
          return {
            ...f,
            lastMaintenance: usage.replacementDate,
            odometerKm: Math.max(f.odometerKm || 0, usage.odometerKm)
          };
        }
        return f;
      });
      this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);
    }

    // 4. Catat ke audit log aktivitas sistem
    this.logActivity(
      'Ganti Komponen Rutin',
      `${usage.plateNumber} (${usage.initialCode || 'Armada'})`,
      `Penggantian ${usage.quantity} ${usage.unit} ${usage.partName} pada ${usage.odometerKm} KM oleh ${usage.mechanicOrWorkshop}`
    );

    this.notify();
    return newUsage;
  }

  public deleteSparePartUsage(id: string): void {
    const item = this.sparePartUsages.find(u => u.id === id);
    this.sparePartUsages = this.sparePartUsages.filter(u => u.id !== id);
    this.saveToStorage(STORAGE_KEYS.SPARE_PART_USAGES, this.sparePartUsages);
    if (item) {
      this.logActivity(
        'Hapus Log Ganti Sparepart',
        item.plateNumber,
        `Catatan penggantian ${item.partName} dihapus`
      );
    }
    this.notify();
  }

  public getFleetRoutineComponentsStatus(fleetId: string) {
    const usages = this.sparePartUsages.filter(u => u.fleetId === fleetId);
    const fleet = this.fleets.find(f => f.id === fleetId);
    const currentKm = fleet?.odometerKm || 50000;
    const now = new Date().getTime();

    // Helper untuk cari penggantian terakhir per kategori
    const getLatest = (cat: SparePartCategory) => {
      const match = usages
        .filter(u => u.category === cat)
        .sort((a, b) => new Date(b.replacementDate).getTime() - new Date(a.replacementDate).getTime())[0];
      return match;
    };

    const latestOil = getLatest('oli');
    const latestTire = getLatest('ban');
    const latestBattery = getLatest('aki');
    const latestFilter = getLatest('filter');

    const getLatestTireByPosition = (positionKeyword: string) => {
      const kw = positionKeyword.toLowerCase();
      const specificMatch = usages
        .filter(u => {
          if (u.category !== 'ban') return false;
          const text = `${u.partName || ''} ${u.notes || ''}`.toLowerCase();
          return text.includes(kw);
        })
        .sort((a, b) => new Date(b.replacementDate).getTime() - new Date(a.replacementDate).getTime())[0];
      if (specificMatch) return specificMatch;

      // Fallback: if a general tire usage exists without any position keyword, apply it
      const generalMatch = usages
        .filter(u => {
          if (u.category !== 'ban') return false;
          const text = `${u.partName || ''} ${u.notes || ''}`.toLowerCase();
          return (
            !text.includes('depan kanan') &&
            !text.includes('depan kiri') &&
            !text.includes('belakang kanan') &&
            !text.includes('belakang kiri')
          );
        })
        .sort((a, b) => new Date(b.replacementDate).getTime() - new Date(a.replacementDate).getTime())[0];
      return generalMatch;
    };

    const latestTireFR = getLatestTireByPosition('depan kanan');
    const latestTireFL = getLatestTireByPosition('depan kiri');
    const latestTireRR = getLatestTireByPosition('belakang kanan');
    const latestTireRL = getLatestTireByPosition('belakang kiri');

    const calculateStatus = (usage: SparePartUsage | undefined, defaultDays: number, defaultKm: number) => {
      if (!usage) {
        return {
          status: 'warning' as const,
          label: 'Perlu Cek',
          lastDate: '-',
          lastKm: 0,
          nextTarget: `${defaultKm.toLocaleString('id-ID')} KM`
        };
      }

      const diffDays = Math.floor((now - new Date(usage.replacementDate).getTime()) / (1000 * 60 * 60 * 24));
      const targetKm = usage.nextReplacementKm || (usage.odometerKm + defaultKm);
      const remainingKm = targetKm - currentKm;

      if (remainingKm <= 0 || diffDays > defaultDays) {
        return {
          status: 'urgent' as const,
          label: 'Wajib Ganti Segera',
          lastDate: usage.replacementDate,
          lastKm: usage.odometerKm,
          nextTarget: `${targetKm.toLocaleString('id-ID')} KM`,
          detail: `Sudah lewat ${Math.abs(remainingKm).toLocaleString('id-ID')} KM (${diffDays} hari lalu)`
        };
      }

      if (remainingKm <= 1500 || diffDays >= defaultDays * 0.8) {
        return {
          status: 'warning' as const,
          label: 'Segera Jadwalkan',
          lastDate: usage.replacementDate,
          lastKm: usage.odometerKm,
          nextTarget: `${targetKm.toLocaleString('id-ID')} KM`,
          detail: `Sisa ${remainingKm.toLocaleString('id-ID')} KM (${diffDays} hari pakai)`
        };
      }

      return {
        status: 'good' as const,
        label: 'Kondisi Prima',
        lastDate: usage.replacementDate,
        lastKm: usage.odometerKm,
        nextTarget: `${targetKm.toLocaleString('id-ID')} KM`,
        detail: `Pemakaian ${diffDays} hari (${remainingKm.toLocaleString('id-ID')} KM lagi)`
      };
    };

    return {
      fleet,
      oil: {
        latest: latestOil,
        ...calculateStatus(latestOil, 90, 10000) // Oli: 3 bulan / 10.000 KM
      },
      tire: {
        latest: latestTire,
        ...calculateStatus(latestTire, 365, 50000) // Ban: 1 tahun / 50.000 KM
      },
      tireFrontRight: {
        positionLabel: 'Ban Armada Depan Kanan',
        latest: latestTireFR,
        ...calculateStatus(latestTireFR, 365, 50000)
      },
      tireFrontLeft: {
        positionLabel: 'Ban Armada Depan Kiri',
        latest: latestTireFL,
        ...calculateStatus(latestTireFL, 365, 50000)
      },
      tireRearRight: {
        positionLabel: 'Ban Armada Belakang Kanan',
        latest: latestTireRR,
        ...calculateStatus(latestTireRR, 365, 50000)
      },
      tireRearLeft: {
        positionLabel: 'Ban Armada Belakang Kiri',
        latest: latestTireRL,
        ...calculateStatus(latestTireRL, 365, 50000)
      },
      battery: {
        latest: latestBattery,
        ...calculateStatus(latestBattery, 540, 80000) // Aki: 1.5 tahun / 80.000 KM
      },
      filter: {
        latest: latestFilter,
        ...calculateStatus(latestFilter, 90, 10000)
      }
    };
  }

  public resetToDefault() {
    localStorage.removeItem(STORAGE_KEYS.FLEETS);
    localStorage.removeItem(STORAGE_KEYS.CREWS);
    localStorage.removeItem(STORAGE_KEYS.STORES);
    localStorage.removeItem(STORAGE_KEYS.SCHEDULES);
    localStorage.removeItem(STORAGE_KEYS.SALES_ORDERS);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_ACTIVITIES);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_SCHEDULES);
    localStorage.removeItem(STORAGE_KEYS.LOADING_RECORDS);
    localStorage.removeItem(STORAGE_KEYS.SKILL_PROFILES);
    localStorage.removeItem(STORAGE_KEYS.JOBDESK_CONFIGS);
    localStorage.removeItem(STORAGE_KEYS.SPARE_PARTS);
    localStorage.removeItem(STORAGE_KEYS.SPARE_PART_USAGES);
    localStorage.removeItem(STORAGE_KEYS.FUEL_LOGS);
    this.fleets = [...INITIAL_FLEETS];
    this.crews = [...INITIAL_CREWS];
    this.stores = [...INITIAL_STORES];
    this.schedules = [...INITIAL_SCHEDULES];
    this.salesOrders = [...INITIAL_SALES_ORDERS];
    this.adminActivities = [...INITIAL_ADMIN_ACTIVITIES];
    this.adminSchedules = [...INITIAL_ADMIN_SCHEDULES];
    this.loadingRecords = [...INITIAL_LOADING_RECORDS];
    this.skillProfiles = [...INITIAL_SKILL_PROFILES];
    this.jobdeskConfigs = [...INITIAL_JOBDESK_CONFIGS];
    this.spareParts = [...INITIAL_SPARE_PARTS];
    this.sparePartUsages = [...INITIAL_SPARE_PART_USAGES];
    this.fuelLogs = [...INITIAL_FUEL_LOGS];
    this.saveToStorage(STORAGE_KEYS.FLEETS, this.fleets);
    this.saveToStorage(STORAGE_KEYS.CREWS, this.crews);
    this.saveToStorage(STORAGE_KEYS.STORES, this.stores);
    this.saveToStorage(STORAGE_KEYS.SCHEDULES, this.schedules);
    this.saveToStorage(STORAGE_KEYS.SALES_ORDERS, this.salesOrders);
    this.saveToStorage(STORAGE_KEYS.ADMIN_ACTIVITIES, this.adminActivities);
    this.saveToStorage(STORAGE_KEYS.ADMIN_SCHEDULES, this.adminSchedules);
    this.saveToStorage(STORAGE_KEYS.LOADING_RECORDS, this.loadingRecords);
    this.saveToStorage(STORAGE_KEYS.SKILL_PROFILES, this.skillProfiles);
    this.saveToStorage(STORAGE_KEYS.JOBDESK_CONFIGS, this.jobdeskConfigs);
    this.saveToStorage(STORAGE_KEYS.SPARE_PARTS, this.spareParts);
    this.saveToStorage(STORAGE_KEYS.SPARE_PART_USAGES, this.sparePartUsages);
    this.saveToStorage(STORAGE_KEYS.FUEL_LOGS, this.fuelLogs);
  }

  // ==========================================
  // MANAJEMEN EFISIENSI BBM ARMADA (FUEL STORE - LANGSUNG MYSQL HOSTINGER)
  // ==========================================
  public getFuelLogs(): FuelLog[] {
    return [...this.fuelLogs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  public getFuelLogById(id: string): FuelLog | undefined {
    return this.fuelLogs.find(log => log.id === id);
  }

  public async refreshFuelLogsFromServer(): Promise<{ success: boolean; source?: string; count?: number; error?: string }> {
    try {
      const res = await fetch('/api/fuel-logs', {
        method: 'GET',
        credentials: 'same-origin',
        headers: this.buildSessionAuthHeaders({ Accept: 'application/json' })
      });
      const payload = await res.json().catch(() => ({}));
      if (!res.ok || payload?.success === false) {
        return {
          success: false,
          error: payload?.error || `Gagal memuat data BBM dari server (${res.status})`
        };
      }
      if (Array.isArray(payload?.data)) {
        const serverLogs = (payload.data as FuelLog[]).filter(
          l => l && l.id && !this.pendingFuelLogDeletes.has(l.id)
        );
        this.fuelLogs = serverLogs;
        this.notify();
        return {
          success: true,
          source: payload.source,
          count: serverLogs.length
        };
      }
      return { success: true, source: payload?.source, count: this.fuelLogs.length };
    } catch (err: any) {
      return {
        success: false,
        error: err?.message || 'Tidak dapat terhubung ke server database BBM'
      };
    }
  }

  private buildComputedNewFuelLog(
    data: Omit<FuelLog, 'id' | 'createdAt' | 'ratioKmPerLiter' | 'costPerKm' | 'efficiencyStatus' | 'totalCost' | 'distanceKm' | 'targetRatio'>
  ): { newLog: FuelLog; fleet?: Fleet } {
    const cleanTargetPlate = String(data.plateNumber || '').replace(/\s+/g, '').toUpperCase();
    const fleet =
      this.fleets.find(f => f.id === data.fleetId) ||
      (cleanTargetPlate
        ? this.fleets.find(f => String(f.plateNumber || '').replace(/\s+/g, '').toUpperCase() === cleanTargetPlate)
        : undefined);
    const vehicleType = data.vehicleType || fleet?.vehicleType || 'Engkel Long';
    const targetConfig = FUEL_TARGET_RATIOS[vehicleType] || { target: 7.5, minAcceptable: 6.4, label: '7.5 KM / L' };
    const targetRatio = targetConfig.target;

    const distanceKm = Math.max(0, data.endOdometerKm - data.startOdometerKm);
    const totalCost = Math.round(data.liters * data.costPerLiter);
    const ratioKmPerLiter = data.liters > 0 ? Number((distanceKm / data.liters).toFixed(2)) : 0;
    const literPerKm = distanceKm > 0 ? Number((data.liters / distanceKm).toFixed(4)) : 0;
    const literPer100Km = distanceKm > 0 ? Number(((data.liters / distanceKm) * 100).toFixed(2)) : 0;
    const costPerKm = distanceKm > 0 ? Math.round(totalCost / distanceKm) : 0;

    let efficiencyStatus: EfficiencyStatus = 'Efisien / Normal';
    if (ratioKmPerLiter >= targetRatio * 1.05) {
      efficiencyStatus = 'Sangat Efisien';
    } else if (ratioKmPerLiter >= targetRatio * 0.90) {
      efficiencyStatus = 'Efisien / Normal';
    } else if (ratioKmPerLiter >= targetRatio * 0.75) {
      efficiencyStatus = 'Boros';
    } else {
      efficiencyStatus = 'Kritis / Potensi Anomali';
    }

    const resolvedFleetId = fleet?.id || data.fleetId;
    const newLog: FuelLog = {
      ...data,
      fleetId: resolvedFleetId,
      id: `fuel-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 5)}`,
      vehicleType,
      targetRatio,
      distanceKm,
      totalCost,
      ratioKmPerLiter,
      literPerKm,
      literPer100Km,
      costPerKm,
      efficiencyStatus,
      createdAt: new Date().toISOString(),
      verifiedBy: data.verifiedBy || this.currentUser.fullName
    };
    return { newLog, fleet };
  }

  private buildComputedUpdatedFuelLog(id: string, updates: Partial<FuelLog>): FuelLog | null {
    const existing = this.fuelLogs.find(l => l.id === id);
    if (!existing) return null;

    const merged = { ...existing, ...updates };
    const cleanTargetPlate = String(merged.plateNumber || '').replace(/\s+/g, '').toUpperCase();
    const fleet =
      this.fleets.find(f => f.id === merged.fleetId) ||
      (cleanTargetPlate
        ? this.fleets.find(f => String(f.plateNumber || '').replace(/\s+/g, '').toUpperCase() === cleanTargetPlate)
        : undefined);
    const vehicleType = merged.vehicleType || fleet?.vehicleType || 'Engkel Long';
    const targetConfig = FUEL_TARGET_RATIOS[vehicleType] || { target: 7.5, minAcceptable: 6.4, label: '7.5 KM / L' };
    const targetRatio = targetConfig.target;

    const distanceKm = Math.max(0, merged.endOdometerKm - merged.startOdometerKm);
    const totalCost = Math.round(merged.liters * merged.costPerLiter);
    const ratioKmPerLiter = merged.liters > 0 ? Number((distanceKm / merged.liters).toFixed(2)) : 0;
    const literPerKm = distanceKm > 0 ? Number((merged.liters / distanceKm).toFixed(4)) : 0;
    const literPer100Km = distanceKm > 0 ? Number(((merged.liters / distanceKm) * 100).toFixed(2)) : 0;
    const costPerKm = distanceKm > 0 ? Math.round(totalCost / distanceKm) : 0;

    let efficiencyStatus: EfficiencyStatus = 'Efisien / Normal';
    if (ratioKmPerLiter >= targetRatio * 1.05) {
      efficiencyStatus = 'Sangat Efisien';
    } else if (ratioKmPerLiter >= targetRatio * 0.90) {
      efficiencyStatus = 'Efisien / Normal';
    } else if (ratioKmPerLiter >= targetRatio * 0.75) {
      efficiencyStatus = 'Boros';
    } else {
      efficiencyStatus = 'Kritis / Potensi Anomali';
    }

    return {
      ...merged,
      fleetId: fleet?.id || merged.fleetId,
      targetRatio,
      distanceKm,
      totalCost,
      ratioKmPerLiter,
      literPerKm,
      literPer100Km,
      costPerKm,
      efficiencyStatus
    };
  }

  public async addFuelLogAsync(
    data: Omit<FuelLog, 'id' | 'createdAt' | 'ratioKmPerLiter' | 'costPerKm' | 'efficiencyStatus' | 'totalCost' | 'distanceKm' | 'targetRatio'>
  ): Promise<FuelLog> {
    const { newLog, fleet } = this.buildComputedNewFuelLog(data);
    const res = await fetch('/api/fuel-logs', {
      method: 'POST',
      credentials: 'same-origin',
      headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(newLog)
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || json?.success === false) {
      throw new Error(json?.error || `Gagal menyimpan catatan BBM ke MySQL (${res.status})`);
    }

    const savedLog: FuelLog = json?.data ? ({ ...newLog, ...json.data } as FuelLog) : newLog;
    this.pendingFuelLogDeletes.delete(savedLog.id);
    this.pendingFuelLogUpserts.delete(savedLog.id);
    this.fuelLogs = [savedLog, ...this.fuelLogs.filter(l => l.id !== savedLog.id)];

    if (fleet && data.endOdometerKm > (fleet.odometerKm || 0)) {
      this.fleets = this.fleets.map(f =>
        f.id === fleet.id ? { ...f, odometerKm: data.endOdometerKm } : f
      );
      this.cachedFleets = null;
      updateFleetInSupabase(fleet.id, { odometerKm: data.endOdometerKm, plateNumber: fleet.plateNumber }).catch(() => {});
    }

    this.logActivity(
      'Pencatatan BBM Armada',
      `${savedLog.plateNumber} (${savedLog.initialCode || 'Armada'})`,
      `Pengisian ${savedLog.liters} L ${savedLog.fuelType} (Rp ${savedLog.totalCost.toLocaleString('id-ID')}) - Rasio: ${savedLog.ratioKmPerLiter} KM/L [${savedLog.efficiencyStatus}]`,
      'tambah'
    );

    this.notify();
    return savedLog;
  }

  public async updateFuelLogAsync(id: string, updates: Partial<FuelLog>): Promise<FuelLog> {
    const updatedLog = this.buildComputedUpdatedFuelLog(id, updates);
    if (!updatedLog) {
      throw new Error('Data catatan BBM tidak ditemukan.');
    }

    const res = await fetch(`/api/fuel-logs/${encodeURIComponent(id)}`, {
      method: 'PUT',
      credentials: 'same-origin',
      headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(updatedLog)
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || json?.success === false) {
      throw new Error(json?.error || `Gagal memperbarui catatan BBM di MySQL (${res.status})`);
    }

    const savedLog: FuelLog = json?.data ? ({ ...updatedLog, ...json.data } as FuelLog) : updatedLog;
    this.pendingFuelLogDeletes.delete(id);
    this.pendingFuelLogUpserts.delete(id);
    this.fuelLogs = this.fuelLogs.map(l => (l.id === id ? savedLog : l));

    this.logActivity(
      'Edit Log Pengisian BBM',
      savedLog.plateNumber,
      `Pembaruan catatan BBM ID: ${id}`,
      'ubah'
    );

    this.notify();
    return savedLog;
  }

  public async deleteFuelLogAsync(id: string): Promise<void> {
    const item = this.fuelLogs.find(l => l.id === id);
    const res = await fetch(`/api/fuel-logs/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      credentials: 'same-origin',
      headers: this.buildSessionAuthHeaders()
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || json?.success === false) {
      throw new Error(json?.error || `Gagal menghapus catatan BBM dari MySQL (${res.status})`);
    }

    this.fuelLogs = this.fuelLogs.filter(l => l.id !== id);
    this.pendingFuelLogUpserts.delete(id);
    this.pendingFuelLogDeletes.delete(id);

    if (item) {
      this.logActivity(
        'Hapus Log Pengisian BBM',
        item.plateNumber,
        `Catatan pengisian BBM ${item.liters} L pada tanggal ${item.date} dihapus`,
        'kurangi'
      );
    }
    this.notify();
  }

  public addFuelLog(data: Omit<FuelLog, 'id' | 'createdAt' | 'ratioKmPerLiter' | 'costPerKm' | 'efficiencyStatus' | 'totalCost' | 'distanceKm' | 'targetRatio'>): FuelLog {
    const { newLog, fleet } = this.buildComputedNewFuelLog(data);

    this.fuelLogs = [newLog, ...this.fuelLogs];
    this.pendingFuelLogDeletes.delete(newLog.id);
    this.pendingFuelLogUpserts.set(newLog.id, newLog);
    void this.syncFuelLogToServer('POST', '/api/fuel-logs', newLog);

    if (fleet && data.endOdometerKm > (fleet.odometerKm || 0)) {
      this.fleets = this.fleets.map(f =>
        f.id === fleet.id ? { ...f, odometerKm: data.endOdometerKm } : f
      );
      this.cachedFleets = null;
      updateFleetInSupabase(fleet.id, { odometerKm: data.endOdometerKm, plateNumber: fleet.plateNumber }).catch(() => {});
    }

    this.logActivity(
      'Pencatatan BBM Armada',
      `${newLog.plateNumber} (${newLog.initialCode || 'Armada'})`,
      `Pengisian ${newLog.liters} L ${newLog.fuelType} (Rp ${newLog.totalCost.toLocaleString('id-ID')}) - Rasio: ${newLog.ratioKmPerLiter} KM/L [${newLog.efficiencyStatus}]`,
      'tambah'
    );

    this.notify();
    return newLog;
  }

  public updateFuelLog(id: string, updates: Partial<FuelLog>) {
    const updatedLog = this.buildComputedUpdatedFuelLog(id, updates);
    if (!updatedLog) return;

    this.fuelLogs = this.fuelLogs.map(l => l.id === id ? updatedLog : l);
    this.pendingFuelLogDeletes.delete(id);
    this.pendingFuelLogUpserts.set(id, updatedLog);
    void this.syncFuelLogToServer('PUT', `/api/fuel-logs/${encodeURIComponent(id)}`, updatedLog);

    this.logActivity(
      'Edit Log Pengisian BBM',
      updatedLog.plateNumber,
      `Pembaruan catatan BBM ID: ${id}`,
      'ubah'
    );

    this.notify();
  }

  public deleteFuelLog(id: string) {
    const item = this.fuelLogs.find(l => l.id === id);
    this.fuelLogs = this.fuelLogs.filter(l => l.id !== id);
    this.pendingFuelLogUpserts.delete(id);
    this.pendingFuelLogDeletes.add(id);
    void this.deleteFuelLogOnServer(id);

    if (item) {
      this.logActivity(
        'Hapus Log Pengisian BBM',
        item.plateNumber,
        `Catatan pengisian BBM ${item.liters} L pada tanggal ${item.date} dihapus`,
        'kurangi'
      );
    }
    this.notify();
  }

  private async syncFuelLogToServer(method: 'POST' | 'PUT', url: string, log: FuelLog, attempt = 0): Promise<void> {
    try {
      const res = await fetch(url, {
        method,
        credentials: 'same-origin',
        headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(log)
      });
      if (res.ok) {
        const json = await res.json().catch(() => ({}));
        if (json?.success !== false) {
          this.pendingFuelLogUpserts.delete(log.id);
          return;
        }
      }
      if (attempt < 3 && (res.status === 429 || res.status >= 500 || res.status === 0)) {
        setTimeout(() => {
          void this.syncFuelLogToServer(method, url, log, attempt + 1);
        }, 1500 * (attempt + 1));
      } else {
        console.warn('[FuelLogs] Gagal sinkron ke server:', res.status);
      }
    } catch (err) {
      if (attempt < 3) {
        setTimeout(() => {
          void this.syncFuelLogToServer(method, url, log, attempt + 1);
        }, 1500 * (attempt + 1));
      } else {
        console.warn('[FuelLogs] Gagal simpan ke server:', err);
      }
    }
  }

  private async deleteFuelLogOnServer(id: string, attempt = 0): Promise<void> {
    try {
      const res = await fetch(`/api/fuel-logs/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        credentials: 'same-origin',
        headers: this.buildSessionAuthHeaders()
      });
      if (res.ok) {
        this.pendingFuelLogDeletes.delete(id);
        return;
      }
      if (attempt < 3 && (res.status === 429 || res.status >= 500)) {
        setTimeout(() => {
          void this.deleteFuelLogOnServer(id, attempt + 1);
        }, 1500 * (attempt + 1));
      }
    } catch {
      if (attempt < 3) {
        setTimeout(() => {
          void this.deleteFuelLogOnServer(id, attempt + 1);
        }, 1500 * (attempt + 1));
      }
    }
  }

  public getFleetFuelSummary(): FleetFuelSummary[] {
    const orderedFleets = sortFleetsByCanonicalOrder(this.fleets);
    return orderedFleets.map(fleet => {
      const logs = this.fuelLogs.filter(
        l => l.fleetId === fleet.id || (l.plateNumber && l.plateNumber.toUpperCase() === fleet.plateNumber.toUpperCase())
      );
      const totalLogs = logs.length;
      const totalLiters = logs.reduce((acc, l) => acc + l.liters, 0);
      const totalCost = logs.reduce((acc, l) => acc + l.totalCost, 0);
      const totalDistanceKm = logs.reduce((acc, l) => acc + l.distanceKm, 0);

      const targetConfig = FUEL_TARGET_RATIOS[fleet.vehicleType] || { target: 7.5, minAcceptable: 6.4, label: '7.5 KM / L' };
      const targetRatio = targetConfig.target;
      const avgKmPerLiter = totalLiters > 0 && totalDistanceKm > 0 ? Number((totalDistanceKm / totalLiters).toFixed(2)) : 0;

      // Rata-rata Konsumsi Liter per Kilometer (0 jika belum ada data input BBM)
      const avgLiterPerKm = totalDistanceKm > 0 && totalLiters > 0 ? Number((totalLiters / totalDistanceKm).toFixed(4)) : 0;
      const avgLiterPer100Km = totalDistanceKm > 0 && totalLiters > 0 ? Number(((totalLiters / totalDistanceKm) * 100).toFixed(2)) : 0;
      const targetLiterPerKm = targetRatio > 0 ? Number((1 / targetRatio).toFixed(4)) : 0;
      const targetLiterPer100Km = targetRatio > 0 ? Number((100 / targetRatio).toFixed(2)) : 0;

      const avgCostPerKm = totalDistanceKm > 0 ? Math.round(totalCost / totalDistanceKm) : 0;
      const efficiencyScore = totalDistanceKm > 0 && targetRatio > 0 ? Math.round((avgKmPerLiter / targetRatio) * 100) : 0;
      const anomaliesCount = logs.filter(l => l.efficiencyStatus === 'Boros' || l.efficiencyStatus === 'Kritis / Potensi Anomali').length;

      let status: EfficiencyStatus = 'Efisien / Normal';
      if (totalLogs === 0 || totalDistanceKm === 0) {
        status = 'Efisien / Normal';
      } else if (efficiencyScore >= 105) {
        status = 'Sangat Efisien';
      } else if (efficiencyScore >= 90) {
        status = 'Efisien / Normal';
      } else if (efficiencyScore >= 75) {
        status = 'Boros';
      } else {
        status = 'Kritis / Potensi Anomali';
      }

      return {
        fleetId: fleet.id,
        plateNumber: fleet.plateNumber,
        initialCode: fleet.initialCode,
        vehicleType: fleet.vehicleType,
        totalLogs,
        totalLiters,
        totalCost,
        totalDistanceKm,
        avgKmPerLiter,
        avgLiterPerKm,
        avgLiterPer100Km,
        targetRatio,
        targetLiterPerKm,
        targetLiterPer100Km,
        avgCostPerKm,
        efficiencyScore,
        status,
        anomaliesCount
      };
    });
  }

  public getDriverFuelScores(): DriverFuelScore[] {
    const driverMap = new Map<string, {
      driverId: string;
      driverName: string;
      logs: FuelLog[];
    }>();

    this.fuelLogs.forEach(log => {
      const key = log.driverName || 'Driver Tidak Terdaftar';
      if (!driverMap.has(key)) {
        driverMap.set(key, {
          driverId: log.driverId || key,
          driverName: key,
          logs: []
        });
      }
      driverMap.get(key)!.logs.push(log);
    });

    const scores: DriverFuelScore[] = Array.from(driverMap.values()).map(item => {
      const totalTrips = item.logs.length;
      const totalDistanceKm = item.logs.reduce((acc, l) => acc + l.distanceKm, 0);
      const totalLiters = item.logs.reduce((acc, l) => acc + l.liters, 0);
      const avgKmPerLiter = totalLiters > 0 ? Number((totalDistanceKm / totalLiters).toFixed(2)) : 0;

      const avgEfficiencyRatio = item.logs.reduce((acc, l) => acc + (l.ratioKmPerLiter / (l.targetRatio || 7.5)), 0) / (totalTrips || 1);
      const ecoDrivingScore = Math.min(100, Math.max(40, Math.round(avgEfficiencyRatio * 90)));

      let badge: 'Master Eco-Driver' | 'Driver Efisien' | 'Perlu Pembinaan' = 'Driver Efisien';
      let recommendation = 'Menjaga kecepatan stabil dan pola perpindahan gigi yang tepat.';

      if (ecoDrivingScore >= 90) {
        badge = 'Master Eco-Driver';
        recommendation = 'Pengemudi teladan dengan akselerasi halus, pengereman terencana, dan efisiensi BBM prima.';
      } else if (ecoDrivingScore < 75) {
        badge = 'Perlu Pembinaan';
        recommendation = 'Perlu evaluasi pola idling berlebih saat antre muat dan hindari akselerasi agresif di tanjakan.';
      }

      return {
        driverId: item.driverId,
        driverName: item.driverName,
        totalTrips,
        totalDistanceKm,
        totalLiters,
        avgKmPerLiter,
        ecoDrivingScore,
        ranking: 0,
        badge,
        recommendation
      };
    });

    scores.sort((a, b) => b.ecoDrivingScore - a.ecoDrivingScore);
    scores.forEach((s, idx) => {
      s.ranking = idx + 1;
    });

    return scores;
  }

  public getFuelKPISummary() {
    const totalLiters = this.fuelLogs.reduce((acc, l) => acc + l.liters, 0);
    const totalCost = this.fuelLogs.reduce((acc, l) => acc + l.totalCost, 0);
    const totalDistanceKm = this.fuelLogs.reduce((acc, l) => acc + l.distanceKm, 0);
    const overallAvgKmPerLiter = totalLiters > 0 ? Number((totalDistanceKm / totalLiters).toFixed(2)) : 0;
    const overallAvgLiterPerKm = totalDistanceKm > 0 ? Number((totalLiters / totalDistanceKm).toFixed(4)) : 0;
    const overallAvgLiterPer100Km = totalDistanceKm > 0 ? Number(((totalLiters / totalDistanceKm) * 100).toFixed(2)) : 0;
    const overallAvgCostPerKm = totalDistanceKm > 0 ? Math.round(totalCost / totalDistanceKm) : 0;
    const totalAnomalies = this.fuelLogs.filter(l => l.efficiencyStatus === 'Boros' || l.efficiencyStatus === 'Kritis / Potensi Anomali').length;

    const fleetSummaries = this.getFleetFuelSummary();
    const sortedFleets = [...fleetSummaries].sort((a, b) => b.efficiencyScore - a.efficiencyScore);
    const topFleet = sortedFleets[0];
    const leastFleet = sortedFleets[sortedFleets.length - 1];

    const driverScores = this.getDriverFuelScores();
    const topDriver = driverScores[0];

    return {
      totalLiters,
      totalCost,
      totalDistanceKm,
      overallAvgKmPerLiter,
      overallAvgLiterPerKm,
      overallAvgLiterPer100Km,
      overallAvgCostPerKm,
      totalAnomalies,
      topFleet,
      leastFleet,
      topDriver,
      totalRecords: this.fuelLogs.length
    };
  }

  // Swap Shift Methods
  private swapShiftRequests: SwapShiftRequest[] = [];

  public getSwapShiftRequests(): SwapShiftRequest[] {
    return [...this.swapShiftRequests];
  }

  public submitSwapShiftRequest(req: Omit<SwapShiftRequest, 'id' | 'status' | 'requestedAt'>): SwapShiftRequest {
    const newReq: SwapShiftRequest = {
      ...req,
      id: 'swp-' + Math.random().toString(36).substring(2, 9),
      status: 'pending',
      requestedAt: new Date().toISOString()
    };
    this.swapShiftRequests = [newReq, ...this.swapShiftRequests];
    // Normally save to storage here if persistent
    this.notify();
    return newReq;
  }

  // ==========================================
  // TIRE WEAR PREDICTION (PREDIKSI KEAUSAN BAN)
  // Berdasarkan total jarak tempuh harian armada dari Tracksolid
  // ==========================================
  public getFleetTireWearPredictions(): FleetTireWearPrediction[] {
    const devices = this.getDevices();
    const tireUsages = this.sparePartUsages.filter(u => u.category === 'ban');
    const now = new Date();

    return this.fleets.map(fleet => {
      // Find matching Tracksolid GPS device
      const matchedDevice = devices.find(d =>
        d.vehiclePlate.toLowerCase().replace(/\s+/g, '') === fleet.plateNumber.toLowerCase().replace(/\s+/g, '') ||
        (fleet.gpsImei && d.imei === fleet.gpsImei) ||
        (fleet.initialCode && d.vehicleName && d.vehicleName.toLowerCase().includes(fleet.initialCode.toLowerCase().split('/')[0].trim()))
      );

      // Total daily mileage from Tracksolid (todayMileageKm)
      // If Tracksolid has 0 or unavailable, fall back to realistic daily route average
      const dailyMileage = matchedDevice?.todayMileageKm && matchedDevice.todayMileageKm > 0
        ? matchedDevice.todayMileageKm
        : fleet.status === 'on-duty' ? 88.5 : fleet.status === 'available' ? 42.0 : 0;

      // Find latest tire change record from spare parts usage
      const latestUsage = tireUsages
        .filter(u => u.fleetId === fleet.id || u.plateNumber.toLowerCase().replace(/\s+/g, '') === fleet.plateNumber.toLowerCase().replace(/\s+/g, ''))
        .sort((a, b) => new Date(b.replacementDate).getTime() - new Date(a.replacementDate).getTime())[0];

      // Fleet specific parameters
      const isPickUp = fleet.vehicleType === 'Pick Up Box';
      const isDouble = fleet.vehicleType === 'Double STD';
      const isEngkel = fleet.vehicleType === 'Engkel STD' || fleet.vehicleType === 'Engkel Long';

      const initialTreadDepthMm = isPickUp ? 10.0 : isDouble ? 15.0 : 13.0; // Ketebalan tapak ban baru
      const minTreadDepthLegalMm = 2.0; // Batas minimal alur ban aman (legal limit 1.6mm - safety limit 2.0mm)
      const usableTreadDepthMm = initialTreadDepthMm - minTreadDepthLegalMm;

      // Tire brand & model
      const tireBrandModel = isPickUp 
        ? 'Bridgestone Ecopia R156 8PR' 
        : isDouble 
        ? 'Gajah Tunggal Super Lug Heavy Duty' 
        : 'Michelin X Multi Z Radial';

      const tireSize = isPickUp 
        ? '185/80 R14' 
        : isDouble 
        ? '7.50-16 14PR' 
        : '7.50-16 12PR';

      const maxLifespanKm = isPickUp ? 45000 : isDouble ? 60000 : 55000;
      const currentOdo = fleet.odometerKm || 50000;
      
      // Determine installed kilometer
      const installedAtKm = latestUsage ? latestUsage.odometerKm : Math.max(0, currentOdo - (currentOdo % maxLifespanKm));
      const accumulatedKm = Math.max(1200, currentOdo - installedAtKm);
      const remainingKm = Math.max(0, maxLifespanKm - accumulatedKm);
      
      // Calculate wear percentage (0% to 100%)
      const wearPercentage = Math.min(100, Number(((accumulatedKm / maxLifespanKm) * 100).toFixed(1)));
      const healthScore = Math.max(0, Number((100 - wearPercentage).toFixed(1)));

      // Current tread depth based on accumulated mileage
      const treadConsumedMm = (accumulatedKm / maxLifespanKm) * usableTreadDepthMm;
      const currentTreadDepthMm = Math.max(minTreadDepthLegalMm, Number((initialTreadDepthMm - treadConsumedMm).toFixed(2)));

      // Daily wear rate (mm per day) based on Tracksolid daily mileage
      // Formula: (usableTreadDepthMm / maxLifespanKm) * dailyMileage
      const dailyWearRateMm = dailyMileage > 0 
        ? Number(((usableTreadDepthMm / maxLifespanKm) * dailyMileage).toFixed(4)) 
        : 0.005;

      // Estimated days remaining until replacement
      const effectiveDailyKm = Math.max(dailyMileage, 35);
      const estimatedDaysRemaining = remainingKm > 0 
        ? Math.round(remainingKm / effectiveDailyKm) 
        : 0;

      // Projected replacement date
      const projectedDate = new Date(now.getTime() + estimatedDaysRemaining * 24 * 60 * 60 * 1000);
      const projectedReplacementDate = projectedDate.toISOString().substring(0, 10);

      // Rotation due every 10,000 km
      const rotationIntervalKm = 10000;
      const rotationDueKm = installedAtKm + (Math.floor(accumulatedKm / rotationIntervalKm) + 1) * rotationIntervalKm;
      const isRotationNeeded = (accumulatedKm % rotationIntervalKm) >= 8500;

      // Tire status logic
      let status: 'Optimal' | 'Waspada' | 'Kritis' = 'Optimal';
      let statusLabel = 'Kondisi Prima';
      let recommendation = 'Tekanan angin stabil, lanjutkan pemantauan harian.';

      if (remainingKm <= 3500 || currentTreadDepthMm <= 3.0 || wearPercentage >= 85) {
        status = 'Kritis';
        statusLabel = 'Wajib Ganti Segera';
        recommendation = `Alur tapak ban menipis (${currentTreadDepthMm} mm). Segera jadwalkan penggantian ban baru di gudang sparepart sebelum muatan berat.`;
      } else if (remainingKm <= 9000 || currentTreadDepthMm <= 5.0 || wearPercentage >= 65) {
        status = 'Waspada';
        statusLabel = 'Perlu Rotasi & Jadwal Ganti';
        recommendation = isRotationNeeded 
          ? `Disarankan rotasi ban silang (depan-belakang) pada ${rotationDueKm.toLocaleString('id-ID')} KM untuk mencegah aus tidak merata.`
          : `Ban masuk fase aus moderat. Pantau tekanan angin mingguan dan batasi beban overload.`;
      } else {
        status = 'Optimal';
        statusLabel = 'Kondisi Prima';
        recommendation = `Ban dalam performa terbaik (${healthScore}% health). Rekomendasi rotasi berikutnya pada ${rotationDueKm.toLocaleString('id-ID')} KM.`;
      }

      // Pressure (PSI)
      const recommendedPressurePsi = isPickUp ? 45 : isDouble ? 95 : 85;
      const pressureOffset = status === 'Kritis' ? -8 : status === 'Waspada' ? -4 : 0;
      const pressurePsi = recommendedPressurePsi + pressureOffset;

      return {
        fleetId: fleet.id,
        plateNumber: fleet.plateNumber,
        initialCode: fleet.initialCode,
        vehicleType: fleet.vehicleType,
        brand: fleet.brand || 'Mitsubishi',
        currentOdometerKm: currentOdo,
        todayMileageKm: Number(dailyMileage.toFixed(2)),
        trackedImei: matchedDevice?.imei,
        isGpsOnline: matchedDevice ? (matchedDevice.status === 'Online' || matchedDevice.status === 'Sleeping') : false,
        tireBrandModel,
        tireSize,
        initialTreadDepthMm,
        currentTreadDepthMm,
        minTreadDepthLegalMm,
        installedAtKm,
        accumulatedKm,
        maxLifespanKm,
        remainingKm,
        wearPercentage,
        healthScore,
        dailyWearRateMm,
        estimatedDaysRemaining,
        projectedReplacementDate,
        status,
        statusLabel,
        recommendation,
        rotationDueKm,
        isRotationNeeded,
        pressurePsi,
        recommendedPressurePsi
      };
    });
  }

  // ==========================================
  // DOCUMENT SCANNING & SEARCHABLE LOGS
  // ==========================================
  public getScannedDocuments(): ScannedDocumentLog[] {
    return [...this.scannedDocuments];
  }

  public addScannedDocument(doc: Omit<ScannedDocumentLog, 'id' | 'timestamp'>): ScannedDocumentLog {
    const newDoc: ScannedDocumentLog = {
      ...doc,
      id: `DOC-SCAN-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      timestamp: new Date().toISOString()
    };
    this.scannedDocuments = [newDoc, ...this.scannedDocuments];
    fetch('/api/scanned-documents', {
      method: 'POST',
      credentials: 'same-origin',
      headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(newDoc)
    }).catch(err => console.warn('[Hostinger ScannedDocs] Gagal simpan ke MySQL:', err));
    this.logActivity(
      'Scan Dokumen',
      newDoc.documentNumber,
      `Dokumen digital dipindai & diarsipkan: ${newDoc.documentTypeLabel} (${newDoc.documentNumber})`,
      'tambah'
    );
    this.notify();
    return newDoc;
  }

  public updateScannedDocument(id: string, updates: Partial<ScannedDocumentLog>): void {
    this.scannedDocuments = this.scannedDocuments.map(d => d.id === id ? { ...d, ...updates } : d);
    fetch(`/api/scanned-documents/${encodeURIComponent(id)}`, {
      method: 'PUT',
      credentials: 'same-origin',
      headers: this.buildSessionAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(updates)
    }).catch(err => console.warn('[Hostinger ScannedDocs] Gagal update ke MySQL:', err));
    this.notify();
  }

  public deleteScannedDocument(id: string): void {
    this.scannedDocuments = this.scannedDocuments.filter(d => d.id !== id);
    fetch(`/api/scanned-documents/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      credentials: 'same-origin',
      headers: this.buildSessionAuthHeaders()
    }).catch(err => console.warn('[Hostinger ScannedDocs] Gagal hapus di MySQL:', err));
    this.notify();
  }

  // ==========================================
  // CHAT & INTERNAL MESSAGING (DISABLED)
  // ==========================================
  public getMessages(): ChatMessage[] {
    return [];
  }

  public async fetchMessagesFromApi(): Promise<ChatMessage[]> {
    return [];
  }

  public async sendMessage(msg: Omit<ChatMessage, 'id' | 'timestamp'>): Promise<ChatMessage> {
    const newMsg: ChatMessage = {
      ...msg,
      id: `msg-${Date.now()}`,
      timestamp: new Date().toISOString(),
      isRead: false
    };
    return newMsg;
  }

  public async markMessagesAsRead(_senderId?: string): Promise<void> {
    // no-op
  }
}

export const logisticsStore = new LogisticsStore();
